# PowerShell Script to Update Tool Pages to New Sidebar Layout
# This script updates all tool HTML files from the old design to the new sidebar layout

Write-Host "Starting bulk update of tool pages..." -ForegroundColor Cyan

# Get all HTML files in the tools directory that reference the old CSS
$toolsPath = ".\tools"
$filesToUpdate = Get-ChildItem -Path $toolsPath -Recurse -Filter "*.html" | Where-Object {
    $content = Get-Content $_.FullName -Raw
    $content -match 'css/style\.css'
}

Write-Host "Found $($filesToUpdate.Count) files to update" -ForegroundColor Yellow

$updatedCount = 0
$errorCount = 0
$skippedCount = 0

foreach ($file in $filesToUpdate) {
    try {
        Write-Host "`nProcessing: $($file.Name)" -ForegroundColor White
        
        $content = Get-Content $file.FullName -Raw
        
        # Skip if already updated (has design-system.css)
        if ($content -match 'design-system\.css') {
            Write-Host "  Skipped (already updated)" -ForegroundColor Gray
            $skippedCount++
            continue
        }
        
        # Create backup
        $backupPath = $file.FullName + ".backup"
        Copy-Item $file.FullName $backupPath -Force
        
        # Update CSS reference
        $content = $content -replace 'css/style\.css', 'css/design-system.css'
        
        # Update old header structure to new header
        $oldHeaderPattern = '(?s)<header class="header">.*?</header>'
        $newHeader = '<header class="header"></header>'
        $content = $content -replace $oldHeaderPattern, $newHeader
        
        # Remove breadcrumb section (old design)
        $content = $content -replace '(?s)<div class="breadcrumb">.*?</div>\s*', ''
        
        # Update main container structure
        $content = $content -replace '<main class="container tool-page">', @'
<!-- Tool Layout with Sidebar -->
    <div class="tool-layout">
        <!-- Sidebar -->
        <aside class="tool-sidebar" id="tool-sidebar"></aside>

        <!-- Main Content -->
        <main class="tool-main">
            <div class="tool-page" style="max-width: 900px; margin: 0; padding: 0;">
'@
        
        # Update closing main tag
        $content = $content -replace '</main>', @'
</div>
        </main>
    </div>

    <!-- Mobile Sidebar Toggle -->
    <button class="sidebar-toggle" id="sidebar-toggle">
        <svg class="icon" viewBox="0 0 24 24">
            <line x1="4" y1="12" x2="20" y2="12" />
            <line x1="4" y1="6" x2="20" y2="6" />
            <line x1="4" y1="18" x2="20" y2="18" />
        </svg>
    </button>

    <!-- Footer -->
    <footer class="footer"></footer>
'@
        
        # Update tool header structure
        $content = $content -replace '<div class="tool-header">\s*<h1>', @'
<!-- Tool Header -->
                <div class="tool-header" style="text-align: left; margin-bottom: var(--space-6);">
                    <div style="display: flex; align-items: center; gap: var(--space-4); margin-bottom: var(--space-4);">
                        <div class="tool-icon-large" style="margin: 0;">
                            <svg class="icon icon-lg" viewBox="0 0 24 24">
                                <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z" />
                            </svg>
                        </div>
                        <div>
                            <h1 class="tool-title" style="font-size: var(--text-2xl);">
'@
        
        $content = $content -replace '</h1>\s*<p class="tool-intro">', @'
</h1>
                            <p class="tool-description" style="font-size: var(--text-base); margin: 0;">
'@
        
        $content = $content -replace '</p>\s*</div>\s*(?=<div class="tool-interface">)', @'
</p>
                        </div>
                    </div>
                </div>

'@
        
        # Add component initialization if not present
        if ($content -notmatch 'Components\.renderHeader') {
            $content = $content -replace '(<script>)', @'
$1
        document.addEventListener('DOMContentLoaded', () => {
            Components.renderHeader();
            Components.renderMobileMenu();
            Components.renderSidebar('tool-sidebar');
            Components.renderFooter();

            const sidebarToggle = document.getElementById('sidebar-toggle');
            const sidebar = document.getElementById('tool-sidebar');
            sidebarToggle?.addEventListener('click', () => sidebar?.classList.toggle('open'));

            // Original script content continues below...
'@
            
            # Close the DOMContentLoaded listener at the end
            $content = $content -replace '(</script>)', @'

            if (window.ThemeManager) ThemeManager.init();
            if (window.ResponsiveManager) ResponsiveManager.init();
        });
    $1
'@
        }
        
        # Update canonical URLs
        $content = $content -replace 'onlinetoolfree\.com', 'freetoolskit.com'
        $content = $content -replace 'OnlineToolFree', 'Free Tools Kit'
        
        # Update meta description branding
        $content = $content -replace 'Free online ([^.]+)\.', 'Free online $1 tool. Fast, secure, and private.'
        
        # Write updated content
        Set-Content -Path $file.FullName -Value $content -NoNewline
        
        Write-Host "  Updated successfully" -ForegroundColor Green
        $updatedCount++
        
    } catch {
        Write-Host "  ERROR: $($_.Exception.Message)" -ForegroundColor Red
        $errorCount++
        
        # Restore from backup if error occurred
        if (Test-Path $backupPath) {
            Copy-Item $backupPath $file.FullName -Force
            Remove-Item $backupPath -Force
        }
    }
}

Write-Host "`n" + "="*60 -ForegroundColor Cyan
Write-Host "Update Complete!" -ForegroundColor Cyan
Write-Host "="*60 -ForegroundColor Cyan
Write-Host "Updated: $updatedCount files" -ForegroundColor Green
Write-Host "Skipped: $skippedCount files (already updated)" -ForegroundColor Gray
Write-Host "Errors:  $errorCount files" -ForegroundColor Red
Write-Host "`nBackup files (.backup) have been created for all processed files." -ForegroundColor Yellow
Write-Host "Review the changes and delete backup files when satisfied." -ForegroundColor Yellow
