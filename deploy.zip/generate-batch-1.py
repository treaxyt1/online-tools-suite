#!/usr/bin/env python3
"""
Generate Writing and Productivity Tools (Batch 1)
Part of the 30 High-Demand Tools Initiative
"""

from pathlib import Path

# Base Template Components
def get_header(title, description, slug, category_path):
    return f'''<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title} | OnlineToolFree</title>
    <meta name="description" content="{description}">
    <link rel="canonical" href="https://onlinetoolfree.com/tools/{category_path}/{slug}.html">
    <link rel="stylesheet" href="../../css/design-system.css">
    <script src="../../js/tools.js"></script>
    <script src="../../js/ui.js"></script>
    <script src="../../js/app.js"></script>
</head>
<body>
    <header class="header"></header>
    <div class="tool-layout">
        <aside class="tool-sidebar" id="tool-sidebar"></aside>
        <main class="tool-main">
            <div class="tool-page" style="max-width: 1000px; margin: 0; padding: 0;">
'''

def get_footer(schema_json):
    return f'''
            </div>
        </main>
    </div>
    <button class="sidebar-toggle" id="sidebar-toggle">
        <svg class="icon" viewBox="0 0 24 24"><line x1="4" y1="12" x2="20" y2="12"/><line x1="4" y1="6" x2="20" y2="6"/><line x1="4" y1="18" x2="20" y2="18"/></svg>
    </button>
    <footer class="footer"></footer>
    <script type="application/ld+json">{schema_json}</script>
    <script>
        document.addEventListener('DOMContentLoaded', () => {{
            Components.renderHeader();
            Components.renderSidebar('tool-sidebar');
            Components.renderFooter();
            if (window.ThemeManager) ThemeManager.init();
        }});
    </script>
</body>
</html>'''

# Tool Definitions
TOOLS = {
    'writing/paraphrasing-tool.html': {
        'title': 'Paraphrasing Tool - Free Sentence Rephraser',
        'desc': 'Free paraphrasing tool to reword sentences and paragraphs. Improve writing flow and avoid plagiarism with our synonym-based rephraser.',
        'content': '''
                <h1 class="tool-title">Paraphrasing Tool</h1>
                <p class="tool-description">Rephrase your text to improve clarity and uniqueness.</p>
                <div class="tool-interface">
                    <div class="tool-section">
                        <label class="form-label">Original Text</label>
                        <textarea id="source-text" class="form-input" rows="8" placeholder="Paste your text here..."></textarea>
                    </div>
                    <div class="tool-actions">
                        <button id="paraphrase-btn" class="btn btn-primary">Paraphrase Now</button>
                    </div>
                    <div class="tool-section output-section">
                        <label class="form-label">Paraphrased Result</label>
                        <div id="output-text" class="form-input" style="min-height: 150px; background: var(--bg-tertiary); white-space: pre-wrap;"></div>
                        <div class="output-actions" style="margin-top: var(--space-3);">
                            <button onclick="copyOutput()" class="btn btn-ghost btn-sm">Copy to Clipboard</button>
                        </div>
                    </div>
                </div>
                <script>
                    const synonyms = {
                        'happy': ['joyful', 'cheerful', 'content', 'delighted'],
                        'fast': ['quick', 'rapid', 'swift', 'speedy'],
                        'smart': ['intelligent', 'clever', 'bright', 'wise'],
                        'important': ['crucial', 'significant', 'vital', 'essential'],
                        'help': ['assist', 'aid', 'support'],
                        'easy': ['simple', 'straightforward', 'effortless'],
                        'beautiful': ['gorgeous', 'stunning', 'lovely'],
                        'big': ['large', 'huge', 'massive', 'enormous']
                    };
                    document.getElementById('paraphrase-btn').addEventListener('click', () => {
                        const text = document.getElementById('source-text').value;
                        if(!text) return Toast.error('Please enter text');
                        let words = text.split(/(\\s+)/);
                        let result = words.map(w => {
                            let clean = w.toLowerCase().replace(/[^a-z]/g, '');
                            if(synonyms[clean]) {
                                let syn = synonyms[clean][Math.floor(Math.random() * synonyms[clean].length)];
                                return w.replace(new RegExp(clean, 'i'), syn);
                            }
                            return w;
                        }).join('');
                        document.getElementById('output-text').textContent = result;
                        Toast.success('Text paraphrased!');
                    });
                    function copyOutput() {
                        const txt = document.getElementById('output-text').textContent;
                        navigator.clipboard.writeText(txt).then(() => Toast.success('Copied!'));
                    }
                </script>
        '''
    },
    'writing/essay-outline.html': {
        'title': 'Essay Outline Generator - Free Structure Maker',
        'desc': 'Create a professional essay outline in seconds. Select essay type and generate a structured plan for your introduction, body, and conclusion.',
        'content': '''
                <h1 class="tool-title">Essay Outline Generator</h1>
                <p class="tool-description">Generate a structured outline for your next essay.</p>
                <div class="tool-interface">
                    <div class="tool-section">
                        <div class="grid" style="grid-template-columns: 1fr 1fr; gap: var(--space-4);">
                            <div>
                                <label class="form-label">Essay Topic</label>
                                <input type="text" id="topic" class="form-input" placeholder="e.g. Climate Change">
                            </div>
                            <div>
                                <label class="form-label">Essay Type</label>
                                <select id="type" class="form-input">
                                    <option value="argumentative">Argumentative</option>
                                    <option value="persuasive">Persuasive</option>
                                    <option value="expository">Expository</option>
                                    <option value="narrative">Narrative</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="tool-actions">
                        <button id="generate-btn" class="btn btn-primary">Generate Outline</button>
                    </div>
                    <div id="outline-result" class="tool-section output-section" style="display:none;">
                        <div id="outline-content" style="background: var(--bg-tertiary); padding: var(--space-6); border-radius: var(--radius-lg); line-height: 1.8;"></div>
                    </div>
                </div>
                <script>
                    document.getElementById('generate-btn').addEventListener('click', () => {
                        const topic = document.getElementById('topic').value || 'Selected Topic';
                        const type = document.getElementById('type').value;
                        const content = `
                            <h3>I. Introduction</h3>
                            <ul><li>Hook: Interesting fact about ${topic}</li><li>Background information</li><li>Thesis Statement</li></ul>
                            <h3>II. Body Paragraph 1: Foundation</h3>
                            <ul><li>Topic Sentence</li><li>Evidence supporting ${topic}</li><li>Analysis and link to thesis</li></ul>
                            <h3>III. Body Paragraph 2: Complexity</h3>
                            <ul><li>Specific aspect of ${topic}</li><li>Detailed analysis</li><li>Transitions</li></ul>
                            <h3>IV. Body Paragraph 3: Counter-Argument (if applicable)</h3>
                            <ul><li>Opposing views</li><li>Rebuttal</li></ul>
                            <h3>V. Conclusion</h3>
                            <ul><li>Restate thesis</li><li>Summary of main points</li><li>Final closing thought on ${topic}</li></ul>
                        `;
                        document.getElementById('outline-content').innerHTML = content;
                        document.getElementById('outline-result').style.display = 'block';
                        Toast.success('Outline generated!');
                    });
                </script>
        '''
    },
    'productivity/note-taking.html': {
        'title': 'Online Notepad - Private Browser-Based Notes',
        'desc': 'Free online notepad with no sign-up required. Save notes instantly in your browser. Private, secure, and features auto-save functionality.',
        'content': '''
                <h1 class="tool-title">Cloud Notes (Local)</h1>
                <p class="tool-description">Private notes that save automatically in your browser.</p>
                <div class="tool-interface">
                    <div class="tool-section">
                        <textarea id="notes" class="form-input" style="height: 400px; font-family: monospace;" placeholder="Start writing... Your notes are saved automatically."></textarea>
                    </div>
                    <div class="tool-actions">
                        <button id="clear-btn" class="btn btn-ghost">Clear All</button>
                        <button id="download-btn" class="btn btn-primary">Download as TXT</button>
                    </div>
                </div>
                <script>
                    const editor = document.getElementById('notes');
                    editor.value = localStorage.getItem('bt_notes') || '';
                    editor.addEventListener('input', () => {
                        localStorage.setItem('bt_notes', editor.value);
                    });
                    document.getElementById('clear-btn').addEventListener('click', () => {
                        if(confirm('Are you sure you want to clear all notes?')) {
                            editor.value = '';
                            localStorage.removeItem('bt_notes');
                        }
                    });
                    document.getElementById('download-btn').addEventListener('click', () => {
                        const blob = new Blob([editor.value], {type: 'text/plain'});
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = url;
                        a.download = 'my-notes.txt';
                        a.click();
                    });
                </script>
        '''
    },
    'productivity/habit-tracker.html': {
        'title': 'Daily Habit Tracker - Visual Progress Calendar',
        'desc': 'Free online habit tracker. Build better routines with visual progress tracking. Mark your daily habits and see your streaks without signing up.',
        'content': '''
                <h1 class="tool-title">Daily Habit Tracker</h1>
                <p class="tool-description">Track your daily progress and build long-term habits.</p>
                <div class="tool-interface">
                    <div class="tool-section">
                        <div style="display: flex; gap: var(--space-2); margin-bottom: var(--space-4);">
                            <input type="text" id="habit-name" class="form-input" placeholder="New Habit (e.g. Exercise)">
                            <button id="add-habit" class="btn btn-primary">Add</button>
                        </div>
                        <div id="habits-list" style="display: grid; gap: var(--space-3);"></div>
                    </div>
                </div>
                <script>
                    let habits = JSON.parse(localStorage.getItem('bt_habits') || '[]');
                    function save() { localStorage.setItem('bt_habits', JSON.stringify(habits)); render(); }
                    function render() {
                        const list = document.getElementById('habits-list');
                        list.innerHTML = habits.map((h, i) => `
                            <div style="padding: var(--space-4); background: var(--bg-tertiary); border-radius: var(--radius-lg); display: flex; justify-content: space-between; align-items: center;">
                                <div><strong style="font-size: var(--text-lg);">${h.name}</strong><br><small>Streak: ${h.streak || 0} days</small></div>
                                <div style="display: flex; gap: var(--space-2);">
                                    <button onclick="check(${i})" class="btn btn-success btn-sm">Done Today</button>
                                    <button onclick="remove(${i})" class="btn btn-ghost btn-sm">Delete</button>
                                </div>
                            </div>
                        `).join('');
                    }
                    document.getElementById('add-habit').addEventListener('click', () => {
                        const name = document.getElementById('habit-name').value;
                        if(name) { habits.push({name, streak: 0}); document.getElementById('habit-name').value = ''; save(); }
                    });
                    window.check = (i) => { habits[i].streak++; save(); Toast.success('Great job!'); };
                    window.remove = (i) => { if(confirm('Delete?')) { habits.splice(i, 1); save(); } };
                    render();
                </script>
        '''
    },
    'seo/utm-builder.html': {
        'title': 'UTM Link Builder - Free Campaign URL Generator',
        'desc': 'Generate campaign URLs with UTM parameters. Track your marketing performance in Google Analytics with our free UTM builder.',
        'content': '''
                <h1 class="tool-title">UTM Link Builder</h1>
                <p class="tool-description">Create tracking URLs for your marketing campaigns.</p>
                <div class="tool-interface">
                    <div class="tool-section" style="display: grid; gap: var(--space-4);">
                        <div><label class="form-label">Website URL *</label><input type="text" id="url" class="form-input" placeholder="https://example.com"></div>
                        <div class="grid" style="grid-template-columns: 1fr 1fr; gap: var(--space-4);">
                            <div><label class="form-label">Campaign Source *</label><input type="text" id="source" class="form-input" placeholder="google, newsletter"></div>
                            <div><label class="form-label">Campaign Medium *</label><input type="text" id="medium" class="form-input" placeholder="cpc, email"></div>
                        </div>
                        <div><label class="form-label">Campaign Name *</label><input type="text" id="name" class="form-input" placeholder="summer_sale"></div>
                    </div>
                    <div class="tool-actions">
                        <button id="build-btn" class="btn btn-primary">Generate URL</button>
                    </div>
                    <div id="result-box" class="tool-section output-section" style="display:none;">
                        <label class="form-label">Generated URL</label>
                        <div id="final-url" style="background: var(--bg-tertiary); padding: var(--space-4); border-radius: var(--radius-md); word-break: break-all; font-family: monospace;"></div>
                        <button onclick="copyUrl()" class="btn btn-ghost btn-sm" style="margin-top: var(--space-2);">Copy URL</button>
                    </div>
                </div>
                <script>
                    document.getElementById('build-btn').addEventListener('click', () => {
                        const url = document.getElementById('url').value;
                        const s = document.getElementById('source').value;
                        const m = document.getElementById('medium').value;
                        const n = document.getElementById('name').value;
                        if(!url || !s || !m || !n) return Toast.error('Fill required fields');
                        const final = `${url}${url.includes('?') ? '&' : '?'}utm_source=${encodeURIComponent(s)}&utm_medium=${encodeURIComponent(m)}&utm_campaign=${encodeURIComponent(n)}`;
                        document.getElementById('final-url').textContent = final;
                        document.getElementById('result-box').style.display = 'block';
                    });
                    function copyUrl() {
                        navigator.clipboard.writeText(document.getElementById('final-url').textContent).then(() => Toast.success('Copied!'));
                    }
                </script>
        '''
    }
}

def main():
    for path, data in TOOLS.items():
        file_path = Path(f'./tools/{path}')
        file_path.parent.mkdir(parents=True, exist_ok=True)
        
        slug = path.split('/')[-1].replace('.html', '')
        cat = path.split('/')[0]
        
        schema = {
            "@context": "https://schema.org",
            "@type": "SoftwareApplication",
            "name": data['title'],
            "applicationCategory": "UtilityApplication",
            "offers": {"@type": "Offer", "price": "0", "priceCurrency": "USD"},
            "description": data['desc']
        }
        
        html = get_header(data['title'], data['desc'], slug, cat)
        html += data['content']
        html += get_footer(import_json := __import__('json').dumps(schema))
        
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(html)
        print(f"Generated: {path}")

if __name__ == '__main__':
    main()
