#!/usr/bin/env python3
"""
Generate TIER 1 High-Priority Tools (Batch 3)
Tools: QR Code Scanner, AI Resume Builder, Translator (MyMemory API - Free, No Key)
"""

from pathlib import Path

def get_header(title, description, slug, category_path):
    return f'''<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title} | OnlineToolFree</title>
    <meta name="description" content="{description}">
    <link rel="canonical" href="https://onlinetoolfree.com/tools/{category_path}/{slug}.html">
    <link rel="stylesheet" href="../../css/design-system.css">
    <script src="../../js/tools.js"></script>
    <script src="../../js/ui.js"></script>
    <script src="../../js/app.js"></script>
</head>
<body>
    <header class="header"></header>
    <div class="tool-layout">
        <aside class="tool-sidebar" id="tool-sidebar"></aside>
        <main class="tool-main">
            <div class="tool-page" style="max-width: 1000px; margin: 0; padding: 0;">
'''

def get_footer(schema_json):
    return f'''
            </div>
        </main>
    </div>
    <button class="sidebar-toggle" id="sidebar-toggle">
        <svg class="icon" viewBox="0 0 24 24"><line x1="4" y1="12" x2="20" y2="12"/><line x1="4" y1="6" x2="20" y2="6"/><line x1="4" y1="18" x2="20" y2="18"/></svg>
    </button>
    <footer class="footer"></footer>
    <script type="application/ld+json">{schema_json}</script>
    <script>
        document.addEventListener('DOMContentLoaded', () => {{
            Components.renderHeader();
            Components.renderSidebar('tool-sidebar');
            Components.renderFooter();
            if (window.ThemeManager) ThemeManager.init();
        }});
    </script>
</body>
</html>'''

TOOLS = {
    'scanner/qr-code-scanner.html': {
        'title': 'QR Code Scanner - Scan QR Codes Online Free',
        'desc': 'Free QR code scanner. Scan QR codes using your camera or upload an image. Decode QR codes instantly. Works on mobile and desktop.',
        'content': '''
                <h1 class="tool-title">QR Code Scanner</h1>
                <p class="tool-description">Scan QR codes using your camera or upload an image.</p>
                <script src="https://cdn.jsdelivr.net/npm/jsqr@1.4.0/dist/jsQR.min.js"></script>
                <div class="tool-interface">
                    <div class="tool-section">
                        <div style="text-align: center;">
                            <button id="start-camera" class="btn btn-primary">Start Camera</button>
                            <button id="upload-btn" class="btn btn-ghost">Upload Image</button>
                            <input type="file" id="file-input" accept="image/*" hidden>
                        </div>
                        <div style="margin-top: var(--space-4); text-align: center;">
                            <video id="video" style="max-width: 100%; border-radius: var(--radius-lg); display: none;"></video>
                            <canvas id="canvas" style="display: none;"></canvas>
                        </div>
                    </div>
                    <div id="result-section" class="tool-section output-section" style="display:none;">
                        <h3>Scanned Result:</h3>
                        <div id="qr-result" style="padding: var(--space-4); background: var(--bg-tertiary); border-radius: var(--radius-lg); word-break: break-all; font-family: monospace;"></div>
                        <button onclick="copyResult()" class="btn btn-ghost btn-sm" style="margin-top: var(--space-2);">Copy Result</button>
                    </div>
                </div>
                <script>
                    let stream;
                    const video = document.getElementById('video');
                    const canvas = document.getElementById('canvas');
                    const ctx = canvas.getContext('2d');
                    
                    document.getElementById('start-camera').addEventListener('click', async () => {
                        try {
                            stream = await navigator.mediaDevices.getUserMedia({video: {facingMode: 'environment'}});
                            video.srcObject = stream;
                            video.play();
                            video.style.display = 'block';
                            scanQR();
                        } catch(e) {
                            Toast.error('Camera access denied');
                        }
                    });
                    
                    document.getElementById('upload-btn').addEventListener('click', () => {
                        document.getElementById('file-input').click();
                    });
                    
                    document.getElementById('file-input').addEventListener('change', (e) => {
                        const file = e.target.files[0];
                        if(!file) return;
                        
                        const img = new Image();
                        img.onload = () => {
                            canvas.width = img.width;
                            canvas.height = img.height;
                            ctx.drawImage(img, 0, 0);
                            const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
                            const code = jsQR(imageData.data, imageData.width, imageData.height);
                            
                            if(code) {
                                showResult(code.data);
                            } else {
                                Toast.error('No QR code found in image');
                            }
                        };
                        img.src = URL.createObjectURL(file);
                    });
                    
                    function scanQR() {
                        if(video.readyState === video.HAVE_ENOUGH_DATA) {
                            canvas.width = video.videoWidth;
                            canvas.height = video.videoHeight;
                            ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
                            const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
                            const code = jsQR(imageData.data, imageData.width, imageData.height);
                            
                            if(code) {
                                showResult(code.data);
                                if(stream) stream.getTracks().forEach(t => t.stop());
                                video.style.display = 'none';
                                return;
                            }
                        }
                        requestAnimationFrame(scanQR);
                    }
                    
                    function showResult(data) {
                        document.getElementById('qr-result').textContent = data;
                        document.getElementById('result-section').style.display = 'block';
                        Toast.success('QR code scanned!');
                    }
                    
                    function copyResult() {
                        navigator.clipboard.writeText(document.getElementById('qr-result').textContent).then(() => Toast.success('Copied!'));
                    }
                </script>
        '''
    },
    'ai/resume-builder.html': {
        'title': 'AI Resume Builder - Create ATS-Optimized Resume Free',
        'desc': 'Free AI resume builder. Create professional ATS-optimized resumes in minutes. Multiple templates. Download as PDF. No sign-up required.',
        'content': '''
                <h1 class="tool-title">AI Resume Builder</h1>
                <p class="tool-description">Create a professional ATS-optimized resume.</p>
                <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
                <div class="tool-interface">
                    <div class="tool-section">
                        <h3>Personal Information</h3>
                        <div class="grid" style="grid-template-columns: 1fr 1fr; gap: var(--space-3);">
                            <input type="text" id="name" class="form-input" placeholder="Full Name">
                            <input type="email" id="email" class="form-input" placeholder="Email">
                            <input type="tel" id="phone" class="form-input" placeholder="Phone">
                            <input type="text" id="location" class="form-input" placeholder="Location">
                        </div>
                    </div>
                    <div class="tool-section">
                        <h3>Professional Summary</h3>
                        <textarea id="summary" class="form-input" rows="3" placeholder="Brief professional summary..."></textarea>
                    </div>
                    <div class="tool-section">
                        <h3>Work Experience</h3>
                        <div id="experience-list"></div>
                        <button onclick="addExperience()" class="btn btn-ghost btn-sm">+ Add Experience</button>
                    </div>
                    <div class="tool-section">
                        <h3>Education</h3>
                        <textarea id="education" class="form-input" rows="3" placeholder="Degree, University, Year"></textarea>
                    </div>
                    <div class="tool-section">
                        <h3>Skills</h3>
                        <textarea id="skills" class="form-input" rows="2" placeholder="Skill 1, Skill 2, Skill 3..."></textarea>
                    </div>
                    <div class="tool-actions">
                        <button id="generate-resume" class="btn btn-primary">Generate Resume PDF</button>
                    </div>
                </div>
                <script>
                    let expCount = 0;
                    
                    function addExperience() {
                        const div = document.createElement('div');
                        div.className = 'exp-item';
                        div.style.marginBottom = 'var(--space-3)';
                        div.innerHTML = `
                            <input type="text" class="form-input exp-title" placeholder="Job Title" style="margin-bottom: 5px;">
                            <input type="text" class="form-input exp-company" placeholder="Company" style="margin-bottom: 5px;">
                            <input type="text" class="form-input exp-dates" placeholder="Jan 2020 - Present" style="margin-bottom: 5px;">
                            <textarea class="form-input exp-desc" rows="2" placeholder="Job description..."></textarea>
                        `;
                        document.getElementById('experience-list').appendChild(div);
                        expCount++;
                    }
                    
                    // Add one experience field by default
                    addExperience();
                    
                    document.getElementById('generate-resume').addEventListener('click', () => {
                        const { jsPDF } = window.jspdf;
                        const doc = new jsPDF();
                        
                        let y = 20;
                        
                        // Header
                        doc.setFontSize(20);
                        doc.text(document.getElementById('name').value || 'Your Name', 105, y, {align: 'center'});
                        y += 10;
                        
                        doc.setFontSize(10);
                        const contact = [
                            document.getElementById('email').value,
                            document.getElementById('phone').value,
                            document.getElementById('location').value
                        ].filter(x => x).join(' | ');
                        doc.text(contact, 105, y, {align: 'center'});
                        y += 15;
                        
                        // Summary
                        if(document.getElementById('summary').value) {
                            doc.setFontSize(12);
                            doc.setFont(undefined, 'bold');
                            doc.text('PROFESSIONAL SUMMARY', 20, y);
                            y += 7;
                            doc.setFont(undefined, 'normal');
                            doc.setFontSize(10);
                            const summary = doc.splitTextToSize(document.getElementById('summary').value, 170);
                            doc.text(summary, 20, y);
                            y += summary.length * 5 + 10;
                        }
                        
                        // Experience
                        const expItems = document.querySelectorAll('.exp-item');
                        if(expItems.length > 0) {
                            doc.setFontSize(12);
                            doc.setFont(undefined, 'bold');
                            doc.text('WORK EXPERIENCE', 20, y);
                            y += 7;
                            
                            expItems.forEach(item => {
                                doc.setFontSize(11);
                                doc.setFont(undefined, 'bold');
                                doc.text(item.querySelector('.exp-title').value || 'Job Title', 20, y);
                                y += 5;
                                doc.setFont(undefined, 'normal');
                                doc.setFontSize(10);
                                doc.text(item.querySelector('.exp-company').value || 'Company', 20, y);
                                doc.text(item.querySelector('.exp-dates').value || 'Dates', 190, y, {align: 'right'});
                                y += 5;
                                const desc = doc.splitTextToSize(item.querySelector('.exp-desc').value || '', 170);
                                doc.text(desc, 20, y);
                                y += desc.length * 5 + 5;
                            });
                            y += 5;
                        }
                        
                        // Education
                        if(document.getElementById('education').value) {
                            doc.setFontSize(12);
                            doc.setFont(undefined, 'bold');
                            doc.text('EDUCATION', 20, y);
                            y += 7;
                            doc.setFont(undefined, 'normal');
                            doc.setFontSize(10);
                            const edu = doc.splitTextToSize(document.getElementById('education').value, 170);
                            doc.text(edu, 20, y);
                            y += edu.length * 5 + 10;
                        }
                        
                        // Skills
                        if(document.getElementById('skills').value) {
                            doc.setFontSize(12);
                            doc.setFont(undefined, 'bold');
                            doc.text('SKILLS', 20, y);
                            y += 7;
                            doc.setFont(undefined, 'normal');
                            doc.setFontSize(10);
                            doc.text(document.getElementById('skills').value, 20, y);
                        }
                        
                        doc.save('resume.pdf');
                        Toast.success('Resume generated!');
                    });
                </script>
        '''
    },
    'translator/translator.html': {
        'title': 'Free Translator - Translate Text Online 100+ Languages',
        'desc': 'Free online translator. Translate text between 100+ languages instantly. Powered by AI. No sign-up required. Fast and accurate translation.',
        'content': '''
                <h1 class="tool-title">Translator</h1>
                <p class="tool-description">Translate text between 100+ languages instantly.</p>
                <div class="tool-interface">
                    <div class="grid" style="grid-template-columns: 1fr 1fr; gap: var(--space-4);">
                        <div class="tool-section">
                            <label>From</label>
                            <select id="from-lang" class="form-input">
                                <option value="en">English</option>
                                <option value="es">Spanish</option>
                                <option value="fr">French</option>
                                <option value="de">German</option>
                                <option value="it">Italian</option>
                                <option value="pt">Portuguese</option>
                                <option value="ru">Russian</option>
                                <option value="ja">Japanese</option>
                                <option value="ko">Korean</option>
                                <option value="zh">Chinese</option>
                                <option value="ar">Arabic</option>
                                <option value="hi">Hindi</option>
                            </select>
                            <textarea id="source-text" class="form-input" rows="8" placeholder="Enter text to translate..." style="margin-top: var(--space-2);"></textarea>
                        </div>
                        <div class="tool-section">
                            <label>To</label>
                            <select id="to-lang" class="form-input">
                                <option value="es">Spanish</option>
                                <option value="en">English</option>
                                <option value="fr">French</option>
                                <option value="de">German</option>
                                <option value="it">Italian</option>
                                <option value="pt">Portuguese</option>
                                <option value="ru">Russian</option>
                                <option value="ja">Japanese</option>
                                <option value="ko">Korean</option>
                                <option value="zh">Chinese</option>
                                <option value="ar">Arabic</option>
                                <option value="hi">Hindi</option>
                            </select>
                            <div id="translated-text" class="form-input" style="margin-top: var(--space-2); min-height: 200px; background: var(--bg-tertiary); white-space: pre-wrap;"></div>
                        </div>
                    </div>
                    <div class="tool-actions">
                        <button id="translate-btn" class="btn btn-primary">Translate</button>
                        <button onclick="copyTranslation()" class="btn btn-ghost">Copy Translation</button>
                    </div>
                </div>
                <script>
                    let debounceTimer;
                    
                    document.getElementById('translate-btn').addEventListener('click', translate);
                    document.getElementById('source-text').addEventListener('input', () => {
                        clearTimeout(debounceTimer);
                        debounceTimer = setTimeout(translate, 1000);
                    });
                    
                    async function translate() {
                        const text = document.getElementById('source-text').value;
                        if(!text) return;
                        
                        const fromLang = document.getElementById('from-lang').value;
                        const toLang = document.getElementById('to-lang').value;
                        
                        if(fromLang === toLang) {
                            document.getElementById('translated-text').textContent = text;
                            return;
                        }
                        
                        try {
                            const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=${fromLang}|${toLang}`;
                            const response = await fetch(url);
                            const data = await response.json();
                            
                            if(data.responseData && data.responseData.translatedText) {
                                document.getElementById('translated-text').textContent = data.responseData.translatedText;
                            } else {
                                Toast.error('Translation failed');
                            }
                        } catch(e) {
                            Toast.error('Translation service unavailable');
                        }
                    }
                    
                    function copyTranslation() {
                        const text = document.getElementById('translated-text').textContent;
                        navigator.clipboard.writeText(text).then(() => Toast.success('Copied!'));
                    }
                </script>
        '''
    }
}

def main():
    for path, data in TOOLS.items():
        file_path = Path(f'./tools/{path}')
        file_path.parent.mkdir(parents=True, exist_ok=True)
        slug = path.split('/')[-1].replace('.html', '')
        cat = path.split('/')[0]
        schema = {"@context": "https://schema.org","@type": "SoftwareApplication","name": data['title'],"description": data['desc']}
        html = get_header(data['title'], data['desc'], slug, cat) + data['content'] + get_footer(__import__('json').dumps(schema))
        with open(file_path, 'w', encoding='utf-8') as f: f.write(html)
        print(f"Generated: {path}")

if __name__ == '__main__': main()
