#!/usr/bin/env python3
"""
Generate TIER 2 Tools (Batch 2)
Tools: Instagram Caption Generator, Bio Generator, Barcode Generator, Invoice Generator, Citation Generator
"""

from pathlib import Path

def get_header(title, description, slug, category_path):
    return f'''<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title} | OnlineToolFree</title>
    <meta name="description" content="{description}">
    <link rel="canonical" href="https://onlinetoolfree.com/tools/{category_path}/{slug}.html">
    <link rel="stylesheet" href="../../css/design-system.css">
    <script src="../../js/tools.js"></script>
    <script src="../../js/ui.js"></script>
    <script src="../../js/app.js"></script>
</head>
<body>
    <header class="header"></header>
    <div class="tool-layout">
        <aside class="tool-sidebar" id="tool-sidebar"></aside>
        <main class="tool-main">
            <div class="tool-page" style="max-width: 1000px; margin: 0; padding: 0;">
'''

def get_footer(schema_json):
    return f'''
            </div>
        </main>
    </div>
    <button class="sidebar-toggle" id="sidebar-toggle">
        <svg class="icon" viewBox="0 0 24 24"><line x1="4" y1="12" x2="20" y2="12"/><line x1="4" y1="6" x2="20" y2="6"/><line x1="4" y1="18" x2="20" y2="18"/></svg>
    </button>
    <footer class="footer"></footer>
    <script type="application/ld+json">{schema_json}</script>
    <script>
        document.addEventListener('DOMContentLoaded', () => {{
            Components.renderHeader();
            Components.renderSidebar('tool-sidebar');
            Components.renderFooter();
            if (window.ThemeManager) ThemeManager.init();
        }});
    </script>
</body>
</html>'''

TOOLS = {
    'social/instagram-caption.html': {
        'title': 'Instagram Caption Generator - AI Captions Free',
        'desc': 'Free Instagram caption generator. Create engaging captions with emojis and hashtags. AI-powered suggestions. Perfect for influencers and businesses.',
        'content': '''
                <h1 class="tool-title">Instagram Caption Generator</h1>
                <p class="tool-description">Generate engaging Instagram captions with AI.</p>
                <div class="tool-interface">
                    <div class="tool-section">
                        <label>Topic or Theme</label>
                        <input type="text" id="topic" class="form-input" placeholder="e.g., sunset, coffee, travel">
                        <div class="grid" style="grid-template-columns: 1fr 1fr; gap: var(--space-3); margin-top: var(--space-3);">
                            <div><label>Tone</label><select id="tone" class="form-input"><option>Casual</option><option>Professional</option><option>Funny</option><option>Inspirational</option><option>Romantic</option></select></div>
                            <div><label>Length</label><select id="length" class="form-input"><option>Short</option><option>Medium</option><option selected>Long</option></select></div>
                        </div>
                        <div style="margin-top: var(--space-3);"><label><input type="checkbox" id="emojis" checked> Include emojis</label><label style="margin-left: var(--space-4);"><input type="checkbox" id="hashtags" checked> Include hashtags</label></div>
                    </div>
                    <div class="tool-actions"><button id="generate" class="btn btn-primary">Generate Caption</button></div>
                    <div id="result" class="tool-section output-section" style="display:none;">
                        <div id="captions"></div>
                    </div>
                </div>
                <script>
                    const templates = {
                        Casual: ["Just vibing with {topic} 🌟", "Living my best life with {topic} ✨", "{topic} hits different 💯"],
                        Professional: ["Exploring {topic} in depth 📊", "Professional insights on {topic} 💼", "Mastering {topic} one day at a time 🎯"],
                        Funny: ["{topic}? More like best thing ever! 😂", "Me and {topic} = perfect match 🤪", "When {topic} is life 🙃"],
                        Inspirational: ["Let {topic} inspire your journey ✨", "Finding beauty in {topic} 🌅", "Chase your {topic} dreams 💫"],
                        Romantic: ["Falling in love with {topic} 💕", "{topic} makes my heart skip a beat 💗", "You, me, and {topic} forever 💖"]
                    };
                    const hashtags = ["#instagood", "#photooftheday", "#love", "#beautiful", "#happy", "#picoftheday", "#amazing", "#followme", "#instadaily", "#bestoftheday"];
                    const emojis = ["✨", "💫", "🌟", "💯", "🔥", "💪", "🎯", "🌈", "💖", "🌺"];
                    
                    document.getElementById('generate').addEventListener('click', () => {
                        const topic = document.getElementById('topic').value || 'life';
                        const tone = document.getElementById('tone').value;
                        const useEmojis = document.getElementById('emojis').checked;
                        const useHashtags = document.getElementById('hashtags').checked;
                        
                        const caps = templates[tone].map(t => {
                            let caption = t.replace('{topic}', topic);
                            if(!useEmojis) caption = caption.replace(/[\\u{1F300}-\\u{1F9FF}]/gu, '').trim();
                            if(useHashtags) {
                                const tags = hashtags.sort(() => 0.5 - Math.random()).slice(0, 5).join(' ');
                                caption += '\\n\\n' + tags;
                            }
                            return caption;
                        });
                        
                        document.getElementById('captions').innerHTML = caps.map(c => 
                            `<div style="padding: var(--space-4); background: var(--bg-tertiary); border-radius: var(--radius-lg); margin-bottom: var(--space-3); white-space: pre-wrap;">${c}<button onclick="navigator.clipboard.writeText('${c.replace(/'/g, "\\\\'")}').then(() => Toast.success('Copied!'))" class="btn btn-ghost btn-sm" style="margin-top: var(--space-2);">Copy</button></div>`
                        ).join('');
                        document.getElementById('result').style.display = 'block';
                    });
                </script>
        '''
    },
    'social/bio-generator.html': {
        'title': 'Bio Generator - Create Social Media Bios Free',
        'desc': 'Free bio generator for Instagram, Twitter, TikTok. Create catchy bios with emojis. Stand out on social media. No sign-up required.',
        'content': '''
                <h1 class="tool-title">Bio Generator</h1>
                <p class="tool-description">Create catchy social media bios.</p>
                <div class="tool-interface">
                    <div class="tool-section">
                        <div class="grid" style="grid-template-columns: 1fr 1fr; gap: var(--space-3);">
                            <div><label>Name/Brand</label><input type="text" id="name" class="form-input" placeholder="Your name"></div>
                            <div><label>Profession</label><input type="text" id="profession" class="form-input" placeholder="e.g., Designer"></div>
                        </div>
                        <div style="margin-top: var(--space-3);"><label>Interests (comma-separated)</label><input type="text" id="interests" class="form-input" placeholder="Travel, Coffee, Tech"></div>
                        <div style="margin-top: var(--space-3);"><label>Platform</label><select id="platform" class="form-input"><option>Instagram</option><option>Twitter</option><option>TikTok</option><option>LinkedIn</option></select></div>
                    </div>
                    <div class="tool-actions"><button id="generate" class="btn btn-primary">Generate Bios</button></div>
                    <div id="result" class="tool-section output-section" style="display:none;"><div id="bios"></div></div>
                </div>
                <script>
                    document.getElementById('generate').addEventListener('click', () => {
                        const name = document.getElementById('name').value || 'Creative Soul';
                        const prof = document.getElementById('profession').value || 'Creator';
                        const interests = document.getElementById('interests').value.split(',').map(i => i.trim()).filter(i => i);
                        const platform = document.getElementById('platform').value;
                        
                        const templates = [
                            `${name} | ${prof} ✨\\n${interests.slice(0,3).join(' • ')} 🌟`,
                            `${prof} 💼 | ${interests[0] || 'Passionate'} enthusiast 🔥\\n${name}`,
                            `✨ ${name}\\n${prof} | ${interests.join(' | ')}\\n📍 Living my best life`,
                            `${prof.toUpperCase()} 🎯\\n${interests.map(i => '• ' + i).join('\\n')}\\n${name}`,
                            `${name} 🌈\\n${prof} | ${interests[0]} lover\\nDM for collabs 📧`
                        ];
                        
                        document.getElementById('bios').innerHTML = templates.map(bio => 
                            `<div style="padding: var(--space-4); background: var(--bg-tertiary); border-radius: var(--radius-lg); margin-bottom: var(--space-3); white-space: pre-wrap; font-family: monospace;">${bio}<button onclick="navigator.clipboard.writeText(\`${bio}\`).then(() => Toast.success('Copied!'))" class="btn btn-ghost btn-sm" style="margin-top: var(--space-2);">Copy</button></div>`
                        ).join('');
                        document.getElementById('result').style.display = 'block';
                    });
                </script>
        '''
    },
    'generator/barcode-generator.html': {
        'title': 'Barcode Generator - Create Barcodes Free Online',
        'desc': 'Free barcode generator. Create Code128, EAN13, UPC barcodes. Download as PNG or SVG. Perfect for products and inventory.',
        'content': '''
                <h1 class="tool-title">Barcode Generator</h1>
                <p class="tool-description">Generate barcodes for products and inventory.</p>
                <script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.5/dist/JsBarcode.all.min.js"></script>
                <div class="tool-interface">
                    <div class="tool-section">
                        <label>Barcode Value</label>
                        <input type="text" id="barcode-value" class="form-input" placeholder="123456789012" value="123456789012">
                        <div class="grid" style="grid-template-columns: 1fr 1fr; gap: var(--space-3); margin-top: var(--space-3);">
                            <div><label>Format</label><select id="format" class="form-input"><option value="CODE128">Code 128</option><option value="EAN13">EAN-13</option><option value="UPC">UPC</option><option value="CODE39">Code 39</option></select></div>
                            <div><label>Height</label><input type="number" id="height" class="form-input" value="50" min="30" max="200"></div>
                        </div>
                    </div>
                    <div class="tool-actions"><button id="generate" class="btn btn-primary">Generate Barcode</button></div>
                    <div class="tool-section output-section" style="text-align: center;">
                        <svg id="barcode"></svg>
                        <div style="margin-top: var(--space-4);"><button id="download" class="btn btn-primary">Download PNG</button></div>
                    </div>
                </div>
                <script>
                    function generateBarcode() {
                        try {
                            JsBarcode("#barcode", document.getElementById('barcode-value').value, {
                                format: document.getElementById('format').value,
                                height: parseInt(document.getElementById('height').value),
                                displayValue: true
                            });
                            Toast.success('Barcode generated!');
                        } catch(e) {
                            Toast.error('Invalid barcode value');
                        }
                    }
                    document.getElementById('generate').addEventListener('click', generateBarcode);
                    document.getElementById('download').addEventListener('click', () => {
                        const svg = document.getElementById('barcode');
                        const canvas = document.createElement('canvas');
                        const ctx = canvas.getContext('2d');
                        const img = new Image();
                        img.onload = () => {
                            canvas.width = img.width;
                            canvas.height = img.height;
                            ctx.drawImage(img, 0, 0);
                            const a = document.createElement('a');
                            a.download = 'barcode.png';
                            a.href = canvas.toDataURL();
                            a.click();
                        };
                        img.src = 'data:image/svg+xml;base64,' + btoa(new XMLSerializer().serializeToString(svg));
                    });
                    generateBarcode();
                </script>
        '''
    },
    'generator/invoice-generator.html': {
        'title': 'Invoice Generator - Create Professional Invoices Free',
        'desc': 'Free invoice generator. Create professional invoices in minutes. Download as PDF. Perfect for freelancers and small businesses.',
        'content': '''
                <h1 class="tool-title">Invoice Generator</h1>
                <p class="tool-description">Create professional invoices instantly.</p>
                <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
                <div class="tool-interface">
                    <div class="grid" style="grid-template-columns: 1fr 1fr; gap: var(--space-4);">
                        <div class="tool-section"><h3>From</h3><input type="text" id="from-name" class="form-input" placeholder="Your Name" style="margin-bottom: 5px;"><input type="text" id="from-email" class="form-input" placeholder="your@email.com"></div>
                        <div class="tool-section"><h3>To</h3><input type="text" id="to-name" class="form-input" placeholder="Client Name" style="margin-bottom: 5px;"><input type="text" id="to-email" class="form-input" placeholder="client@email.com"></div>
                    </div>
                    <div class="tool-section">
                        <div class="grid" style="grid-template-columns: 1fr 1fr 1fr; gap: var(--space-3);">
                            <div><label>Invoice #</label><input type="text" id="invoice-num" class="form-input" value="001"></div>
                            <div><label>Date</label><input type="date" id="date" class="form-input"></div>
                            <div><label>Due Date</label><input type="date" id="due-date" class="form-input"></div>
                        </div>
                    </div>
                    <div class="tool-section">
                        <h3>Items</h3>
                        <div id="items-list"></div>
                        <button onclick="addItem()" class="btn btn-ghost btn-sm">+ Add Item</button>
                    </div>
                    <div class="tool-actions"><button id="generate" class="btn btn-primary">Generate Invoice PDF</button></div>
                </div>
                <script>
                    let itemCount = 0;
                    function addItem() {
                        const div = document.createElement('div');
                        div.className = 'grid';
                        div.style.cssText = 'grid-template-columns: 2fr 1fr 1fr 1fr; gap: var(--space-2); margin-bottom: var(--space-2);';
                        div.innerHTML = \`<input type="text" class="form-input item-desc" placeholder="Description"><input type="number" class="form-input item-qty" placeholder="Qty" value="1"><input type="number" class="form-input item-price" placeholder="Price" value="0"><input type="text" class="form-input item-total" placeholder="Total" readonly>\`;
                        document.getElementById('items-list').appendChild(div);
                        div.querySelectorAll('.item-qty, .item-price').forEach(inp => {
                            inp.addEventListener('input', () => {
                                const qty = parseFloat(div.querySelector('.item-qty').value) || 0;
                                const price = parseFloat(div.querySelector('.item-price').value) || 0;
                                div.querySelector('.item-total').value = (qty * price).toFixed(2);
                            });
                        });
                        itemCount++;
                    }
                    addItem();
                    document.getElementById('date').valueAsDate = new Date();
                    const due = new Date(); due.setDate(due.getDate() + 30);
                    document.getElementById('due-date').valueAsDate = due;
                    
                    document.getElementById('generate').addEventListener('click', () => {
                        const { jsPDF } = window.jspdf;
                        const doc = new jsPDF();
                        let y = 20;
                        doc.setFontSize(24); doc.text('INVOICE', 105, y, {align: 'center'}); y += 15;
                        doc.setFontSize(10);
                        doc.text('From: ' + document.getElementById('from-name').value, 20, y); y += 5;
                        doc.text(document.getElementById('from-email').value, 20, y); y += 10;
                        doc.text('To: ' + document.getElementById('to-name').value, 20, y); y += 5;
                        doc.text(document.getElementById('to-email').value, 20, y); y += 10;
                        doc.text('Invoice #: ' + document.getElementById('invoice-num').value, 20, y);
                        doc.text('Date: ' + document.getElementById('date').value, 105, y);
                        doc.text('Due: ' + document.getElementById('due-date').value, 160, y); y += 15;
                        
                        doc.setFont(undefined, 'bold');
                        doc.text('Description', 20, y); doc.text('Qty', 120, y); doc.text('Price', 145, y); doc.text('Total', 170, y); y += 7;
                        doc.setFont(undefined, 'normal');
                        
                        let total = 0;
                        document.querySelectorAll('#items-list > div').forEach(item => {
                            const desc = item.querySelector('.item-desc').value;
                            const qty = item.querySelector('.item-qty').value;
                            const price = item.querySelector('.item-price').value;
                            const itemTotal = parseFloat(item.querySelector('.item-total').value) || 0;
                            total += itemTotal;
                            doc.text(desc, 20, y); doc.text(qty, 120, y); doc.text('$' + price, 145, y); doc.text('$' + itemTotal.toFixed(2), 170, y); y += 7;
                        });
                        
                        y += 5;
                        doc.setFont(undefined, 'bold');
                        doc.text('TOTAL: $' + total.toFixed(2), 170, y, {align: 'right'});
                        doc.save('invoice.pdf');
                        Toast.success('Invoice generated!');
                    });
                </script>
        '''
    },
    'generator/citation-generator.html': {
        'title': 'Citation Generator - APA, MLA, Chicago Free',
        'desc': 'Free citation generator. Create citations in APA, MLA, Chicago formats. Perfect for students and researchers. Instant bibliography generation.',
        'content': '''
                <h1 class="tool-title">Citation Generator</h1>
                <p class="tool-description">Generate citations in APA, MLA, and Chicago formats.</p>
                <div class="tool-interface">
                    <div class="tool-section">
                        <label>Citation Style</label>
                        <select id="style" class="form-input"><option>APA</option><option>MLA</option><option>Chicago</option></select>
                        <div style="margin-top: var(--space-3);">
                            <div class="grid" style="grid-template-columns: 1fr 1fr; gap: var(--space-3);">
                                <div><label>Author(s)</label><input type="text" id="author" class="form-input" placeholder="Last, First"></div>
                                <div><label>Year</label><input type="number" id="year" class="form-input" placeholder="2024"></div>
                            </div>
                            <div style="margin-top: var(--space-2);"><label>Title</label><input type="text" id="title" class="form-input" placeholder="Article or Book Title"></div>
                            <div class="grid" style="grid-template-columns: 1fr 1fr; gap: var(--space-3); margin-top: var(--space-2);">
                                <div><label>Publication</label><input type="text" id="publication" class="form-input" placeholder="Journal/Publisher"></div>
                                <div><label>URL (optional)</label><input type="url" id="url" class="form-input" placeholder="https://..."></div>
                            </div>
                        </div>
                    </div>
                    <div class="tool-actions"><button id="generate" class="btn btn-primary">Generate Citation</button></div>
                    <div id="result" class="tool-section output-section" style="display:none;">
                        <div id="citation" style="padding: var(--space-4); background: var(--bg-tertiary); border-radius: var(--radius-lg); font-family: 'Times New Roman', serif; line-height: 1.8;"></div>
                        <button onclick="navigator.clipboard.writeText(document.getElementById('citation').textContent).then(() => Toast.success('Copied!'))" class="btn btn-ghost btn-sm" style="margin-top: var(--space-2);">Copy Citation</button>
                    </div>
                </div>
                <script>
                    document.getElementById('generate').addEventListener('click', () => {
                        const style = document.getElementById('style').value;
                        const author = document.getElementById('author').value || 'Author, A.';
                        const year = document.getElementById('year').value || '2024';
                        const title = document.getElementById('title').value || 'Title of Work';
                        const pub = document.getElementById('publication').value || 'Publisher';
                        const url = document.getElementById('url').value;
                        
                        let citation = '';
                        if(style === 'APA') {
                            citation = \`\${author} (\${year}). <i>\${title}</i>. \${pub}.\`;
                            if(url) citation += \` Retrieved from \${url}\`;
                        } else if(style === 'MLA') {
                            citation = \`\${author}. "<i>\${title}</i>." <i>\${pub}</i>, \${year}.\`;
                            if(url) citation += \` <\${url}>.\`;
                        } else {
                            citation = \`\${author}. <i>\${title}</i>. \${pub}, \${year}.\`;
                        }
                        
                        document.getElementById('citation').innerHTML = citation;
                        document.getElementById('result').style.display = 'block';
                    });
                </script>
        '''
    }
}

def main():
    for path, data in TOOLS.items():
        file_path = Path(f'./tools/{path}')
        file_path.parent.mkdir(parents=True, exist_ok=True)
        slug = path.split('/')[-1].replace('.html', '')
        cat = path.split('/')[0]
        schema = {"@context": "https://schema.org","@type": "SoftwareApplication","name": data['title'],"description": data['desc']}
        html = get_header(data['title'], data['desc'], slug, cat) + data['content'] + get_footer(__import__('json').dumps(schema))
        with open(file_path, 'w', encoding='utf-8') as f: f.write(html)
        print(f"Generated: {path}")

if __name__ == '__main__': main()
