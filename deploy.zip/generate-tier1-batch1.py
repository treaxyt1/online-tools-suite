#!/usr/bin/env python3
"""
Generate TIER 1 High-Priority Tools (Batch 1)
Tools: Percentage Calculator, QR Code Generator, Unit Converter, Age Calculator, Random Number Generator
"""

from pathlib import Path

def get_header(title, description, slug, category_path):
    return f'''<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title} | OnlineToolFree</title>
    <meta name="description" content="{description}">
    <link rel="canonical" href="https://onlinetoolfree.com/tools/{category_path}/{slug}.html">
    <link rel="stylesheet" href="../../css/design-system.css">
    <script src="../../js/tools.js"></script>
    <script src="../../js/ui.js"></script>
    <script src="../../js/app.js"></script>
</head>
<body>
    <header class="header"></header>
    <div class="tool-layout">
        <aside class="tool-sidebar" id="tool-sidebar"></aside>
        <main class="tool-main">
            <div class="tool-page" style="max-width: 1000px; margin: 0; padding: 0;">
'''

def get_footer(schema_json):
    return f'''
            </div>
        </main>
    </div>
    <button class="sidebar-toggle" id="sidebar-toggle">
        <svg class="icon" viewBox="0 0 24 24"><line x1="4" y1="12" x2="20" y2="12"/><line x1="4" y1="6" x2="20" y2="6"/><line x1="4" y1="18" x2="20" y2="18"/></svg>
    </button>
    <footer class="footer"></footer>
    <script type="application/ld+json">{schema_json}</script>
    <script>
        document.addEventListener('DOMContentLoaded', () => {{
            Components.renderHeader();
            Components.renderSidebar('tool-sidebar');
            Components.renderFooter();
            if (window.ThemeManager) ThemeManager.init();
        }});
    </script>
</body>
</html>'''

TOOLS = {
    'calculator/percentage-calculator.html': {
        'title': 'Percentage Calculator - Calculate Percentages Online Free',
        'desc': 'Free percentage calculator. Calculate percentage increase, decrease, difference, and more. Simple and accurate percentage calculations.',
        'content': '''
                <h1 class="tool-title">Percentage Calculator</h1>
                <p class="tool-description">Calculate percentages quickly and accurately.</p>
                <div class="tool-interface">
                    <div class="tool-section">
                        <h3>What is % of ?</h3>
                        <div class="grid" style="grid-template-columns: 1fr 1fr 1fr; gap: var(--space-3); align-items: end;">
                            <div><label>Percentage</label><input type="number" id="pct1" class="form-input" placeholder="10"></div>
                            <div><label>Of Value</label><input type="number" id="val1" class="form-input" placeholder="100"></div>
                            <div style="font-size: 1.5rem; font-weight: bold; color: var(--primary-600);" id="res1">= 0</div>
                        </div>
                    </div>
                    <div class="tool-section">
                        <h3>What % is of ?</h3>
                        <div class="grid" style="grid-template-columns: 1fr 1fr 1fr; gap: var(--space-3); align-items: end;">
                            <div><label>Value</label><input type="number" id="val2" class="form-input" placeholder="25"></div>
                            <div><label>Of Value</label><input type="number" id="val3" class="form-input" placeholder="100"></div>
                            <div style="font-size: 1.5rem; font-weight: bold; color: var(--primary-600);" id="res2">= 0%</div>
                        </div>
                    </div>
                    <div class="tool-section">
                        <h3>Percentage Increase/Decrease</h3>
                        <div class="grid" style="grid-template-columns: 1fr 1fr 1fr; gap: var(--space-3); align-items: end;">
                            <div><label>From</label><input type="number" id="from" class="form-input" placeholder="100"></div>
                            <div><label>To</label><input type="number" id="to" class="form-input" placeholder="150"></div>
                            <div style="font-size: 1.5rem; font-weight: bold; color: var(--success-600);" id="res3">= 0%</div>
                        </div>
                    </div>
                </div>
                <script>
                    function calc() {
                        const p1 = parseFloat(document.getElementById('pct1').value) || 0;
                        const v1 = parseFloat(document.getElementById('val1').value) || 0;
                        document.getElementById('res1').textContent = '= ' + ((p1/100) * v1).toFixed(2);
                        
                        const v2 = parseFloat(document.getElementById('val2').value) || 0;
                        const v3 = parseFloat(document.getElementById('val3').value) || 1;
                        document.getElementById('res2').textContent = '= ' + ((v2/v3)*100).toFixed(2) + '%';
                        
                        const from = parseFloat(document.getElementById('from').value) || 0;
                        const to = parseFloat(document.getElementById('to').value) || 0;
                        const change = ((to - from) / from) * 100;
                        document.getElementById('res3').textContent = '= ' + change.toFixed(2) + '%';
                        document.getElementById('res3').style.color = change >= 0 ? 'var(--success-600)' : 'var(--error-600)';
                    }
                    document.querySelectorAll('input').forEach(i => i.addEventListener('input', calc));
                </script>
        '''
    },
    'generator/qr-code.html': {
        'title': 'QR Code Generator - Create Custom QR Codes Free',
        'desc': 'Free QR code generator. Create QR codes for URLs, text, WiFi, vCards, and more. Download as PNG or SVG. No sign-up required.',
        'content': '''
                <h1 class="tool-title">QR Code Generator</h1>
                <p class="tool-description">Create custom QR codes instantly.</p>
                <script src="https://cdn.jsdelivr.net/npm/qrcode/build/qrcode.min.js"></script>
                <div class="tool-interface">
                    <div class="tool-section">
                        <label class="form-label">Enter Text or URL</label>
                        <textarea id="qr-text" class="form-input" rows="3" placeholder="https://example.com"></textarea>
                        <div class="grid" style="grid-template-columns: 1fr 1fr; gap: var(--space-3); margin-top: var(--space-3);">
                            <div><label>Size (px)</label><input type="number" id="qr-size" class="form-input" value="256" min="128" max="1024"></div>
                            <div><label>Color</label><input type="color" id="qr-color" class="form-input" value="#000000"></div>
                        </div>
                    </div>
                    <div class="tool-actions">
                        <button id="gen-qr" class="btn btn-primary">Generate QR Code</button>
                    </div>
                    <div class="tool-section output-section" style="text-align: center;">
                        <canvas id="qr-canvas" style="max-width: 100%; border: 1px solid var(--border-color); border-radius: var(--radius-lg);"></canvas>
                        <div style="margin-top: var(--space-4);">
                            <button id="dl-qr" class="btn btn-primary">Download PNG</button>
                        </div>
                    </div>
                </div>
                <script>
                    document.getElementById('gen-qr').addEventListener('click', () => {
                        const text = document.getElementById('qr-text').value || 'https://onlinetoolfree.com';
                        const size = parseInt(document.getElementById('qr-size').value);
                        const color = document.getElementById('qr-color').value;
                        const canvas = document.getElementById('qr-canvas');
                        QRCode.toCanvas(canvas, text, {width: size, color: {dark: color, light: '#ffffff'}}, (err) => {
                            if(err) Toast.error('Failed to generate QR code');
                            else Toast.success('QR code generated!');
                        });
                    });
                    document.getElementById('dl-qr').addEventListener('click', () => {
                        const canvas = document.getElementById('qr-canvas');
                        const link = document.createElement('a');
                        link.download = 'qrcode.png';
                        link.href = canvas.toDataURL();
                        link.click();
                    });
                    // Generate default QR on load
                    setTimeout(() => document.getElementById('gen-qr').click(), 500);
                </script>
        '''
    },
    'converter/unit-converter.html': {
        'title': 'Unit Converter - Convert Length, Weight, Temperature Free',
        'desc': 'Free unit converter. Convert between metric and imperial units. Length, weight, temperature, volume, area, and more. Instant conversion.',
        'content': '''
                <h1 class="tool-title">Unit Converter</h1>
                <p class="tool-description">Convert between different units of measurement.</p>
                <div class="tool-interface">
                    <div class="tool-section">
                        <label>Category</label>
                        <select id="category" class="form-input">
                            <option value="length">Length</option>
                            <option value="weight">Weight</option>
                            <option value="temperature">Temperature</option>
                            <option value="volume">Volume</option>
                        </select>
                    </div>
                    <div class="grid" style="grid-template-columns: 1fr 1fr; gap: var(--space-4);">
                        <div class="tool-section">
                            <label>From</label>
                            <input type="number" id="from-val" class="form-input" value="1">
                            <select id="from-unit" class="form-input" style="margin-top: var(--space-2);"></select>
                        </div>
                        <div class="tool-section">
                            <label>To</label>
                            <input type="number" id="to-val" class="form-input" readonly>
                            <select id="to-unit" class="form-input" style="margin-top: var(--space-2);"></select>
                        </div>
                    </div>
                </div>
                <script>
                    const units = {
                        length: {m: 1, km: 0.001, cm: 100, mm: 1000, mi: 0.000621371, yd: 1.09361, ft: 3.28084, in: 39.3701},
                        weight: {kg: 1, g: 1000, mg: 1000000, lb: 2.20462, oz: 35.274},
                        temperature: {c: 'base', f: (c) => c * 9/5 + 32, k: (c) => c + 273.15},
                        volume: {l: 1, ml: 1000, gal: 0.264172, qt: 1.05669, pt: 2.11338, cup: 4.22675}
                    };
                    
                    function updateUnits() {
                        const cat = document.getElementById('category').value;
                        const fromSel = document.getElementById('from-unit');
                        const toSel = document.getElementById('to-unit');
                        fromSel.innerHTML = toSel.innerHTML = Object.keys(units[cat]).map(u => `<option value="${u}">${u.toUpperCase()}</option>`).join('');
                        convert();
                    }
                    
                    function convert() {
                        const cat = document.getElementById('category').value;
                        const fromVal = parseFloat(document.getElementById('from-val').value) || 0;
                        const fromUnit = document.getElementById('from-unit').value;
                        const toUnit = document.getElementById('to-unit').value;
                        
                        let result;
                        if(cat === 'temperature') {
                            let celsius = fromUnit === 'c' ? fromVal : fromUnit === 'f' ? (fromVal - 32) * 5/9 : fromVal - 273.15;
                            result = toUnit === 'c' ? celsius : typeof units[cat][toUnit] === 'function' ? units[cat][toUnit](celsius) : celsius;
                        } else {
                            const base = fromVal / units[cat][fromUnit];
                            result = base * units[cat][toUnit];
                        }
                        
                        document.getElementById('to-val').value = result.toFixed(6);
                    }
                    
                    document.getElementById('category').addEventListener('change', updateUnits);
                    document.getElementById('from-val').addEventListener('input', convert);
                    document.getElementById('from-unit').addEventListener('change', convert);
                    document.getElementById('to-unit').addEventListener('change', convert);
                    updateUnits();
                </script>
        '''
    },
    'calculator/age-calculator.html': {
        'title': 'Age Calculator - Calculate Your Exact Age Online Free',
        'desc': 'Free age calculator. Calculate your exact age in years, months, days, hours, and minutes. Find out how old you are today.',
        'content': '''
                <h1 class="tool-title">Age Calculator</h1>
                <p class="tool-description">Calculate your exact age from your birth date.</p>
                <div class="tool-interface">
                    <div class="tool-section">
                        <label class="form-label">Date of Birth</label>
                        <input type="date" id="dob" class="form-input" style="max-width: 300px;">
                    </div>
                    <div class="tool-actions">
                        <button id="calc-age" class="btn btn-primary">Calculate Age</button>
                    </div>
                    <div id="age-result" class="tool-section output-section" style="display:none;">
                        <div class="grid" style="grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: var(--space-4);">
                            <div style="text-align: center; padding: var(--space-4); background: var(--bg-tertiary); border-radius: var(--radius-lg);">
                                <div style="font-size: 2rem; font-weight: bold; color: var(--primary-600);" id="years">0</div>
                                <div style="font-size: var(--text-sm); color: var(--text-secondary);">Years</div>
                            </div>
                            <div style="text-align: center; padding: var(--space-4); background: var(--bg-tertiary); border-radius: var(--radius-lg);">
                                <div style="font-size: 2rem; font-weight: bold; color: var(--primary-600);" id="months">0</div>
                                <div style="font-size: var(--text-sm); color: var(--text-secondary);">Months</div>
                            </div>
                            <div style="text-align: center; padding: var(--space-4); background: var(--bg-tertiary); border-radius: var(--radius-lg);">
                                <div style="font-size: 2rem; font-weight: bold; color: var(--primary-600);" id="days">0</div>
                                <div style="font-size: var(--text-sm); color: var(--text-secondary);">Days</div>
                            </div>
                        </div>
                        <div style="margin-top: var(--space-4); padding: var(--space-4); background: var(--bg-tertiary); border-radius: var(--radius-lg);">
                            <p><strong>Total:</strong> <span id="total-days">0</span> days or <span id="total-hours">0</span> hours</p>
                            <p><strong>Next Birthday:</strong> <span id="next-bday">-</span></p>
                        </div>
                    </div>
                </div>
                <script>
                    document.getElementById('calc-age').addEventListener('click', () => {
                        const dob = new Date(document.getElementById('dob').value);
                        if(!dob || isNaN(dob)) return Toast.error('Please enter a valid date');
                        
                        const now = new Date();
                        let years = now.getFullYear() - dob.getFullYear();
                        let months = now.getMonth() - dob.getMonth();
                        let days = now.getDate() - dob.getDate();
                        
                        if(days < 0) { months--; days += new Date(now.getFullYear(), now.getMonth(), 0).getDate(); }
                        if(months < 0) { years--; months += 12; }
                        
                        const totalDays = Math.floor((now - dob) / (1000 * 60 * 60 * 24));
                        const totalHours = Math.floor((now - dob) / (1000 * 60 * 60));
                        
                        const nextBday = new Date(now.getFullYear(), dob.getMonth(), dob.getDate());
                        if(nextBday < now) nextBday.setFullYear(nextBday.getFullYear() + 1);
                        const daysToNext = Math.ceil((nextBday - now) / (1000 * 60 * 60 * 24));
                        
                        document.getElementById('years').textContent = years;
                        document.getElementById('months').textContent = months;
                        document.getElementById('days').textContent = days;
                        document.getElementById('total-days').textContent = totalDays.toLocaleString();
                        document.getElementById('total-hours').textContent = totalHours.toLocaleString();
                        document.getElementById('next-bday').textContent = `${daysToNext} days (${nextBday.toLocaleDateString()})`;
                        document.getElementById('age-result').style.display = 'block';
                    });
                </script>
        '''
    },
    'generator/random-number.html': {
        'title': 'Random Number Generator - Generate Random Numbers Free',
        'desc': 'Free random number generator. Generate random numbers with custom range, quantity, and options. Perfect for games, lottery, and more.',
        'content': '''
                <h1 class="tool-title">Random Number Generator</h1>
                <p class="tool-description">Generate random numbers with custom settings.</p>
                <div class="tool-interface">
                    <div class="tool-section">
                        <div class="grid" style="grid-template-columns: 1fr 1fr 1fr; gap: var(--space-3);">
                            <div><label>Minimum</label><input type="number" id="min" class="form-input" value="1"></div>
                            <div><label>Maximum</label><input type="number" id="max" class="form-input" value="100"></div>
                            <div><label>Quantity</label><input type="number" id="qty" class="form-input" value="1" min="1" max="100"></div>
                        </div>
                        <div style="margin-top: var(--space-3);">
                            <label><input type="checkbox" id="unique"> Unique numbers (no duplicates)</label>
                        </div>
                    </div>
                    <div class="tool-actions">
                        <button id="gen-num" class="btn btn-primary">Generate Numbers</button>
                    </div>
                    <div id="num-result" class="tool-section output-section" style="display:none;">
                        <div id="numbers" style="display: flex; flex-wrap: wrap; gap: var(--space-2); justify-content: center;"></div>
                    </div>
                </div>
                <script>
                    document.getElementById('gen-num').addEventListener('click', () => {
                        const min = parseInt(document.getElementById('min').value);
                        const max = parseInt(document.getElementById('max').value);
                        const qty = parseInt(document.getElementById('qty').value);
                        const unique = document.getElementById('unique').checked;
                        
                        if(min >= max) return Toast.error('Min must be less than max');
                        if(unique && (max - min + 1) < qty) return Toast.error('Range too small for unique numbers');
                        
                        const numbers = [];
                        while(numbers.length < qty) {
                            const num = Math.floor(Math.random() * (max - min + 1)) + min;
                            if(!unique || !numbers.includes(num)) numbers.push(num);
                        }
                        
                        document.getElementById('numbers').innerHTML = numbers.map(n => 
                            `<div style="padding: var(--space-3) var(--space-5); background: var(--primary-600); color: white; border-radius: var(--radius-lg); font-size: 1.5rem; font-weight: bold;">${n}</div>`
                        ).join('');
                        document.getElementById('num-result').style.display = 'block';
                    });
                </script>
        '''
    }
}

def main():
    for path, data in TOOLS.items():
        file_path = Path(f'./tools/{path}')
        file_path.parent.mkdir(parents=True, exist_ok=True)
        slug = path.split('/')[-1].replace('.html', '')
        cat = path.split('/')[0]
        schema = {"@context": "https://schema.org","@type": "SoftwareApplication","name": data['title'],"description": data['desc']}
        html = get_header(data['title'], data['desc'], slug, cat) + data['content'] + get_footer(__import__('json').dumps(schema))
        with open(file_path, 'w', encoding='utf-8') as f: f.write(html)
        print(f"Generated: {path}")

if __name__ == '__main__': main()
