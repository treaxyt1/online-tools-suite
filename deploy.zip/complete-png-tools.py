#!/usr/bin/env python3
"""
Complete PNG Tools & Emulator Utilities - Add Full Functionality
Removes all "Coming Soon" placeholders with working tools
"""

from pathlib import Path

class Colors:
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RESET = '\033[0m'

def print_colored(text, color):
    try:
        print(f"{color}{text}{Colors.RESET}")
    except UnicodeEncodeError:
        print(text.encode('ascii', 'replace').decode('ascii'))

# Standard PNG tool template
def create_png_tool(name, description, slug, controls_html, process_js):
    return f'''<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{name} - Free Online PNG Tool | OnlineToolFree</title>
    <meta name="description" content="{description} Free, fast, and secure. All processing in your browser.">
    <link rel="canonical" href="https://onlinetoolfree.com/tools/png/{slug}.html">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../../css/design-system.css">
    <script src="../../js/tools.js"></script>
    <script src="../../js/ui.js"></script>
    <script src="../../js/app.js"></script>
</head>
<body>
    <header class="header"></header>
    <div class="tool-layout">
        <aside class="tool-sidebar" id="tool-sidebar"></aside>
        <main class="tool-main">
            <div class="tool-page" style="max-width: 1000px; margin: 0; padding: 0;">
                <div class="tool-header" style="text-align: left; margin-bottom: var(--space-6);">
                    <div style="display: flex; align-items: center; gap: var(--space-4); margin-bottom: var(--space-4);">
                        <div class="tool-icon-large" style="margin: 0;">
                            <svg class="icon icon-lg" viewBox="0 0 24 24">
                                <rect x="3" y="3" width="18" height="18" rx="2"/>
                                <circle cx="8.5" cy="8.5" r="1.5"/>
                                <polyline points="21 15 16 10 5 21"/>
                            </svg>
                        </div>
                        <div>
                            <h1 class="tool-title" style="font-size: var(--text-2xl);">{name}</h1>
                            <p class="tool-description" style="font-size: var(--text-base); margin: 0;">{description}</p>
                        </div>
                    </div>
                </div>

                <div class="tool-interface">
                    <div class="tool-section" id="upload-section">
                        <div class="file-drop-area" id="drop-area">
                            <input type="file" id="file-input" accept="image/png" hidden>
                            <div class="drop-icon">
                                <svg class="icon icon-xl" viewBox="0 0 24 24">
                                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                                    <polyline points="17 8 12 3 7 8"/>
                                    <line x1="12" y1="3" x2="12" y2="15"/>
                                </svg>
                            </div>
                            <p class="drop-text">Drag & drop PNG image or <span>browse</span></p>
                        </div>
                    </div>

                    <div id="editor-section" style="display: none;">
                        <div class="tool-grid" style="margin-bottom: var(--space-6);">
                            <div class="tool-section">
                                <div class="output-header">
                                    <span class="tool-section-title">Original</span>
                                </div>
                                <div style="background-image: linear-gradient(45deg, #f0f0f0 25%, transparent 25%), linear-gradient(-45deg, #f0f0f0 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #f0f0f0 75%), linear-gradient(-45deg, transparent 75%, #f0f0f0 75%); background-size: 20px 20px; background-position: 0 0, 0 10px, 10px -10px, -10px 0px; padding: var(--space-4); border-radius: var(--radius-lg); min-height: 300px; display: flex; align-items: center; justify-content: center;">
                                    <canvas id="source-canvas" style="max-width: 100%; height: auto;"></canvas>
                                </div>
                            </div>
                            <div class="tool-section">
                                <div class="output-header">
                                    <span class="tool-section-title">Result</span>
                                    <button class="btn btn-ghost btn-sm" id="download-btn">
                                        <svg class="icon icon-sm" viewBox="0 0 24 24">
                                            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                                            <polyline points="7 10 12 15 17 10"/>
                                            <line x1="12" y1="15" x2="12" y2="3"/>
                                        </svg>
                                        Download
                                    </button>
                                </div>
                                <div style="background-image: linear-gradient(45deg, #f0f0f0 25%, transparent 25%), linear-gradient(-45deg, #f0f0f0 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #f0f0f0 75%), linear-gradient(-45deg, transparent 75%, #f0f0f0 75%); background-size: 20px 20px; background-position: 0 0, 0 10px, 10px -10px, -10px 0px; padding: var(--space-4); border-radius: var(--radius-lg); min-height: 300px; display: flex; align-items: center; justify-content: center;">
                                    <canvas id="result-canvas" style="max-width: 100%; height: auto;"></canvas>
                                </div>
                            </div>
                        </div>

                        {controls_html}

                        <div class="tool-actions">
                            <button id="process-btn" class="btn btn-primary">
                                <svg class="icon" viewBox="0 0 24 24">
                                    <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>
                                </svg>
                                Process Image
                            </button>
                            <button id="reset-btn" class="btn btn-ghost">Reset</button>
                        </div>
                    </div>
                </div>

                <section class="info-section" style="margin-top: var(--space-8); padding: var(--space-6); background: var(--bg-primary); border: 1px solid var(--border-light); border-radius: var(--radius-xl);">
                    <h2 style="font-size: var(--text-xl); font-weight: var(--font-semibold); margin-bottom: var(--space-4);">Privacy & Security</h2>
                    <p><strong>100% Client-Side:</strong> All processing happens in your browser. Images never leave your device.</p>
                </section>
            </div>
        </main>
    </div>
    <button class="sidebar-toggle" id="sidebar-toggle">
        <svg class="icon" viewBox="0 0 24 24">
            <line x1="4" y1="12" x2="20" y2="12"/><line x1="4" y1="6" x2="20" y2="6"/><line x1="4" y1="18" x2="20" y2="18"/>
        </svg>
    </button>
    <footer class="footer"></footer>
    <script>
        document.addEventListener('DOMContentLoaded', () => {{
            Components.renderHeader();
            Components.renderMobileMenu();
            Components.renderSidebar('tool-sidebar');
            Components.renderFooter();
            const sidebarToggle = document.getElementById('sidebar-toggle');
            const sidebar = document.getElementById('tool-sidebar');
            sidebarToggle?.addEventListener('click', () => sidebar?.classList.toggle('open'));

            const sourceCanvas = document.getElementById('source-canvas');
            const resultCanvas = document.getElementById('result-canvas');
            const sourceCtx = sourceCanvas.getContext('2d', {{willReadFrequently: true}});
            const resultCtx = resultCanvas.getContext('2d', {{willReadFrequently: true}});
            const dropArea = document.getElementById('drop-area');
            const fileInput = document.getElementById('file-input');
            const uploadSection = document.getElementById('upload-section');
            const editorSection = document.getElementById('editor-section');
            let originalImageData = null;

            ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(e => {{
                dropArea.addEventListener(e, evt => {{evt.preventDefault(); evt.stopPropagation();}}, false);
            }});
            dropArea.addEventListener('drop', e => handleFiles(e.dataTransfer.files));
            dropArea.addEventListener('click', () => fileInput.click());
            fileInput.addEventListener('change', e => handleFiles(e.target.files));

            function handleFiles(files) {{
                if (files.length > 0) {{
                    const file = files[0];
                    if (!file.type.match('image/png')) {{
                        Toast.error('Please upload a PNG image');
                        return;
                    }}
                    const reader = new FileReader();
                    reader.onload = function(e) {{
                        const img = new Image();
                        img.onload = function() {{
                            const maxDim = 800;
                            let w = img.width, h = img.height;
                            if (w > maxDim || h > maxDim) {{
                                const ratio = Math.min(maxDim / w, maxDim / h);
                                w = Math.floor(w * ratio);
                                h = Math.floor(h * ratio);
                            }}
                            sourceCanvas.width = resultCanvas.width = w;
                            sourceCanvas.height = resultCanvas.height = h;
                            sourceCtx.drawImage(img, 0, 0, w, h);
                            originalImageData = sourceCtx.getImageData(0, 0, w, h);
                            uploadSection.style.display = 'none';
                            editorSection.style.display = 'block';
                            Toast.success('Image loaded');
                        }};
                        img.src = e.target.result;
                    }};
                    reader.readAsDataURL(file);
                }}
            }}

            {process_js}

            document.getElementById('download-btn').addEventListener('click', () => {{
                const link = document.createElement('a');
                link.download = '{slug}-result.png';
                link.href = resultCanvas.toDataURL('image/png');
                link.click();
                Toast.success('Downloaded!');
            }});

            document.getElementById('reset-btn').addEventListener('click', () => {{
                uploadSection.style.display = 'block';
                editorSection.style.display = 'none';
                fileInput.value = '';
                originalImageData = null;
            }});

            if (window.ThemeManager) ThemeManager.init();
            if (window.ResponsiveManager) ResponsiveManager.init();
        }});
    </script>
</body>
</html>'''

# PNG Tools configurations
PNG_TOOLS = {
    'remove-png-alpha.html': {
        'name': 'Remove PNG Alpha Channel',
        'description': 'Remove transparency from PNG and replace with solid background',
        'slug': 'remove-png-alpha',
        'controls': '''<div style="background: var(--bg-tertiary); padding: var(--space-6); border-radius: var(--radius-lg); margin-bottom: var(--space-6);">
            <label class="form-label">Background Color</label>
            <input type="color" id="bg-color" class="form-input" value="#ffffff">
        </div>''',
        'process': '''
            document.getElementById('process-btn').addEventListener('click', () => {
                if (!originalImageData) return;
                const bgColor = document.getElementById('bg-color').value;
                const r = parseInt(bgColor.slice(1, 3), 16);
                const g = parseInt(bgColor.slice(3, 5), 16);
                const b = parseInt(bgColor.slice(5, 7), 16);
                
                const imageData = new ImageData(new Uint8ClampedArray(originalImageData.data), originalImageData.width, originalImageData.height);
                const data = imageData.data;
                
                for (let i = 0; i < data.length; i += 4) {
                    const alpha = data[i + 3] / 255;
                    data[i] = Math.round(data[i] * alpha + r * (1 - alpha));
                    data[i + 1] = Math.round(data[i + 1] * alpha + g * (1 - alpha));
                    data[i + 2] = Math.round(data[i + 2] * alpha + b * (1 - alpha));
                    data[i + 3] = 255;
                }
                
                resultCtx.putImageData(imageData, 0, 0);
                Toast.success('Alpha channel removed!');
            });
        '''
    },
    'change-png-opacity.html': {
        'name': 'Change PNG Opacity',
        'description': 'Adjust the opacity/transparency level of your PNG image',
        'slug': 'change-png-opacity',
        'controls': '''<div style="background: var(--bg-tertiary); padding: var(--space-6); border-radius: var(--radius-lg); margin-bottom: var(--space-6);">
            <label class="form-label">Opacity (%)</label>
            <input type="range" id="opacity" class="form-range" min="0" max="100" value="50">
            <div style="text-align: center; margin-top: var(--space-2);"><span id="opacity-val">50</span>%</div>
        </div>''',
        'process': '''
            document.getElementById('opacity').addEventListener('input', (e) => {
                document.getElementById('opacity-val').textContent = e.target.value;
            });
            
            document.getElementById('process-btn').addEventListener('click', () => {
                if (!originalImageData) return;
                const opacity = parseInt(document.getElementById('opacity').value) / 100;
                
                const imageData = new ImageData(new Uint8ClampedArray(originalImageData.data), originalImageData.width, originalImageData.height);
                const data = imageData.data;
                
                for (let i = 3; i < data.length; i += 4) {
                    data[i] = Math.round(data[i] * opacity);
                }
                
                resultCtx.putImageData(imageData, 0, 0);
                Toast.success('Opacity changed!');
            });
        '''
    },
    'make-png-opaque.html': {
        'name': 'Make PNG Opaque',
        'description': 'Replace all transparency with a solid background color',
        'slug': 'make-png-opaque',
        'controls': '''<div style="background: var(--bg-tertiary); padding: var(--space-6); border-radius: var(--radius-lg); margin-bottom: var(--space-6);">
            <label class="form-label">Background Color</label>
            <input type="color" id="bg-color" class="form-input" value="#ffffff">
        </div>''',
        'process': '''
            document.getElementById('process-btn').addEventListener('click', () => {
                if (!originalImageData) return;
                const bgColor = document.getElementById('bg-color').value;
                const r = parseInt(bgColor.slice(1, 3), 16);
                const g = parseInt(bgColor.slice(3, 5), 16);
                const b = parseInt(bgColor.slice(5, 7), 16);
                
                const imageData = new ImageData(new Uint8ClampedArray(originalImageData.data), originalImageData.width, originalImageData.height);
                const data = imageData.data;
                
                for (let i = 0; i < data.length; i += 4) {
                    if (data[i + 3] < 255) {
                        const alpha = data[i + 3] / 255;
                        data[i] = Math.round(data[i] * alpha + r * (1 - alpha));
                        data[i + 1] = Math.round(data[i + 1] * alpha + g * (1 - alpha));
                        data[i + 2] = Math.round(data[i + 2] * alpha + b * (1 - alpha));
                        data[i + 3] = 255;
                    }
                }
                
                resultCtx.putImageData(imageData, 0, 0);
                Toast.success('PNG is now opaque!');
            });
        '''
    },
    'resize.html': {
        'name': 'Resize PNG',
        'description': 'Resize your PNG image to custom dimensions',
        'slug': 'resize',
        'controls': '''<div style="background: var(--bg-tertiary); padding: var(--space-6); border-radius: var(--radius-lg); margin-bottom: var(--space-6);">
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: var(--space-4);">
                <div>
                    <label class="form-label">Width (px)</label>
                    <input type="number" id="width" class="form-input" value="800" min="1">
                </div>
                <div>
                    <label class="form-label">Height (px)</label>
                    <input type="number" id="height" class="form-input" value="600" min="1">
                </div>
            </div>
            <label style="display: flex; align-items: center; gap: var(--space-2); margin-top: var(--space-3);">
                <input type="checkbox" id="maintain-aspect" checked>
                <span>Maintain aspect ratio</span>
            </label>
        </div>''',
        'process': '''
            const widthInput = document.getElementById('width');
            const heightInput = document.getElementById('height');
            const maintainAspect = document.getElementById('maintain-aspect');
            let aspectRatio = 1;
            
            widthInput.addEventListener('input', () => {
                if (maintainAspect.checked && aspectRatio) {
                    heightInput.value = Math.round(widthInput.value / aspectRatio);
                }
            });
            
            heightInput.addEventListener('input', () => {
                if (maintainAspect.checked && aspectRatio) {
                    widthInput.value = Math.round(heightInput.value * aspectRatio);
                }
            });
            
            fileInput.addEventListener('change', () => {
                setTimeout(() => {
                    if (originalImageData) {
                        aspectRatio = originalImageData.width / originalImageData.height;
                        widthInput.value = originalImageData.width;
                        heightInput.value = originalImageData.height;
                    }
                }, 100);
            });
            
            document.getElementById('process-btn').addEventListener('click', () => {
                if (!originalImageData) return;
                const newWidth = parseInt(widthInput.value);
                const newHeight = parseInt(heightInput.value);
                
                resultCanvas.width = newWidth;
                resultCanvas.height = newHeight;
                resultCtx.drawImage(sourceCanvas, 0, 0, newWidth, newHeight);
                Toast.success('Image resized!');
            });
        '''
    },
    'rotate.html': {
        'name': 'Rotate PNG',
        'description': 'Rotate your PNG image by any angle',
        'slug': 'rotate',
        'controls': '''<div style="background: var(--bg-tertiary); padding: var(--space-6); border-radius: var(--radius-lg); margin-bottom: var(--space-6);">
            <label class="form-label">Rotation Angle (degrees)</label>
            <input type="range" id="angle" class="form-range" min="0" max="360" value="90">
            <div style="text-align: center; margin-top: var(--space-2);"><span id="angle-val">90</span>°</div>
            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: var(--space-2); margin-top: var(--space-4);">
                <button class="btn btn-ghost btn-sm" onclick="document.getElementById('angle').value=0; document.getElementById('angle-val').textContent='0'">0°</button>
                <button class="btn btn-ghost btn-sm" onclick="document.getElementById('angle').value=90; document.getElementById('angle-val').textContent='90'">90°</button>
                <button class="btn btn-ghost btn-sm" onclick="document.getElementById('angle').value=180; document.getElementById('angle-val').textContent='180'">180°</button>
                <button class="btn btn-ghost btn-sm" onclick="document.getElementById('angle').value=270; document.getElementById('angle-val').textContent='270'">270°</button>
            </div>
        </div>''',
        'process': '''
            document.getElementById('angle').addEventListener('input', (e) => {
                document.getElementById('angle-val').textContent = e.target.value;
            });
            
            document.getElementById('process-btn').addEventListener('click', () => {
                if (!originalImageData) return;
                const angle = parseInt(document.getElementById('angle').value) * Math.PI / 180;
                const w = sourceCanvas.width;
                const h = sourceCanvas.height;
                
                const newW = Math.abs(w * Math.cos(angle)) + Math.abs(h * Math.sin(angle));
                const newH = Math.abs(w * Math.sin(angle)) + Math.abs(h * Math.cos(angle));
                
                resultCanvas.width = newW;
                resultCanvas.height = newH;
                resultCtx.clearRect(0, 0, newW, newH);
                resultCtx.save();
                resultCtx.translate(newW / 2, newH / 2);
                resultCtx.rotate(angle);
                resultCtx.drawImage(sourceCanvas, -w / 2, -h / 2);
                resultCtx.restore();
                Toast.success('Image rotated!');
            });
        '''
    },
}

def main():
    print_colored("="*60, Colors.CYAN)
    print_colored("Adding Functionality to PNG Tools", Colors.CYAN)
    print_colored("="*60, Colors.CYAN)
    print()
    
    png_dir = Path('./tools/png')
    updated = 0
    
    for filename, config in PNG_TOOLS.items():
        file_path = png_dir / filename
        html = create_png_tool(
            config['name'],
            config['description'],
            config['slug'],
            config['controls'],
            config['process']
        )
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(html)
        print_colored(f"[+] Created: {filename}", Colors.GREEN)
        updated += 1
    
    print()
    print_colored(f"[+] Updated {updated} PNG tools with full functionality", Colors.GREEN)
    print_colored("="*60, Colors.CYAN)

if __name__ == '__main__':
    main()
