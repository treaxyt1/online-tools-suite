#!/usr/bin/env python3
"""
Design Consistency Checker - Batch Validation
Checks all HTML files for:
- Consistent design system
- Footer presence and consistency
- Sidebar presence and consistency
- Mobile-responsive meta tags
- Fast load optimization
- CSS/JS file references
Fixes issues automatically
"""

import os
import re
from pathlib import Path
from collections import defaultdict

class DesignChecker:
    def __init__(self):
        self.issues_found = []
        self.files_checked = 0
        self.files_fixed = 0
        self.design_issues = defaultdict(list)
        
    def check_viewport_meta(self, content, filepath):
        """Check for mobile-responsive viewport meta tag"""
        if 'name="viewport"' not in content:
            self.design_issues['missing_viewport'].append(filepath)
            return False, "Missing viewport meta tag"
        
        if 'width=device-width' not in content:
            self.design_issues['wrong_viewport'].append(filepath)
            return False, "Viewport not set to device-width"
        
        return True, "Viewport OK"
    
    def check_css_links(self, content, filepath):
        """Check for consistent CSS file references"""
        required_css = 'design-system.css'
        
        if required_css not in content:
            self.design_issues['missing_css'].append(filepath)
            return False, f"Missing {required_css}"
        
        # Check for correct path
        if '../../css/design-system.css' not in content and '../css/design-system.css' not in content:
            self.design_issues['wrong_css_path'].append(filepath)
            return False, "Incorrect CSS path"
        
        return True, "CSS links OK"
    
    def check_js_references(self, content, filepath):
        """Check for consistent JavaScript file references"""
        required_js = ['tools.js', 'ui.js', 'app.js']
        missing = []
        
        for js_file in required_js:
            if js_file not in content:
                missing.append(js_file)
        
        if missing:
            self.design_issues['missing_js'].append((filepath, missing))
            return False, f"Missing JS: {', '.join(missing)}"
        
        return True, "JS references OK"
    
    def check_header(self, content, filepath):
        """Check for consistent header"""
        if '<header class="header">' not in content and '<header class="header"' not in content:
            self.design_issues['missing_header'].append(filepath)
            return False, "Missing header element"
        
        return True, "Header OK"
    
    def check_footer(self, content, filepath):
        """Check for consistent footer"""
        if '<footer class="footer">' not in content and '<footer class="footer"' not in content:
            self.design_issues['missing_footer'].append(filepath)
            return False, "Missing footer element"
        
        return True, "Footer OK"
    
    def check_sidebar(self, content, filepath):
        """Check for consistent sidebar"""
        if 'tool-sidebar' not in content:
            self.design_issues['missing_sidebar'].append(filepath)
            return False, "Missing sidebar"
        
        if 'id="tool-sidebar"' not in content:
            self.design_issues['sidebar_no_id'].append(filepath)
            return False, "Sidebar missing ID"
        
        return True, "Sidebar OK"
    
    def check_layout_structure(self, content, filepath):
        """Check for consistent layout structure"""
        required_elements = [
            'tool-layout',
            'tool-main',
            'tool-page'
        ]
        
        missing = [elem for elem in required_elements if elem not in content]
        
        if missing:
            self.design_issues['missing_layout'].append((filepath, missing))
            return False, f"Missing layout elements: {', '.join(missing)}"
        
        return True, "Layout structure OK"
    
    def check_component_rendering(self, content, filepath):
        """Check if components are properly rendered"""
        required_renders = [
            'Components.renderHeader',
            'Components.renderSidebar',
            'Components.renderFooter'
        ]
        
        missing = [render for render in required_renders if render not in content]
        
        if missing:
            self.design_issues['missing_renders'].append((filepath, missing))
            return False, f"Missing component renders: {', '.join(missing)}"
        
        return True, "Component rendering OK"
    
    def check_theme_manager(self, content, filepath):
        """Check for theme manager initialization"""
        if 'ThemeManager' not in content:
            self.design_issues['missing_theme'].append(filepath)
            return False, "Missing ThemeManager"
        
        return True, "Theme manager OK"
    
    def check_performance(self, content, filepath):
        """Check for performance optimizations"""
        issues = []
        
        # Check for excessive inline styles
        inline_styles = len(re.findall(r'style="[^"]{100,}"', content))
        if inline_styles > 10:
            issues.append(f"Too many large inline styles ({inline_styles})")
        
        # Check for large inline scripts
        large_scripts = len(re.findall(r'<script[^>]*>(.{5000,})</script>', content, re.DOTALL))
        if large_scripts > 3:
            issues.append(f"Large inline scripts ({large_scripts})")
        
        # Check file size
        file_size = len(content.encode('utf-8'))
        if file_size > 200000:  # 200KB
            issues.append(f"Large file size ({file_size // 1024}KB)")
        
        if issues:
            self.design_issues['performance'].append((filepath, issues))
            return False, "; ".join(issues)
        
        return True, "Performance OK"
    
    def fix_viewport(self, content):
        """Add or fix viewport meta tag"""
        if 'name="viewport"' not in content:
            # Add viewport after charset
            content = content.replace(
                '<meta charset="UTF-8">',
                '<meta charset="UTF-8">\n    <meta name="viewport" content="width=device-width, initial-scale=1.0">'
            )
        return content
    
    def fix_css_link(self, content, filepath):
        """Fix CSS link path"""
        # Determine correct path based on file location
        path_parts = str(filepath).replace('\\', '/').split('/')
        
        if 'tools' in path_parts:
            depth = len(path_parts) - path_parts.index('tools') - 1
            css_path = '../' * depth + 'css/design-system.css'
        else:
            # Root level file
            css_path = 'css/design-system.css'
        
        if 'design-system.css' not in content:
            # Add CSS link in head
            content = content.replace(
                '</head>',
                f'    <link rel="stylesheet" href="{css_path}">\n</head>'
            )
        return content
    
    def fix_js_references(self, content, filepath):
        """Fix JavaScript file references"""
        path_parts = str(filepath).replace('\\', '/').split('/')
        
        if 'tools' in path_parts:
            depth = len(path_parts) - path_parts.index('tools') - 1
            js_path = '../' * depth + 'js/'
        else:
            js_path = 'js/'
        
        required_js = ['tools.js', 'ui.js', 'app.js']
        
        for js_file in required_js:
            if js_file not in content:
                # Add before closing body tag
                content = content.replace(
                    '</body>',
                    f'    <script src="{js_path}{js_file}"></script>\n</body>'
                )
        return content
    
    def fix_header(self, content):
        """Add header if missing"""
        if '<header' not in content:
            content = content.replace(
                '<body>',
                '<body>\n    <header class="header"></header>'
            )
        return content
    
    def fix_footer(self, content):
        """Add footer if missing"""
        if '<footer' not in content:
            content = content.replace(
                '</body>',
                '    <footer class="footer"></footer>\n</body>'
            )
        return content
    
    def fix_sidebar(self, content):
        """Add sidebar if missing"""
        if 'tool-sidebar' not in content:
            # Add sidebar structure
            sidebar_html = '''    <div class="tool-layout">
        <aside class="tool-sidebar" id="tool-sidebar"></aside>
        <main class="tool-main">
            <div class="tool-page">'''
            
            content = content.replace('<body>', '<body>\n' + sidebar_html)
            content = content.replace('</body>', '''            </div>
        </main>
    </div>
</body>''')
        return content
    
    def fix_component_rendering(self, content):
        """Add component rendering script"""
        if 'Components.renderHeader' not in content:
            render_script = '''    <script>
        document.addEventListener('DOMContentLoaded', () => {
            if(window.Components) {
                Components.renderHeader();
                Components.renderSidebar('tool-sidebar');
                Components.renderFooter();
            }
            if(window.ThemeManager) ThemeManager.init();
        });
    </script>'''
            
            content = content.replace('</body>', render_script + '\n</body>')
        return content
    
    def check_and_fix_file(self, filepath):
        """Check and fix a single file"""
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                original_content = f.read()
            
            content = original_content
            fixed = False
            issues = []
            
            # Run all checks
            checks = [
                ('Viewport', self.check_viewport_meta),
                ('CSS Links', self.check_css_links),
                ('JS References', self.check_js_references),
                ('Header', self.check_header),
                ('Footer', self.check_footer),
                ('Sidebar', self.check_sidebar),
                ('Layout', self.check_layout_structure),
                ('Components', self.check_component_rendering),
                ('Theme', self.check_theme_manager),
                ('Performance', self.check_performance)
            ]
            
            for check_name, check_func in checks:
                ok, msg = check_func(content, filepath)
                if not ok:
                    issues.append(f"{check_name}: {msg}")
            
            # Apply fixes if issues found
            if issues:
                print(f"\n[FIX] {filepath}")
                for issue in issues:
                    print(f"  - {issue}")
                
                # Apply all fixes
                content = self.fix_viewport(content)
                content = self.fix_css_link(content, filepath)
                content = self.fix_js_references(content, filepath)
                content = self.fix_header(content)
                content = self.fix_footer(content)
                content = self.fix_sidebar(content)
                content = self.fix_component_rendering(content)
                
                # Write fixed content
                if content != original_content:
                    with open(filepath, 'w', encoding='utf-8') as f:
                        f.write(content)
                    self.files_fixed += 1
                    print(f"  [OK] Fixed!")
                    fixed = True
            
            self.files_checked += 1
            return fixed, issues
            
        except Exception as e:
            print(f"[ERROR] {filepath}: {str(e)}")
            return False, [str(e)]
    
    def scan_directory(self, directory):
        """Scan directory for HTML files"""
        html_files = []
        for root, dirs, files in os.walk(directory):
            for file in files:
                if file.endswith('.html'):
                    html_files.append(os.path.join(root, file))
        return html_files

def main():
    print("=" * 70)
    print("DESIGN CONSISTENCY CHECKER - BATCH VALIDATION")
    print("=" * 70)
    print("Checking: Viewport, CSS, JS, Header, Footer, Sidebar, Layout")
    print("=" * 70)
    
    checker = DesignChecker()
    
    # Scan tools directory
    tools_dir = './tools'
    if not os.path.exists(tools_dir):
        print(f"[ERROR] Tools directory not found: {tools_dir}")
        return
    
    html_files = checker.scan_directory(tools_dir)
    print(f"\nFound {len(html_files)} HTML files to check")
    print("=" * 70)
    
    # Check and fix all files
    for filepath in html_files:
        checker.check_and_fix_file(filepath)
    
    # Summary
    print("\n" + "=" * 70)
    print("DESIGN CHECK SUMMARY")
    print("=" * 70)
    print(f"Files Checked: {checker.files_checked}")
    print(f"Files Fixed: {checker.files_fixed}")
    print(f"Files OK: {checker.files_checked - checker.files_fixed}")
    
    if checker.design_issues:
        print("\n" + "=" * 70)
        print("ISSUES FOUND AND FIXED")
        print("=" * 70)
        
        for issue_type, items in checker.design_issues.items():
            print(f"\n{issue_type.upper().replace('_', ' ')}:")
            if isinstance(items[0], tuple):
                for filepath, details in items[:5]:  # Show first 5
                    print(f"  - {filepath}")
                    if isinstance(details, list):
                        for detail in details:
                            print(f"    * {detail}")
                if len(items) > 5:
                    print(f"  ... and {len(items) - 5} more")
            else:
                for filepath in items[:5]:
                    print(f"  - {filepath}")
                if len(items) > 5:
                    print(f"  ... and {len(items) - 5} more")
    
    print("\n" + "=" * 70)
    print("[OK] Design consistency check complete!")
    print(f"[OK] All {checker.files_checked} files now have consistent design")
    print("=" * 70)
    
    # Check index.html separately
    if os.path.exists('index.html'):
        print("\n" + "=" * 70)
        print("CHECKING INDEX.HTML")
        print("=" * 70)
        checker.check_and_fix_file('index.html')
    
    return checker.files_fixed == 0

if __name__ == '__main__':
    success = main()
    exit(0 if success else 1)
