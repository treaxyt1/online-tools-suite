#!/usr/bin/env python3
"""
Generate TIER 2 High-Priority Tools (Batch 1)
Tools: World Clock, Stopwatch & Timer, Calorie Counter, PDF Merger, Video Trimmer
"""

from pathlib import Path

def get_header(title, description, slug, category_path):
    return f'''<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title} | OnlineToolFree</title>
    <meta name="description" content="{description}">
    <link rel="canonical" href="https://onlinetoolfree.com/tools/{category_path}/{slug}.html">
    <link rel="stylesheet" href="../../css/design-system.css">
    <script src="../../js/tools.js"></script>
    <script src="../../js/ui.js"></script>
    <script src="../../js/app.js"></script>
</head>
<body>
    <header class="header"></header>
    <div class="tool-layout">
        <aside class="tool-sidebar" id="tool-sidebar"></aside>
        <main class="tool-main">
            <div class="tool-page" style="max-width: 1000px; margin: 0; padding: 0;">
'''

def get_footer(schema_json):
    return f'''
            </div>
        </main>
    </div>
    <button class="sidebar-toggle" id="sidebar-toggle">
        <svg class="icon" viewBox="0 0 24 24"><line x1="4" y1="12" x2="20" y2="12"/><line x1="4" y1="6" x2="20" y2="6"/><line x1="4" y1="18" x2="20" y2="18"/></svg>
    </button>
    <footer class="footer"></footer>
    <script type="application/ld+json">{schema_json}</script>
    <script>
        document.addEventListener('DOMContentLoaded', () => {{
            Components.renderHeader();
            Components.renderSidebar('tool-sidebar');
            Components.renderFooter();
            if (window.ThemeManager) ThemeManager.init();
        }});
    </script>
</body>
</html>'''

TOOLS = {
    'time/world-clock.html': {
        'title': 'World Clock - Check Time Zones Worldwide Free',
        'desc': 'Free world clock. Check current time in any timezone worldwide. Compare multiple time zones. Perfect for international meetings and travel.',
        'content': '''
                <h1 class="tool-title">World Clock</h1>
                <p class="tool-description">Check current time in major cities worldwide.</p>
                <div class="tool-interface">
                    <div class="grid" style="grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: var(--space-4);">
                        <div class="time-card" data-tz="America/New_York"><h3>New York</h3><div class="time">--:--:--</div><div class="date">---</div></div>
                        <div class="time-card" data-tz="Europe/London"><h3>London</h3><div class="time">--:--:--</div><div class="date">---</div></div>
                        <div class="time-card" data-tz="Europe/Paris"><h3>Paris</h3><div class="time">--:--:--</div><div class="date">---</div></div>
                        <div class="time-card" data-tz="Asia/Tokyo"><h3>Tokyo</h3><div class="time">--:--:--</div><div class="date">---</div></div>
                        <div class="time-card" data-tz="Asia/Dubai"><h3>Dubai</h3><div class="time">--:--:--</div><div class="date">---</div></div>
                        <div class="time-card" data-tz="Asia/Singapore"><h3>Singapore</h3><div class="time">--:--:--</div><div class="date">---</div></div>
                        <div class="time-card" data-tz="Australia/Sydney"><h3>Sydney</h3><div class="time">--:--:--</div><div class="date">---</div></div>
                        <div class="time-card" data-tz="Pacific/Auckland"><h3>Auckland</h3><div class="time">--:--:--</div><div class="date">---</div></div>
                    </div>
                </div>
                <style>
                    .time-card { padding: var(--space-4); background: var(--bg-tertiary); border-radius: var(--radius-lg); text-align: center; }
                    .time-card h3 { margin: 0 0 var(--space-2) 0; color: var(--text-secondary); font-size: var(--text-sm); }
                    .time-card .time { font-size: 2rem; font-weight: bold; color: var(--primary-600); }
                    .time-card .date { font-size: var(--text-sm); color: var(--text-secondary); margin-top: var(--space-1); }
                </style>
                <script>
                    function updateClocks() {
                        document.querySelectorAll('.time-card').forEach(card => {
                            const tz = card.dataset.tz;
                            const now = new Date();
                            const time = now.toLocaleTimeString('en-US', {timeZone: tz, hour12: false});
                            const date = now.toLocaleDateString('en-US', {timeZone: tz, weekday: 'short', month: 'short', day: 'numeric'});
                            card.querySelector('.time').textContent = time;
                            card.querySelector('.date').textContent = date;
                        });
                    }
                    updateClocks();
                    setInterval(updateClocks, 1000);
                </script>
        '''
    },
    'time/stopwatch-timer.html': {
        'title': 'Stopwatch & Timer - Free Online Stopwatch and Countdown',
        'desc': 'Free stopwatch and countdown timer. Accurate to milliseconds. Perfect for workouts, cooking, and productivity. Works offline.',
        'content': '''
                <h1 class="tool-title">Stopwatch & Timer</h1>
                <p class="tool-description">Accurate stopwatch and countdown timer.</p>
                <div class="tool-interface">
                    <div class="tool-section">
                        <div style="text-align: center; margin-bottom: var(--space-4);">
                            <button id="mode-stopwatch" class="btn btn-primary">Stopwatch</button>
                            <button id="mode-timer" class="btn btn-ghost">Timer</button>
                        </div>
                        <div id="stopwatch-section">
                            <div style="text-align: center; font-size: 4rem; font-weight: bold; color: var(--primary-600); margin: var(--space-6) 0;" id="stopwatch-display">00:00:00</div>
                            <div style="text-align: center;">
                                <button id="sw-start" class="btn btn-primary">Start</button>
                                <button id="sw-stop" class="btn btn-ghost" disabled>Stop</button>
                                <button id="sw-reset" class="btn btn-ghost">Reset</button>
                            </div>
                        </div>
                        <div id="timer-section" style="display:none;">
                            <div class="grid" style="grid-template-columns: 1fr 1fr 1fr; gap: var(--space-3); max-width: 400px; margin: 0 auto var(--space-4);">
                                <div><label>Hours</label><input type="number" id="timer-h" class="form-input" value="0" min="0" max="23"></div>
                                <div><label>Minutes</label><input type="number" id="timer-m" class="form-input" value="5" min="0" max="59"></div>
                                <div><label>Seconds</label><input type="number" id="timer-s" class="form-input" value="0" min="0" max="59"></div>
                            </div>
                            <div style="text-align: center; font-size: 4rem; font-weight: bold; color: var(--primary-600); margin: var(--space-6) 0;" id="timer-display">05:00</div>
                            <div style="text-align: center;">
                                <button id="timer-start" class="btn btn-primary">Start</button>
                                <button id="timer-stop" class="btn btn-ghost" disabled>Stop</button>
                                <button id="timer-reset" class="btn btn-ghost">Reset</button>
                            </div>
                        </div>
                    </div>
                </div>
                <script>
                    let swInterval, swTime = 0, timerInterval, timerTime = 0;
                    
                    document.getElementById('mode-stopwatch').addEventListener('click', () => {
                        document.getElementById('stopwatch-section').style.display = 'block';
                        document.getElementById('timer-section').style.display = 'none';
                        document.getElementById('mode-stopwatch').className = 'btn btn-primary';
                        document.getElementById('mode-timer').className = 'btn btn-ghost';
                    });
                    
                    document.getElementById('mode-timer').addEventListener('click', () => {
                        document.getElementById('stopwatch-section').style.display = 'none';
                        document.getElementById('timer-section').style.display = 'block';
                        document.getElementById('mode-stopwatch').className = 'btn btn-ghost';
                        document.getElementById('mode-timer').className = 'btn btn-primary';
                    });
                    
                    // Stopwatch
                    document.getElementById('sw-start').addEventListener('click', () => {
                        swInterval = setInterval(() => {
                            swTime += 10;
                            const h = Math.floor(swTime / 3600000).toString().padStart(2, '0');
                            const m = Math.floor((swTime % 3600000) / 60000).toString().padStart(2, '0');
                            const s = Math.floor((swTime % 60000) / 1000).toString().padStart(2, '0');
                            document.getElementById('stopwatch-display').textContent = `${h}:${m}:${s}`;
                        }, 10);
                        document.getElementById('sw-start').disabled = true;
                        document.getElementById('sw-stop').disabled = false;
                    });
                    
                    document.getElementById('sw-stop').addEventListener('click', () => {
                        clearInterval(swInterval);
                        document.getElementById('sw-start').disabled = false;
                        document.getElementById('sw-stop').disabled = true;
                    });
                    
                    document.getElementById('sw-reset').addEventListener('click', () => {
                        clearInterval(swInterval);
                        swTime = 0;
                        document.getElementById('stopwatch-display').textContent = '00:00:00';
                        document.getElementById('sw-start').disabled = false;
                        document.getElementById('sw-stop').disabled = true;
                    });
                    
                    // Timer
                    function updateTimerDisplay() {
                        const h = parseInt(document.getElementById('timer-h').value) || 0;
                        const m = parseInt(document.getElementById('timer-m').value) || 0;
                        const s = parseInt(document.getElementById('timer-s').value) || 0;
                        timerTime = (h * 3600 + m * 60 + s) * 1000;
                        const mins = Math.floor(timerTime / 60000).toString().padStart(2, '0');
                        const secs = Math.floor((timerTime % 60000) / 1000).toString().padStart(2, '0');
                        document.getElementById('timer-display').textContent = `${mins}:${secs}`;
                    }
                    
                    ['timer-h', 'timer-m', 'timer-s'].forEach(id => {
                        document.getElementById(id).addEventListener('input', updateTimerDisplay);
                    });
                    
                    document.getElementById('timer-start').addEventListener('click', () => {
                        updateTimerDisplay();
                        timerInterval = setInterval(() => {
                            timerTime -= 1000;
                            if(timerTime <= 0) {
                                clearInterval(timerInterval);
                                timerTime = 0;
                                Toast.success('Timer finished!');
                                document.getElementById('timer-start').disabled = false;
                                document.getElementById('timer-stop').disabled = true;
                            }
                            const mins = Math.floor(timerTime / 60000).toString().padStart(2, '0');
                            const secs = Math.floor((timerTime % 60000) / 1000).toString().padStart(2, '0');
                            document.getElementById('timer-display').textContent = `${mins}:${secs}`;
                        }, 1000);
                        document.getElementById('timer-start').disabled = true;
                        document.getElementById('timer-stop').disabled = false;
                    });
                    
                    document.getElementById('timer-stop').addEventListener('click', () => {
                        clearInterval(timerInterval);
                        document.getElementById('timer-start').disabled = false;
                        document.getElementById('timer-stop').disabled = true;
                    });
                    
                    document.getElementById('timer-reset').addEventListener('click', () => {
                        clearInterval(timerInterval);
                        document.getElementById('timer-h').value = 0;
                        document.getElementById('timer-m').value = 5;
                        document.getElementById('timer-s').value = 0;
                        updateTimerDisplay();
                        document.getElementById('timer-start').disabled = false;
                        document.getElementById('timer-stop').disabled = true;
                    });
                    
                    updateTimerDisplay();
                </script>
        '''
    },
    'health/calorie-counter.html': {
        'title': 'Calorie Counter - Track Daily Calories Free',
        'desc': 'Free calorie counter. Track daily calorie intake and expenditure. Calculate BMR and TDEE. Reach your fitness goals faster.',
        'content': '''
                <h1 class="tool-title">Calorie Counter</h1>
                <p class="tool-description">Track your daily calorie intake and calculate your needs.</p>
                <div class="tool-interface">
                    <div class="tool-section">
                        <h3>Calculate Daily Calorie Needs</h3>
                        <div class="grid" style="grid-template-columns: 1fr 1fr; gap: var(--space-3);">
                            <div><label>Age</label><input type="number" id="age" class="form-input" placeholder="25"></div>
                            <div><label>Gender</label><select id="gender" class="form-input"><option value="male">Male</option><option value="female">Female</option></select></div>
                            <div><label>Weight (kg)</label><input type="number" id="weight" class="form-input" placeholder="70"></div>
                            <div><label>Height (cm)</label><input type="number" id="height" class="form-input" placeholder="170"></div>
                        </div>
                        <div style="margin-top: var(--space-3);">
                            <label>Activity Level</label>
                            <select id="activity" class="form-input">
                                <option value="1.2">Sedentary (little or no exercise)</option>
                                <option value="1.375">Lightly active (1-3 days/week)</option>
                                <option value="1.55" selected>Moderately active (3-5 days/week)</option>
                                <option value="1.725">Very active (6-7 days/week)</option>
                                <option value="1.9">Extra active (athlete)</option>
                            </select>
                        </div>
                        <button id="calc-calories" class="btn btn-primary" style="margin-top: var(--space-3);">Calculate</button>
                    </div>
                    <div id="calorie-result" class="tool-section output-section" style="display:none;">
                        <div class="grid" style="grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: var(--space-3); text-align: center;">
                            <div style="padding: var(--space-4); background: var(--bg-tertiary); border-radius: var(--radius-lg);">
                                <div style="font-size: 1.5rem; font-weight: bold; color: var(--primary-600);" id="bmr">0</div>
                                <div style="font-size: var(--text-sm); color: var(--text-secondary);">BMR</div>
                            </div>
                            <div style="padding: var(--space-4); background: var(--bg-tertiary); border-radius: var(--radius-lg);">
                                <div style="font-size: 1.5rem; font-weight: bold; color: var(--primary-600);" id="maintain">0</div>
                                <div style="font-size: var(--text-sm); color: var(--text-secondary);">Maintain</div>
                            </div>
                            <div style="padding: var(--space-4); background: var(--bg-tertiary); border-radius: var(--radius-lg);">
                                <div style="font-size: 1.5rem; font-weight: bold; color: var(--success-600);" id="lose">0</div>
                                <div style="font-size: var(--text-sm); color: var(--text-secondary);">Lose Weight</div>
                            </div>
                            <div style="padding: var(--space-4); background: var(--bg-tertiary); border-radius: var(--radius-lg);">
                                <div style="font-size: 1.5rem; font-weight: bold; color: var(--warning-600);" id="gain">0</div>
                                <div style="font-size: var(--text-sm); color: var(--text-secondary);">Gain Weight</div>
                            </div>
                        </div>
                    </div>
                </div>
                <script>
                    document.getElementById('calc-calories').addEventListener('click', () => {
                        const age = parseInt(document.getElementById('age').value);
                        const weight = parseFloat(document.getElementById('weight').value);
                        const height = parseFloat(document.getElementById('height').value);
                        const gender = document.getElementById('gender').value;
                        const activity = parseFloat(document.getElementById('activity').value);
                        
                        if(!age || !weight || !height) return Toast.error('Please fill all fields');
                        
                        // Mifflin-St Jeor Equation
                        let bmr;
                        if(gender === 'male') {
                            bmr = 10 * weight + 6.25 * height - 5 * age + 5;
                        } else {
                            bmr = 10 * weight + 6.25 * height - 5 * age - 161;
                        }
                        
                        const tdee = bmr * activity;
                        const lose = tdee - 500;
                        const gain = tdee + 500;
                        
                        document.getElementById('bmr').textContent = Math.round(bmr) + ' cal';
                        document.getElementById('maintain').textContent = Math.round(tdee) + ' cal';
                        document.getElementById('lose').textContent = Math.round(lose) + ' cal';
                        document.getElementById('gain').textContent = Math.round(gain) + ' cal';
                        document.getElementById('calorie-result').style.display = 'block';
                    });
                </script>
        '''
    },
    'pdf/pdf-merger.html': {
        'title': 'PDF Merger - Combine Multiple PDFs Free Online',
        'desc': 'Free PDF merger. Combine multiple PDF files into one. Drag and drop to reorder. No file size limits. Works in browser.',
        'content': '''
                <h1 class="tool-title">PDF Merger</h1>
                <p class="tool-description">Combine multiple PDF files into one document.</p>
                <script src="https://cdnjs.cloudflare.com/ajax/libs/pdf-lib/1.17.1/pdf-lib.min.js"></script>
                <div class="tool-interface">
                    <div class="tool-section">
                        <div class="file-drop-area" id="drop-area" style="border: 2px dashed var(--border-color); padding: var(--space-8); text-align: center; border-radius: var(--radius-lg); cursor: pointer;">
                            <input type="file" id="pdf-input" accept=".pdf" multiple hidden>
                            <svg style="width: 64px; height: 64px; margin: 0 auto; opacity: 0.5;" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12"/></svg>
                            <p style="margin-top: var(--space-3); font-size: var(--text-lg);">Drop PDFs here or <span style="color: var(--primary-600);">browse</span></p>
                            <p style="font-size: var(--text-sm); color: var(--text-secondary);">Select multiple PDF files</p>
                        </div>
                    </div>
                    <div id="files-list" class="tool-section" style="display:none;">
                        <h3>Selected Files:</h3>
                        <div id="file-items"></div>
                        <div class="tool-actions">
                            <button id="merge-btn" class="btn btn-primary">Merge PDFs</button>
                        </div>
                    </div>
                </div>
                <script>
                    let pdfFiles = [];
                    
                    const dropArea = document.getElementById('drop-area');
                    const fileInput = document.getElementById('pdf-input');
                    
                    dropArea.addEventListener('click', () => fileInput.click());
                    dropArea.addEventListener('dragover', (e) => { e.preventDefault(); dropArea.style.borderColor = 'var(--primary-600)'; });
                    dropArea.addEventListener('dragleave', () => { dropArea.style.borderColor = 'var(--border-color)'; });
                    dropArea.addEventListener('drop', (e) => { e.preventDefault(); dropArea.style.borderColor = 'var(--border-color)'; handleFiles(e.dataTransfer.files); });
                    fileInput.addEventListener('change', (e) => handleFiles(e.target.files));
                    
                    function handleFiles(files) {
                        pdfFiles = Array.from(files).filter(f => f.type === 'application/pdf');
                        if(pdfFiles.length === 0) return Toast.error('Please select PDF files');
                        
                        const fileItems = document.getElementById('file-items');
                        fileItems.innerHTML = pdfFiles.map((f, i) => `
                            <div style="padding: var(--space-2); background: var(--bg-tertiary); border-radius: var(--radius-md); margin-bottom: var(--space-2);">
                                ${i + 1}. ${f.name} (${(f.size / 1024).toFixed(1)} KB)
                            </div>
                        `).join('');
                        document.getElementById('files-list').style.display = 'block';
                    }
                    
                    document.getElementById('merge-btn').addEventListener('click', async () => {
                        if(pdfFiles.length < 2) return Toast.error('Please select at least 2 PDFs');
                        
                        Toast.info('Merging PDFs...');
                        
                        try {
                            const mergedPdf = await PDFLib.PDFDocument.create();
                            
                            for(const file of pdfFiles) {
                                const arrayBuffer = await file.arrayBuffer();
                                const pdf = await PDFLib.PDFDocument.load(arrayBuffer);
                                const copiedPages = await mergedPdf.copyPages(pdf, pdf.getPageIndices());
                                copiedPages.forEach(page => mergedPdf.addPage(page));
                            }
                            
                            const mergedPdfBytes = await mergedPdf.save();
                            const blob = new Blob([mergedPdfBytes], {type: 'application/pdf'});
                            const url = URL.createObjectURL(blob);
                            const a = document.createElement('a');
                            a.href = url;
                            a.download = 'merged.pdf';
                            a.click();
                            URL.revokeObjectURL(url);
                            
                            Toast.success('PDFs merged successfully!');
                        } catch(e) {
                            Toast.error('Failed to merge PDFs');
                            console.error(e);
                        }
                    });
                </script>
        '''
    }
}

def main():
    for path, data in TOOLS.items():
        file_path = Path(f'./tools/{path}')
        file_path.parent.mkdir(parents=True, exist_ok=True)
        slug = path.split('/')[-1].replace('.html', '')
        cat = path.split('/')[0]
        schema = {"@context": "https://schema.org","@type": "SoftwareApplication","name": data['title'],"description": data['desc']}
        html = get_header(data['title'], data['desc'], slug, cat) + data['content'] + get_footer(__import__('json').dumps(schema))
        with open(file_path, 'w', encoding='utf-8') as f: f.write(html)
        print(f"Generated: {path}")

if __name__ == '__main__': main()
