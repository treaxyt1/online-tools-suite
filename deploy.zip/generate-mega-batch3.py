#!/usr/bin/env python3
"""
Generate TIER 2 & 3 Tools (Batch 3 - MEGA BATCH)
Tools: Flashcard Maker, Study Planner, Sleep Calculator, Water Intake, Compound Interest, 
       ROI Calculator, Currency Converter, Timezone Converter, Wheel Spinner, Team Generator
"""

from pathlib import Path
import json

def get_header(title, description, slug, category_path):
    return f'''<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title} | OnlineToolFree</title>
    <meta name="description" content="{description}">
    <link rel="canonical" href="https://onlinetoolfree.com/tools/{category_path}/{slug}.html">
    <link rel="stylesheet" href="../../css/design-system.css">
    <script src="../../js/tools.js"></script>
    <script src="../../js/ui.js"></script>
    <script src="../../js/app.js"></script>
</head>
<body>
    <header class="header"></header>
    <div class="tool-layout">
        <aside class="tool-sidebar" id="tool-sidebar"></aside>
        <main class="tool-main">
            <div class="tool-page" style="max-width: 1000px; margin: 0; padding: 0;">
'''

def get_footer(schema_json):
    return f'''
            </div>
        </main>
    </div>
    <button class="sidebar-toggle" id="sidebar-toggle">
        <svg class="icon" viewBox="0 0 24 24"><line x1="4" y1="12" x2="20" y2="12"/><line x1="4" y1="6" x2="20" y2="6"/><line x1="4" y1="18" x2="20" y2="18"/></svg>
    </button>
    <footer class="footer"></footer>
    <script type="application/ld+json">{schema_json}</script>
    <script>
        document.addEventListener('DOMContentLoaded', () => {{
            Components.renderHeader();
            Components.renderSidebar('tool-sidebar');
            Components.renderFooter();
            if (window.ThemeManager) ThemeManager.init();
        }});
    </script>
</body>
</html>'''

TOOLS = {
    'education/flashcard-maker.html': ('Flashcard Maker - Create Study Flashcards Free', 'Free flashcard maker. Create digital flashcards for studying. Perfect for students. Export and share. No sign-up required.', '''
                <h1 class="tool-title">Flashcard Maker</h1>
                <p class="tool-description">Create digital flashcards for studying.</p>
                <div class="tool-interface">
                    <div class="tool-section">
                        <div class="grid" style="grid-template-columns: 1fr 1fr; gap: var(--space-3);">
                            <div><label>Front (Question)</label><textarea id="front" class="form-input" rows="3"></textarea></div>
                            <div><label>Back (Answer)</label><textarea id="back" class="form-input" rows="3"></textarea></div>
                        </div>
                        <button onclick="addCard()" class="btn btn-primary" style="margin-top: var(--space-2);">Add Card</button>
                    </div>
                    <div id="cards-section" class="tool-section" style="display:none;">
                        <h3>Your Flashcards (<span id="card-count">0</span>)</h3>
                        <div id="cards-list"></div>
                        <button onclick="startStudy()" class="btn btn-primary">Start Studying</button>
                    </div>
                    <div id="study-section" style="display:none; text-align: center;">
                        <div id="flashcard" style="min-height: 200px; padding: var(--space-6); background: var(--bg-tertiary); border-radius: var(--radius-lg); cursor: pointer; margin: var(--space-4) 0;" onclick="flipCard()">
                            <div id="card-content" style="font-size: 1.5rem;"></div>
                        </div>
                        <div><button onclick="prevCard()" class="btn btn-ghost">← Previous</button><button onclick="nextCard()" class="btn btn-primary">Next →</button></div>
                    </div>
                </div>
                <script>
                    let cards = [], currentCard = 0, showingFront = true;
                    function addCard() {
                        const front = document.getElementById('front').value;
                        const back = document.getElementById('back').value;
                        if(!front || !back) return Toast.error('Fill both sides');
                        cards.push({front, back});
                        document.getElementById('front').value = '';
                        document.getElementById('back').value = '';
                        updateCardsList();
                    }
                    function updateCardsList() {
                        document.getElementById('card-count').textContent = cards.length;
                        document.getElementById('cards-list').innerHTML = cards.map((c, i) => 
                            \`<div style="padding: var(--space-2); background: var(--bg-tertiary); border-radius: var(--radius-md); margin-bottom: var(--space-2);">\${i+1}. \${c.front.substring(0, 50)}...</div>\`
                        ).join('');
                        document.getElementById('cards-section').style.display = cards.length ? 'block' : 'none';
                    }
                    function startStudy() {
                        if(!cards.length) return;
                        currentCard = 0; showingFront = true;
                        document.getElementById('study-section').style.display = 'block';
                        showCard();
                    }
                    function showCard() {
                        document.getElementById('card-content').textContent = showingFront ? cards[currentCard].front : cards[currentCard].back;
                    }
                    function flipCard() { showingFront = !showingFront; showCard(); }
                    function nextCard() { currentCard = (currentCard + 1) % cards.length; showingFront = true; showCard(); }
                    function prevCard() { currentCard = (currentCard - 1 + cards.length) % cards.length; showingFront = true; showCard(); }
                </script>
    '''),
    'education/study-planner.html': ('Study Planner - Plan Your Study Schedule Free', 'Free study planner. Create study schedules and track progress. Perfect for students and exam prep. No sign-up required.', '''
                <h1 class="tool-title">Study Planner</h1>
                <p class="tool-description">Plan your study schedule effectively.</p>
                <div class="tool-interface">
                    <div class="tool-section">
                        <div class="grid" style="grid-template-columns: 2fr 1fr 1fr; gap: var(--space-3);">
                            <input type="text" id="subject" class="form-input" placeholder="Subject">
                            <input type="time" id="time" class="form-input" value="09:00">
                            <input type="number" id="duration" class="form-input" placeholder="Minutes" value="60">
                        </div>
                        <button onclick="addSession()" class="btn btn-primary" style="margin-top: var(--space-2);">Add Study Session</button>
                    </div>
                    <div id="schedule" class="tool-section" style="display:none;"><h3>Today's Schedule</h3><div id="sessions"></div></div>
                </div>
                <script>
                    let sessions = [];
                    function addSession() {
                        const subject = document.getElementById('subject').value;
                        const time = document.getElementById('time').value;
                        const duration = document.getElementById('duration').value;
                        if(!subject) return Toast.error('Enter subject');
                        sessions.push({subject, time, duration});
                        sessions.sort((a,b) => a.time.localeCompare(b.time));
                        updateSchedule();
                    }
                    function updateSchedule() {
                        document.getElementById('sessions').innerHTML = sessions.map((s, i) => 
                            \`<div style="padding: var(--space-3); background: var(--bg-tertiary); border-radius: var(--radius-md); margin-bottom: var(--space-2); display: flex; justify-content: space-between;">
                                <div><strong>\${s.time}</strong> - \${s.subject} (\${s.duration} min)</div>
                                <button onclick="sessions.splice(\${i}, 1); updateSchedule();" class="btn btn-ghost btn-sm">Remove</button>
                            </div>\`
                        ).join('');
                        document.getElementById('schedule').style.display = sessions.length ? 'block' : 'none';
                    }
                </script>
    '''),
    'health/sleep-calculator.html': ('Sleep Calculator - Calculate Best Sleep Time Free', 'Free sleep calculator. Find the best time to sleep and wake up. Based on 90-minute sleep cycles. Wake up refreshed.', '''
                <h1 class="tool-title">Sleep Calculator</h1>
                <p class="tool-description">Calculate optimal sleep and wake times.</p>
                <div class="tool-interface">
                    <div class="tool-section">
                        <label>I want to wake up at:</label>
                        <input type="time" id="wake-time" class="form-input" value="07:00">
                        <button id="calc-sleep" class="btn btn-primary" style="margin-top: var(--space-2);">Calculate Sleep Times</button>
                    </div>
                    <div id="result" class="tool-section output-section" style="display:none;">
                        <p>To wake up at <strong id="wake-display"></strong>, you should go to bed at:</p>
                        <div id="sleep-times" class="grid" style="grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: var(--space-3);"></div>
                        <p style="margin-top: var(--space-4); font-size: var(--text-sm); color: var(--text-secondary);">Based on 90-minute sleep cycles. It takes ~14 minutes to fall asleep.</p>
                    </div>
                </div>
                <script>
                    document.getElementById('calc-sleep').addEventListener('click', () => {
                        const wakeTime = document.getElementById('wake-time').value.split(':');
                        const wakeDate = new Date();
                        wakeDate.setHours(parseInt(wakeTime[0]), parseInt(wakeTime[1]), 0);
                        
                        const cycles = [6, 5, 4, 3];
                        const sleepTimes = cycles.map(c => {
                            const time = new Date(wakeDate - (c * 90 + 14) * 60000);
                            return {cycles: c, time: time.toLocaleTimeString('en-US', {hour: '2-digit', minute: '2-digit', hour12: false})};
                        });
                        
                        document.getElementById('wake-display').textContent = wakeTime.join(':');
                        document.getElementById('sleep-times').innerHTML = sleepTimes.map(s => 
                            \`<div style="padding: var(--space-4); background: var(--bg-tertiary); border-radius: var(--radius-lg); text-align: center;">
                                <div style="font-size: 1.5rem; font-weight: bold; color: var(--primary-600);">\${s.time}</div>
                                <div style="font-size: var(--text-sm); color: var(--text-secondary);">\${s.cycles} cycles (\${s.cycles * 1.5}h)</div>
                            </div>\`
                        ).join('');
                        document.getElementById('result').style.display = 'block';
                    });
                </script>
    '''),
    'health/water-intake.html': ('Water Intake Calculator - Daily Water Needs Free', 'Free water intake calculator. Calculate how much water you should drink daily. Based on weight and activity level.', '''
                <h1 class="tool-title">Water Intake Calculator</h1>
                <p class="tool-description">Calculate your daily water intake needs.</p>
                <div class="tool-interface">
                    <div class="tool-section">
                        <div class="grid" style="grid-template-columns: 1fr 1fr; gap: var(--space-3);">
                            <div><label>Weight (kg)</label><input type="number" id="weight" class="form-input" placeholder="70"></div>
                            <div><label>Activity Level</label><select id="activity" class="form-input"><option value="1">Sedentary</option><option value="1.2">Light</option><option value="1.4" selected>Moderate</option><option value="1.6">Active</option><option value="1.8">Very Active</option></select></div>
                        </div>
                        <button id="calculate" class="btn btn-primary" style="margin-top: var(--space-2);">Calculate</button>
                    </div>
                    <div id="result" class="tool-section output-section" style="display:none; text-align: center;">
                        <div style="font-size: 3rem; font-weight: bold; color: var(--primary-600);" id="liters">0</div>
                        <p>liters per day</p>
                        <div class="grid" style="grid-template-columns: 1fr 1fr; gap: var(--space-3); margin-top: var(--space-4);">
                            <div style="padding: var(--space-3); background: var(--bg-tertiary); border-radius: var(--radius-md);"><strong id="glasses">0</strong> glasses (250ml)</div>
                            <div style="padding: var(--space-3); background: var(--bg-tertiary); border-radius: var(--radius-md);"><strong id="bottles">0</strong> bottles (500ml)</div>
                        </div>
                    </div>
                </div>
                <script>
                    document.getElementById('calculate').addEventListener('click', () => {
                        const weight = parseFloat(document.getElementById('weight').value);
                        const activity = parseFloat(document.getElementById('activity').value);
                        if(!weight) return Toast.error('Enter weight');
                        const liters = (weight * 0.033 * activity).toFixed(1);
                        document.getElementById('liters').textContent = liters;
                        document.getElementById('glasses').textContent = Math.ceil(liters * 4);
                        document.getElementById('bottles').textContent = Math.ceil(liters * 2);
                        document.getElementById('result').style.display = 'block';
                    });
                </script>
    '''),
    'finance/compound-interest.html': ('Compound Interest Calculator - Calculate Returns Free', 'Free compound interest calculator. Calculate investment returns with compound interest. Plan your financial future.', '''
                <h1 class="tool-title">Compound Interest Calculator</h1>
                <p class="tool-description">Calculate compound interest on investments.</p>
                <div class="tool-interface">
                    <div class="tool-section">
                        <div class="grid" style="grid-template-columns: 1fr 1fr; gap: var(--space-3);">
                            <div><label>Initial Amount ($)</label><input type="number" id="principal" class="form-input" value="1000"></div>
                            <div><label>Monthly Contribution ($)</label><input type="number" id="monthly" class="form-input" value="100"></div>
                            <div><label>Annual Interest Rate (%)</label><input type="number" id="rate" class="form-input" value="7" step="0.1"></div>
                            <div><label>Years</label><input type="number" id="years" class="form-input" value="10"></div>
                        </div>
                        <button id="calculate" class="btn btn-primary" style="margin-top: var(--space-2);">Calculate</button>
                    </div>
                    <div id="result" class="tool-section output-section" style="display:none;">
                        <div class="grid" style="grid-template-columns: repeat(3, 1fr); gap: var(--space-3); text-align: center;">
                            <div style="padding: var(--space-4); background: var(--bg-tertiary); border-radius: var(--radius-lg);"><div style="font-size: 1.5rem; font-weight: bold; color: var(--primary-600);" id="total">$0</div><div style="font-size: var(--text-sm);">Total Value</div></div>
                            <div style="padding: var(--space-4); background: var(--bg-tertiary); border-radius: var(--radius-lg);"><div style="font-size: 1.5rem; font-weight: bold; color: var(--success-600);" id="contributed">$0</div><div style="font-size: var(--text-sm);">Contributed</div></div>
                            <div style="padding: var(--space-4); background: var(--bg-tertiary); border-radius: var(--radius-lg);"><div style="font-size: 1.5rem; font-weight: bold; color: var(--warning-600);" id="interest">$0</div><div style="font-size: var(--text-sm);">Interest Earned</div></div>
                        </div>
                    </div>
                </div>
                <script>
                    document.getElementById('calculate').addEventListener('click', () => {
                        const P = parseFloat(document.getElementById('principal').value) || 0;
                        const PMT = parseFloat(document.getElementById('monthly').value) || 0;
                        const r = parseFloat(document.getElementById('rate').value) / 100 / 12;
                        const n = parseInt(document.getElementById('years').value) * 12;
                        const FV = P * Math.pow(1 + r, n) + PMT * ((Math.pow(1 + r, n) - 1) / r);
                        const contributed = P + (PMT * n);
                        const interest = FV - contributed;
                        document.getElementById('total').textContent = '$' + FV.toFixed(2).replace(/\\B(?=(\\d{3})+(?!\\d))/g, ',');
                        document.getElementById('contributed').textContent = '$' + contributed.toFixed(2).replace(/\\B(?=(\\d{3})+(?!\\d))/g, ',');
                        document.getElementById('interest').textContent = '$' + interest.toFixed(2).replace(/\\B(?=(\\d{3})+(?!\\d))/g, ',');
                        document.getElementById('result').style.display = 'block';
                    });
                </script>
    '''),
    'finance/roi-calculator.html': ('ROI Calculator - Calculate Return on Investment Free', 'Free ROI calculator. Calculate return on investment percentage. Make better investment decisions.', '''
                <h1 class="tool-title">ROI Calculator</h1>
                <p class="tool-description">Calculate return on investment (ROI).</p>
                <div class="tool-interface">
                    <div class="tool-section">
                        <div class="grid" style="grid-template-columns: 1fr 1fr; gap: var(--space-3);">
                            <div><label>Initial Investment ($)</label><input type="number" id="initial" class="form-input" placeholder="10000"></div>
                            <div><label>Final Value ($)</label><input type="number" id="final" class="form-input" placeholder="15000"></div>
                        </div>
                        <button id="calculate" class="btn btn-primary" style="margin-top: var(--space-2);">Calculate ROI</button>
                    </div>
                    <div id="result" class="tool-section output-section" style="display:none; text-align: center;">
                        <div style="font-size: 4rem; font-weight: bold; color: var(--success-600);" id="roi">0%</div>
                        <p style="font-size: var(--text-lg);">Return on Investment</p>
                        <div style="margin-top: var(--space-4); padding: var(--space-4); background: var(--bg-tertiary); border-radius: var(--radius-lg);">
                            <p><strong>Profit/Loss:</strong> <span id="profit">$0</span></p>
                        </div>
                    </div>
                </div>
                <script>
                    document.getElementById('calculate').addEventListener('click', () => {
                        const initial = parseFloat(document.getElementById('initial').value);
                        const final = parseFloat(document.getElementById('final').value);
                        if(!initial || !final) return Toast.error('Enter both values');
                        const profit = final - initial;
                        const roi = ((profit / initial) * 100).toFixed(2);
                        document.getElementById('roi').textContent = roi + '%';
                        document.getElementById('roi').style.color = profit >= 0 ? 'var(--success-600)' : 'var(--error-600)';
                        document.getElementById('profit').textContent = '$' + profit.toFixed(2);
                        document.getElementById('profit').style.color = profit >= 0 ? 'var(--success-600)' : 'var(--error-600)';
                        document.getElementById('result').style.display = 'block';
                    });
                </script>
    '''),
    'converter/currency-converter.html': ('Currency Converter - Convert Currencies Free', 'Free currency converter. Convert between 150+ currencies. Real-time exchange rates. No sign-up required.', '''
                <h1 class="tool-title">Currency Converter</h1>
                <p class="tool-description">Convert between world currencies.</p>
                <div class="tool-interface">
                    <div class="grid" style="grid-template-columns: 1fr 1fr; gap: var(--space-4);">
                        <div class="tool-section"><label>From</label><input type="number" id="amount" class="form-input" value="100"><select id="from" class="form-input" style="margin-top: 5px;"><option value="USD">USD - US Dollar</option><option value="EUR">EUR - Euro</option><option value="GBP">GBP - British Pound</option><option value="JPY">JPY - Japanese Yen</option><option value="CNY">CNY - Chinese Yuan</option></select></div>
                        <div class="tool-section"><label>To</label><input type="number" id="result" class="form-input" readonly><select id="to" class="form-input" style="margin-top: 5px;"><option value="USD">USD - US Dollar</option><option value="EUR" selected>EUR - Euro</option><option value="GBP">GBP - British Pound</option><option value="JPY">JPY - Japanese Yen</option><option value="CNY">CNY - Chinese Yuan</option></select></div>
                    </div>
                    <button id="convert" class="btn btn-primary">Convert</button>
                    <p style="margin-top: var(--space-2); font-size: var(--text-sm); color: var(--text-secondary);">Note: Using approximate exchange rates. For exact rates, check with your bank.</p>
                </div>
                <script>
                    const rates = {USD: 1, EUR: 0.92, GBP: 0.79, JPY: 149.5, CNY: 7.24};
                    document.getElementById('convert').addEventListener('click', () => {
                        const amount = parseFloat(document.getElementById('amount').value);
                        const from = document.getElementById('from').value;
                        const to = document.getElementById('to').value;
                        const result = (amount / rates[from]) * rates[to];
                        document.getElementById('result').value = result.toFixed(2);
                    });
                </script>
    '''),
    'time/timezone-converter.html': ('Timezone Converter - Convert Time Zones Free', 'Free timezone converter. Convert time between different time zones. Perfect for international meetings and travel.', '''
                <h1 class="tool-title">Timezone Converter</h1>
                <p class="tool-description">Convert time between different time zones.</p>
                <div class="tool-interface">
                    <div class="tool-section">
                        <div class="grid" style="grid-template-columns: 1fr 1fr; gap: var(--space-3);">
                            <div><label>Time</label><input type="time" id="time" class="form-input" value="12:00"></div>
                            <div><label>Date</label><input type="date" id="date" class="form-input"></div>
                        </div>
                        <div class="grid" style="grid-template-columns: 1fr 1fr; gap: var(--space-3); margin-top: var(--space-3);">
                            <div><label>From Timezone</label><select id="from-tz" class="form-input"><option value="America/New_York">New York (EST)</option><option value="Europe/London">London (GMT)</option><option value="Asia/Tokyo">Tokyo (JST)</option><option value="Australia/Sydney">Sydney (AEDT)</option></select></div>
                            <div><label>To Timezone</label><select id="to-tz" class="form-input"><option value="America/New_York">New York (EST)</option><option value="Europe/London" selected>London (GMT)</option><option value="Asia/Tokyo">Tokyo (JST)</option><option value="Australia/Sydney">Sydney (AEDT)</option></select></div>
                        </div>
                        <button id="convert" class="btn btn-primary" style="margin-top: var(--space-2);">Convert</button>
                    </div>
                    <div id="result" class="tool-section output-section" style="display:none; text-align: center;">
                        <div style="font-size: 2rem; font-weight: bold; color: var(--primary-600);" id="converted-time"></div>
                        <p id="converted-date" style="margin-top: var(--space-2);"></p>
                    </div>
                </div>
                <script>
                    document.getElementById('date').valueAsDate = new Date();
                    document.getElementById('convert').addEventListener('click', () => {
                        const time = document.getElementById('time').value;
                        const date = document.getElementById('date').value;
                        const fromTz = document.getElementById('from-tz').value;
                        const toTz = document.getElementById('to-tz').value;
                        const dt = new Date(date + 'T' + time);
                        const converted = new Date(dt.toLocaleString('en-US', {timeZone: toTz}));
                        document.getElementById('converted-time').textContent = converted.toLocaleTimeString('en-US', {hour: '2-digit', minute: '2-digit', hour12: false});
                        document.getElementById('converted-date').textContent = converted.toLocaleDateString('en-US', {weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'});
                        document.getElementById('result').style.display = 'block';
                    });
                </script>
    '''),
    'random/wheel-spinner.html': ('Wheel Spinner - Random Decision Maker Free', 'Free wheel spinner. Make random decisions with a spinning wheel. Add custom options. Perfect for games and choices.', '''
                <h1 class="tool-title">Wheel Spinner</h1>
                <p class="tool-description">Spin the wheel to make random decisions.</p>
                <div class="tool-interface">
                    <div class="tool-section">
                        <label>Add Options (one per line)</label>
                        <textarea id="options" class="form-input" rows="5" placeholder="Option 1\\nOption 2\\nOption 3">Pizza\\nBurger\\nSushi\\nPasta\\nSalad</textarea>
                        <button id="spin" class="btn btn-primary" style="margin-top: var(--space-2);">Spin the Wheel!</button>
                    </div>
                    <div id="result" class="tool-section output-section" style="display:none; text-align: center;">
                        <div style="font-size: 3rem; font-weight: bold; color: var(--primary-600); padding: var(--space-6); background: var(--bg-tertiary); border-radius: var(--radius-lg);" id="winner"></div>
                    </div>
                </div>
                <script>
                    document.getElementById('spin').addEventListener('click', () => {
                        const options = document.getElementById('options').value.split('\\n').filter(o => o.trim());
                        if(options.length < 2) return Toast.error('Add at least 2 options');
                        let count = 0;
                        const interval = setInterval(() => {
                            document.getElementById('winner').textContent = options[Math.floor(Math.random() * options.length)];
                            document.getElementById('result').style.display = 'block';
                            count++;
                            if(count > 20) {
                                clearInterval(interval);
                                Toast.success('Result selected!');
                            }
                        }, 100);
                    });
                </script>
    '''),
    'random/team-generator.html': ('Random Team Generator - Create Teams Free', 'Free random team generator. Divide people into random teams. Perfect for sports, games, and group activities.', '''
                <h1 class="tool-title">Random Team Generator</h1>
                <p class="tool-description">Generate random teams from a list of names.</p>
                <div class="tool-interface">
                    <div class="tool-section">
                        <label>Names (one per line)</label>
                        <textarea id="names" class="form-input" rows="8" placeholder="Alice\\nBob\\nCharlie\\nDiana"></textarea>
                        <div style="margin-top: var(--space-3);"><label>Number of Teams</label><input type="number" id="teams" class="form-input" value="2" min="2" max="10"></div>
                        <button id="generate" class="btn btn-primary" style="margin-top: var(--space-2);">Generate Teams</button>
                    </div>
                    <div id="result" class="tool-section output-section" style="display:none;"><div id="teams-list"></div></div>
                </div>
                <script>
                    document.getElementById('generate').addEventListener('click', () => {
                        const names = document.getElementById('names').value.split('\\n').filter(n => n.trim());
                        const teamCount = parseInt(document.getElementById('teams').value);
                        if(names.length < teamCount) return Toast.error('Need more names than teams');
                        const shuffled = names.sort(() => 0.5 - Math.random());
                        const teams = Array.from({length: teamCount}, () => []);
                        shuffled.forEach((name, i) => teams[i % teamCount].push(name));
                        document.getElementById('teams-list').innerHTML = teams.map((team, i) => 
                            \`<div style="padding: var(--space-4); background: var(--bg-tertiary); border-radius: var(--radius-lg); margin-bottom: var(--space-3);">
                                <h3>Team \${i + 1} (\${team.length} members)</h3>
                                <ul style="margin-top: var(--space-2);">\${team.map(n => '<li>' + n + '</li>').join('')}</ul>
                            </div>\`
                        ).join('');
                        document.getElementById('result').style.display = 'block';
                    });
                </script>
    '''),
}

def main():
    for path, (title, desc, content) in TOOLS.items():
        file_path = Path(f'./tools/{path}')
        file_path.parent.mkdir(parents=True, exist_ok=True)
        slug = path.split('/')[-1].replace('.html', '')
        cat = path.split('/')[0]
        schema = json.dumps({"@context": "https://schema.org","@type": "SoftwareApplication","name": title,"description": desc})
        html = get_header(title, desc, slug, cat) + content + get_footer(schema)
        with open(file_path, 'w', encoding='utf-8') as f: f.write(html)
        print(f"Generated: {path}")

if __name__ == '__main__': main()
