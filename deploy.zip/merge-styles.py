#!/usr/bin/env python3
"""
Merge duplicate style attributes
"""

import re
from pathlib import Path

class Colors:
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RESET = '\033[0m'

def print_colored(text, color):
    try:
        print(f"{color}{text}{Colors.RESET}")
    except UnicodeEncodeError:
        print(text.encode('ascii', 'replace').decode('ascii'))

def merge_styles(file_path):
    """Merge duplicate style attributes"""
    
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    original_content = content
    
    # Find all elements with multiple style attributes
    def merge_style_attrs(match):
        full_tag = match.group(0)
        # Extract all style attribute values
        style_pattern = r'style="([^"]*)"'
        styles = re.findall(style_pattern, full_tag)
        
        if len(styles) > 1:
            # Merge all styles
            merged_styles = '; '.join(s.strip().rstrip(';') for s in styles if s.strip())
            # Remove all existing style attributes
            cleaned_tag = re.sub(r'\s*style="[^"]*"', '', full_tag)
            # Add merged style attribute before the closing >
            if '>' in cleaned_tag:
                cleaned_tag = cleaned_tag.replace('>', f' style="{merged_styles}">', 1)
            return cleaned_tag
        return full_tag
    
    # Process all tags that might have multiple style attributes
    tag_pattern = r'<[^>]+style="[^"]*"[^>]*(?:style="[^"]*")+[^>]*>'
    content = re.sub(tag_pattern, merge_style_attrs, content)
    
    # Clean up empty class attributes with trailing spaces
    content = re.sub(r'class="\s+"\s*', '', content)
    content = re.sub(r'class="([^"]*)\s+"\s*', r'class="\1" ', content)
    
    # Only write if content changed
    if content != original_content:
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(content)
        return True
    return False

def main():
    print_colored("="*60, Colors.CYAN)
    print_colored("Merging Duplicate Style Attributes", Colors.CYAN)
    print_colored("="*60, Colors.CYAN)
    print()
    
    tools_dir = Path('./tools')
    html_files = list(tools_dir.rglob('*.html'))
    
    print_colored(f"Scanning {len(html_files)} HTML files...\n", Colors.YELLOW)
    
    fixed_count = 0
    
    for file_path in html_files:
        try:
            if merge_styles(file_path):
                relative_path = file_path.relative_to(Path('.'))
                print_colored(f"[+] Fixed: {relative_path}", Colors.GREEN)
                fixed_count += 1
        except Exception as e:
            relative_path = file_path.relative_to(Path('.'))
            print_colored(f"[X] Error: {relative_path}", Colors.YELLOW)
    
    print()
    print_colored("="*60, Colors.CYAN)
    print_colored(f"[+] Fixed: {fixed_count} files", Colors.GREEN)
    print_colored(f"[-] Unchanged: {len(html_files) - fixed_count} files", Colors.YELLOW)

if __name__ == '__main__':
    main()
