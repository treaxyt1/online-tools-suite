#!/usr/bin/env python3
"""
Complete Website Rename Script
OnlineToolFree → OnlineToolFree
onlinetoolfree.com → onlinetoolfree.com
"""

import os
import re
from pathlib import Path

class WebsiteRenamer:
    def __init__(self):
        self.files_processed = 0
        self.replacements_made = 0
        self.files_modified = 0
        
        # Define all replacements
        self.replacements = [
            # Website name variations
            ('OnlineToolFree', 'OnlineToolFree'),
            ('OnlineToolFree', 'OnlineToolFree'),
            ('OnlineToolFree', 'OnlineToolFree'),
            ('ONLINETOOLFREE', 'ONLINETOOLFREE'),
            ('onlinetoolfree', 'onlinetoolfree'),
            ('onlinetoolfree', 'onlinetoolfree'),
            
            # Domain variations
            ('onlinetoolfree.com', 'onlinetoolfree.com'),
            ('OnlineToolFree.com', 'onlinetoolfree.com'),
            ('https://onlinetoolfree.com', 'https://onlinetoolfree.com'),
            ('http://onlinetoolfree.com', 'http://onlinetoolfree.com'),
            
            # Email addresses
            ('@onlinetoolfree.com', '@onlinetoolfree.com'),
            ('contact@onlinetoolfree.com', 'contact@onlinetoolfree.com'),
            ('support@onlinetoolfree.com', 'support@onlinetoolfree.com'),
            ('privacy@onlinetoolfree.com', 'privacy@onlinetoolfree.com'),
            ('legal@onlinetoolfree.com', 'legal@onlinetoolfree.com'),
            
            # Social media handles
            ('@onlinetoolfree', '@onlinetoolfree'),
            ('/onlinetoolfree', '/onlinetoolfree'),
            
            # Repository names
            ('github.com/onlinetoolfree', 'github.com/onlinetoolfree'),
        ]
    
    def should_process_file(self, filepath):
        """Check if file should be processed"""
        # Skip certain directories
        skip_dirs = ['.git', 'node_modules', '__pycache__', '.venv', 'venv']
        for skip_dir in skip_dirs:
            if skip_dir in str(filepath):
                return False
        
        # Process these file types
        valid_extensions = [
            '.html', '.htm', '.css', '.js', '.json', '.xml', '.txt',
            '.md', '.py', '.php', '.htaccess', '.conf', '.yaml', '.yml'
        ]
        
        return any(str(filepath).endswith(ext) for ext in valid_extensions)
    
    def process_file(self, filepath):
        """Process a single file"""
        try:
            # Read file
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()
            
            original_content = content
            file_replacements = 0
            
            # Apply all replacements
            for old, new in self.replacements:
                if old in content:
                    count = content.count(old)
                    content = content.replace(old, new)
                    file_replacements += count
                    self.replacements_made += count
            
            # Write back if changes were made
            if content != original_content:
                with open(filepath, 'w', encoding='utf-8') as f:
                    f.write(content)
                self.files_modified += 1
                print(f"[UPDATED] {filepath} ({file_replacements} replacements)")
                return True
            
            self.files_processed += 1
            return False
            
        except Exception as e:
            print(f"[ERROR] {filepath}: {str(e)}")
            return False
    
    def scan_and_rename(self, directory='.'):
        """Scan directory and rename all occurrences"""
        print("=" * 70)
        print("WEBSITE RENAME: OnlineToolFree -> OnlineToolFree")
        print("               onlinetoolfree.com -> onlinetoolfree.com")
        print("=" * 70)
        print(f"Scanning directory: {directory}")
        print("=" * 70)
        
        # Get all files
        all_files = []
        for root, dirs, files in os.walk(directory):
            # Skip hidden directories
            dirs[:] = [d for d in dirs if not d.startswith('.')]
            
            for file in files:
                filepath = os.path.join(root, file)
                if self.should_process_file(filepath):
                    all_files.append(filepath)
        
        print(f"\nFound {len(all_files)} files to process")
        print("=" * 70)
        
        # Process each file
        for filepath in all_files:
            self.process_file(filepath)
        
        # Summary
        print("\n" + "=" * 70)
        print("RENAME SUMMARY")
        print("=" * 70)
        print(f"Files Scanned: {len(all_files)}")
        print(f"Files Modified: {self.files_modified}")
        print(f"Files Unchanged: {len(all_files) - self.files_modified}")
        print(f"Total Replacements: {self.replacements_made}")
        print("=" * 70)
        
        if self.files_modified > 0:
            print("\n[SUCCESS] Website renamed successfully!")
            print("\nChanges made:")
            print("  - OnlineToolFree -> OnlineToolFree")
            print("  - onlinetoolfree.com -> onlinetoolfree.com")
            print("  - Email addresses updated")
            print("  - Social media handles updated")
            print("=" * 70)
        else:
            print("\n[INFO] No changes needed - already using OnlineToolFree")
            print("=" * 70)

def main():
    renamer = WebsiteRenamer()
    renamer.scan_and_rename()
    
    # Create verification report
    print("\n" + "=" * 70)
    print("VERIFICATION CHECKLIST")
    print("=" * 70)
    print("Please verify the following:")
    print("  [ ] All page titles updated")
    print("  [ ] All meta descriptions updated")
    print("  [ ] Sitemap.xml updated")
    print("  [ ] Robots.txt updated")
    print("  [ ] Manifest.json updated (if exists)")
    print("  [ ] Schema markup updated")
    print("  [ ] Footer copyright updated")
    print("  [ ] All email addresses updated")
    print("  [ ] Social media links updated")
    print("  [ ] About/Contact/Privacy/Terms pages updated")
    print("  [ ] All internal links working")
    print("  [ ] No broken references")
    print("=" * 70)
    
    return renamer.files_modified > 0

if __name__ == '__main__':
    success = main()
    exit(0 if success else 1)
