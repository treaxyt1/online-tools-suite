#!/usr/bin/env python3
"""
Generate Retro Emulator Tool Pages - Legal & Consistent Design
Creates all emulator pages with proper legal disclaimers
"""

import os
from pathlib import Path

# Legal disclaimer component (reusable)
LEGAL_NOTICE = '''<div class="legal-notice" style="background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%); border-left: 4px solid #f59e0b; padding: var(--space-4); border-radius: var(--radius-lg); margin-bottom: var(--space-6);">
    <div style="display: flex; align-items: start; gap: var(--space-3);">
        <svg class="icon" style="color: #f59e0b; flex-shrink: 0; margin-top: 2px;" viewBox="0 0 24 24">
            <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>
            <line x1="12" y1="9" x2="12" y2="13"/>
            <line x1="12" y1="17" x2="12.01" y2="17"/>
        </svg>
        <div>
            <h4 style="margin: 0 0 var(--space-2) 0; font-weight: var(--font-semibold); color: #92400e;">Legal Notice</h4>
            <p style="margin: 0; font-size: var(--text-sm); color: #78350f; line-height: 1.6;">
                <strong>Emulators are legal software.</strong> However, you must own the original game cartridges or discs to legally create and use personal backups. 
                This site does not host, distribute, or link to copyrighted games or BIOS files. All content is for educational purposes only.
            </p>
        </div>
    </div>
</div>'''

# Emulator data with detailed information
EMULATORS = {
    'epsxe': {
        'name': 'ePSXe',
        'full_name': 'Enhanced PSX Emulator',
        'system': 'PlayStation 1',
        'platforms': ['Windows', 'Linux', 'Android'],
        'features': ['High compatibility', 'Plugin system', 'Save states', 'Gamepad support'],
        'github': 'N/A (Closed source)',
        'website': 'http://www.epsxe.com/',
        'description': 'ePSXe is one of the most popular PlayStation 1 emulators, known for its high compatibility and plugin-based architecture.',
    },
    'duckstation': {
        'name': 'DuckStation',
        'full_name': 'DuckStation PS1 Emulator',
        'system': 'PlayStation 1',
        'platforms': ['Windows', 'macOS', 'Linux', 'Android'],
        'features': ['Modern UI', 'Upscaling', 'Texture filtering', 'PGXP geometry correction'],
        'github': 'https://github.com/stenzek/duckstation',
        'website': 'https://www.duckstation.org/',
        'description': 'DuckStation is a modern, feature-rich PlayStation 1 emulator with focus on accuracy and enhancements.',
    },
    'ppsspp': {
        'name': 'PPSSPP',
        'full_name': 'PlayStation Portable Simulator Suitable for Playing Portably',
        'system': 'PlayStation Portable (PSP)',
        'platforms': ['Windows', 'macOS', 'Linux', 'Android', 'iOS'],
        'features': ['HD rendering', 'Save states', 'Texture scaling', 'Multiplayer support'],
        'github': 'https://github.com/hrydgard/ppsspp',
        'website': 'https://www.ppsspp.org/',
        'description': 'PPSSPP is the best PSP emulator, capable of running games at higher resolutions than the original hardware.',
    },
    'mupen64plus': {
        'name': 'Mupen64Plus',
        'full_name': 'Mupen64Plus N64 Emulator',
        'system': 'Nintendo 64',
        'platforms': ['Windows', 'macOS', 'Linux'],
        'features': ['High accuracy', 'Plugin architecture', 'Widescreen hacks', 'Texture packs'],
        'github': 'https://github.com/mupen64plus',
        'website': 'https://mupen64plus.org/',
        'description': 'Mupen64Plus is an open-source Nintendo 64 emulator with excellent compatibility and enhancement features.',
    },
    'fceux': {
        'name': 'FCEUX',
        'full_name': 'FCE Ultra X',
        'system': 'NES / Famicom',
        'platforms': ['Windows', 'macOS', 'Linux'],
        'features': ['Debugging tools', 'Movie recording', 'Lua scripting', 'TAS support'],
        'github': 'https://github.com/TASEmulators/fceux',
        'website': 'http://fceux.com/',
        'description': 'FCEUX is a feature-rich NES emulator popular among speedrunners and tool-assisted speedrun creators.',
    },
    'nestopia': {
        'name': 'Nestopia',
        'full_name': 'Nestopia UE',
        'system': 'NES / Famicom',
        'platforms': ['Windows', 'macOS', 'Linux'],
        'features': ['Cycle-accurate', 'NSF playback', 'Netplay', 'Video recording'],
        'github': 'https://github.com/0ldsk00l/nestopia',
        'website': 'http://nestopia.sourceforge.net/',
        'description': 'Nestopia is known for its high accuracy in NES emulation, making it ideal for preservation.',
    },
    'snes9x': {
        'name': 'Snes9x',
        'full_name': 'Super Nintendo Entertainment System Emulator',
        'system': 'Super Nintendo (SNES)',
        'platforms': ['Windows', 'macOS', 'Linux'],
        'features': ['High compatibility', 'Netplay', 'Rewind', 'Cheat support'],
        'github': 'https://github.com/snes9xgit/snes9x',
        'website': 'http://www.snes9x.com/',
        'description': 'Snes9x is one of the most popular SNES emulators, balancing accuracy with performance.',
    },
    'mgba': {
        'name': 'mGBA',
        'full_name': 'Modern Game Boy Advance',
        'system': 'Game Boy / Game Boy Color / Game Boy Advance',
        'platforms': ['Windows', 'macOS', 'Linux'],
        'features': ['Accurate emulation', 'Debugging tools', 'Save states', 'Solar sensor support'],
        'github': 'https://github.com/mgba-emu/mgba',
        'website': 'https://mgba.io/',
        'description': 'mGBA is a modern, accurate Game Boy Advance emulator with excellent compatibility.',
    },
    'retroarch': {
        'name': 'RetroArch',
        'full_name': 'RetroArch Multi-System Frontend',
        'system': 'Multi-System (50+ cores)',
        'platforms': ['All major platforms'],
        'features': ['Unified interface', 'Shaders', 'Netplay', 'Achievements'],
        'github': 'https://github.com/libretro/RetroArch',
        'website': 'https://www.retroarch.com/',
        'description': 'RetroArch is a frontend for emulators, game engines, and media players, supporting dozens of systems.',
    },
}

# Utility tools data
UTILITIES = {
    'bios-checker': {
        'name': 'BIOS Checker',
        'description': 'Verify the integrity and compatibility of emulator BIOS files',
        'features': ['MD5/SHA1 verification', 'File size check', 'Format validation', 'Compatibility database'],
    },
    'save-converter': {
        'name': 'Save File Converter',
        'description': 'Convert save files between different emulator formats',
        'features': ['Multiple format support', 'Batch conversion', 'Backup creation', 'Format detection'],
    },
    'controller-mapper': {
        'name': 'Controller Mapping Tester',
        'description': 'Test and configure gamepad inputs for emulators',
        'features': ['Real-time input display', 'Button mapping', 'Deadzone testing', 'Multiple controllers'],
    },
    'fps-tester': {
        'name': 'FPS Performance Tester',
        'description': 'Measure emulator performance and frame rates',
        'features': ['Real-time FPS counter', 'Frame time graph', 'Performance metrics', 'Benchmark mode'],
    },
    'config-generator': {
        'name': 'Emulator Config Generator',
        'description': 'Generate optimal configuration files for various emulators',
        'features': ['System detection', 'Preset templates', 'Custom settings', 'Export configs'],
    },
    'cheat-editor': {
        'name': 'Cheat File Editor',
        'description': 'Create and edit cheat codes for homebrew games',
        'features': ['Code editor', 'Format validation', 'Code library', 'Export/Import'],
    },
    'shader-preview': {
        'name': 'Shader Preset Preview',
        'description': 'Preview CRT and shader effects before applying',
        'features': ['Live preview', 'Shader library', 'Custom parameters', 'Before/After comparison'],
    },
    'emulator-compare': {
        'name': 'Emulator Comparison Tool',
        'description': 'Compare features and compatibility of different emulators',
        'features': ['Side-by-side comparison', 'Feature matrix', 'Performance data', 'Recommendations'],
    },
    'aspect-ratio': {
        'name': 'Aspect Ratio Calculator',
        'description': 'Calculate proper aspect ratios for retro gaming',
        'features': ['Common ratios', 'Custom calculations', 'Pixel perfect modes', 'Resolution suggestions'],
    },
    'input-latency': {
        'name': 'Input Latency Tester',
        'description': 'Measure controller input lag and latency',
        'features': ['Latency measurement', 'Visual feedback', 'Multiple tests', 'Results export'],
    },
}

def create_emulator_page(slug, data):
    """Create an emulator information page"""
    
    features_html = '\n'.join([f'<li>{feature}</li>' for feature in data['features']])
    platforms_html = ' / '.join(data['platforms'])
    
    github_link = f'<a href="{data["github"]}" target="_blank" rel="noopener" class="btn btn-secondary">View on GitHub</a>' if data['github'] != 'N/A (Closed source)' else ''
    
    html = f'''<!DOCTYPE html>
<html lang="en" data-theme="light">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- SEO Meta Tags -->
    <title>{data['name']} - {data['system']} Emulator | OnlineToolFree</title>
    <meta name="description" content="{data['description']} Legal emulator software for {data['system']}.">
    <link rel="canonical" href="https://onlinetoolfree.com/tools/emulators/{slug}.html">

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">

    <!-- Styles -->
    <link rel="stylesheet" href="../../css/design-system.css">

    <!-- Scripts -->
    <script src="../../js/tools.js"></script>
    <script src="../../js/ui.js"></script>
    <script src="../../js/app.js"></script>
</head>

<body>
    <!-- Header -->
    <header class="header"></header>

    <!-- Tool Layout with Sidebar -->
    <div class="tool-layout">
        <!-- Sidebar -->
        <aside class="tool-sidebar" id="tool-sidebar"></aside>

        <!-- Main Content -->
        <main class="tool-main">
            <div class="tool-page" style="max-width: 900px; margin: 0; padding: 0;">
                <!-- Tool Header -->
                <div class="tool-header" style="text-align: left; margin-bottom: var(--space-6);">
                    <div style="display: flex; align-items: center; gap: var(--space-4); margin-bottom: var(--space-4);">
                        <div class="tool-icon-large" style="margin: 0;">
                            <svg class="icon icon-lg" viewBox="0 0 24 24">
                                <rect x="2" y="7" width="20" height="14" rx="2" ry="2"/>
                                <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/>
                            </svg>
                        </div>
                        <div>
                            <h1 class="tool-title" style="font-size: var(--text-2xl);">{data['name']}</h1>
                            <p class="tool-description" style="font-size: var(--text-base); margin: 0;">
                                {data['full_name']} - {data['system']} Emulator
                            </p>
                        </div>
                    </div>
                </div>

                <!-- Legal Notice -->
                {LEGAL_NOTICE}

                <!-- Emulator Information -->
                <div class="tool-interface">
                    <div class="tool-section" style="margin-bottom: var(--space-6);">
                        <h2 style="font-size: var(--text-xl); font-weight: var(--font-semibold); margin-bottom: var(--space-4);">
                            About {data['name']}
                        </h2>
                        <p style="margin-bottom: var(--space-4); line-height: 1.6;">
                            {data['description']}
                        </p>
                        
                        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: var(--space-4); margin-top: var(--space-6);">
                            <div style="padding: var(--space-4); background: var(--bg-tertiary); border-radius: var(--radius-lg);">
                                <h3 style="font-size: var(--text-sm); font-weight: var(--font-semibold); color: var(--text-secondary); margin-bottom: var(--space-2);">
                                    SYSTEM
                                </h3>
                                <p style="font-size: var(--text-lg); font-weight: var(--font-semibold); margin: 0;">
                                    {data['system']}
                                </p>
                            </div>
                            
                            <div style="padding: var(--space-4); background: var(--bg-tertiary); border-radius: var(--radius-lg);">
                                <h3 style="font-size: var(--text-sm); font-weight: var(--font-semibold); color: var(--text-secondary); margin-bottom: var(--space-2);">
                                    PLATFORMS
                                </h3>
                                <p style="font-size: var(--text-base); font-weight: var(--font-medium); margin: 0;">
                                    {platforms_html}
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="tool-section" style="margin-bottom: var(--space-6);">
                        <h2 style="font-size: var(--text-xl); font-weight: var(--font-semibold); margin-bottom: var(--space-4);">
                            Key Features
                        </h2>
                        <ul style="list-style-type: disc; padding-left: var(--space-6); line-height: 1.8;">
                            {features_html}
                        </ul>
                    </div>

                    <div class="tool-actions">
                        <a href="{data['website']}" target="_blank" rel="noopener" class="btn btn-primary">
                            <svg class="icon" viewBox="0 0 24 24">
                                <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>
                                <polyline points="15 3 21 3 21 9"/>
                                <line x1="10" y1="14" x2="21" y2="3"/>
                            </svg>
                            Official Website
                        </a>
                        {github_link}
                    </div>
                </div>

                <!-- Information Section -->
                <section class="info-section" style="margin-top: var(--space-8); padding: var(--space-6); background: var(--bg-primary); border: 1px solid var(--border-light); border-radius: var(--radius-xl);">
                    <h2 style="font-size: var(--text-xl); font-weight: var(--font-semibold); margin-bottom: var(--space-4);">
                        Important Information
                    </h2>
                    <p style="margin-bottom: var(--space-4);">
                        <strong>This page provides information about the {data['name']} emulator software only.</strong> 
                        We do not provide downloads, ROMs, BIOS files, or any copyrighted content.
                    </p>
                    <p style="margin-bottom: var(--space-4);">
                        To use this emulator legally:
                    </p>
                    <ol style="padding-left: var(--space-6); line-height: 1.8;">
                        <li>Download the emulator from the official website</li>
                        <li>Obtain BIOS files from your own {data['system']} console (if required)</li>
                        <li>Create backups of games you physically own</li>
                        <li>Never download or distribute copyrighted games</li>
                    </ol>
                </section>
            </div>
        </main>
    </div>

    <!-- Mobile Sidebar Toggle -->
    <button class="sidebar-toggle" id="sidebar-toggle">
        <svg class="icon" viewBox="0 0 24 24">
            <line x1="4" y1="12" x2="20" y2="12" />
            <line x1="4" y1="6" x2="20" y2="6" />
            <line x1="4" y1="18" x2="20" y2="18" />
        </svg>
    </button>

    <!-- Footer -->
    <footer class="footer"></footer>

    <script>
        document.addEventListener('DOMContentLoaded', () => {{
            Components.renderHeader();
            Components.renderMobileMenu();
            Components.renderSidebar('tool-sidebar');
            Components.renderFooter();

            const sidebarToggle = document.getElementById('sidebar-toggle');
            const sidebar = document.getElementById('tool-sidebar');
            sidebarToggle?.addEventListener('click', () => sidebar?.classList.toggle('open'));

            if (window.ThemeManager) ThemeManager.init();
            if (window.ResponsiveManager) ResponsiveManager.init();
        }});
    </script>
</body>

</html>'''
    
    return html

def create_utility_page(slug, data):
    """Create a utility tool page"""
    
    features_html = '\n'.join([f'<li>{feature}</li>' for feature in data['features']])
    
    html = f'''<!DOCTYPE html>
<html lang="en" data-theme="light">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- SEO Meta Tags -->
    <title>{data['name']} - Emulator Utility | OnlineToolFree</title>
    <meta name="description" content="{data['description']} Free online tool for retro gaming emulation.">
    <link rel="canonical" href="https://onlinetoolfree.com/tools/emulators/{slug}.html">

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">

    <!-- Styles -->
    <link rel="stylesheet" href="../../css/design-system.css">

    <!-- Scripts -->
    <script src="../../js/tools.js"></script>
    <script src="../../js/ui.js"></script>
    <script src="../../js/app.js"></script>
</head>

<body>
    <!-- Header -->
    <header class="header"></header>

    <!-- Tool Layout with Sidebar -->
    <div class="tool-layout">
        <!-- Sidebar -->
        <aside class="tool-sidebar" id="tool-sidebar"></aside>

        <!-- Main Content -->
        <main class="tool-main">
            <div class="tool-page" style="max-width: 900px; margin: 0; padding: 0;">
                <!-- Tool Header -->
                <div class="tool-header" style="text-align: left; margin-bottom: var(--space-6);">
                    <div style="display: flex; align-items: center; gap: var(--space-4); margin-bottom: var(--space-4);">
                        <div class="tool-icon-large" style="margin: 0;">
                            <svg class="icon icon-lg" viewBox="0 0 24 24">
                                <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/>
                            </svg>
                        </div>
                        <div>
                            <h1 class="tool-title" style="font-size: var(--text-2xl);">{data['name']}</h1>
                            <p class="tool-description" style="font-size: var(--text-base); margin: 0;">
                                {data['description']}
                            </p>
                        </div>
                    </div>
                </div>

                <!-- Legal Notice -->
                {LEGAL_NOTICE}

                <!-- Tool Interface -->
                <div class="tool-interface">
                    <div class="tool-section" style="margin-bottom: var(--space-6);">
                        <h2 style="font-size: var(--text-xl); font-weight: var(--font-semibold); margin-bottom: var(--space-4);">
                            Features
                        </h2>
                        <ul style="list-style-type: disc; padding-left: var(--space-6); line-height: 1.8;">
                            {features_html}
                        </ul>
                    </div>

                    <div class="tool-section" style="padding: var(--space-8); background: var(--gradient-subtle); border-radius: var(--radius-xl); text-align: center;">
                        <svg class="icon icon-xl" style="margin: 0 auto var(--space-4); color: var(--primary-600);" viewBox="0 0 24 24">
                            <circle cx="12" cy="12" r="10"/>
                            <line x1="12" y1="8" x2="12" y2="12"/>
                            <line x1="12" y1="16" x2="12.01" y2="16"/>
                        </svg>
                        <h3 style="font-size: var(--text-lg); font-weight: var(--font-semibold); margin-bottom: var(--space-2);">
                            Tool Coming Soon
                        </h3>
                        <p style="color: var(--text-secondary); margin: 0;">
                            This utility tool is currently under development. Check back soon!
                        </p>
                    </div>
                </div>

                <!-- Information Section -->
                <section class="info-section" style="margin-top: var(--space-8); padding: var(--space-6); background: var(--bg-primary); border: 1px solid var(--border-light); border-radius: var(--radius-xl);">
                    <h2 style="font-size: var(--text-xl); font-weight: var(--font-semibold); margin-bottom: var(--space-4);">
                        About This Tool
                    </h2>
                    <p>
                        The {data['name']} is designed to help retro gaming enthusiasts optimize their emulation experience. 
                        All tools are client-side and respect user privacy - your files never leave your browser.
                    </p>
                </section>
            </div>
        </main>
    </div>

    <!-- Mobile Sidebar Toggle -->
    <button class="sidebar-toggle" id="sidebar-toggle">
        <svg class="icon" viewBox="0 0 24 24">
            <line x1="4" y1="12" x2="20" y2="12" />
            <line x1="4" y1="6" x2="20" y2="6" />
            <line x1="4" y1="18" x2="20" y2="18" />
        </svg>
    </button>

    <!-- Footer -->
    <footer class="footer"></footer>

    <script>
        document.addEventListener('DOMContentLoaded', () => {{
            Components.renderHeader();
            Components.renderMobileMenu();
            Components.renderSidebar('tool-sidebar');
            Components.renderFooter();

            const sidebarToggle = document.getElementById('sidebar-toggle');
            const sidebar = document.getElementById('tool-sidebar');
            sidebarToggle?.addEventListener('click', () => sidebar?.classList.toggle('open'));

            if (window.ThemeManager) ThemeManager.init();
            if (window.ResponsiveManager) ResponsiveManager.init();
        }});
    </script>
</body>

</html>'''
    
    return html

def main():
    print("="*60)
    print("Creating Retro Emulator Pages")
    print("="*60)
    print()
    
    # Create emulators directory
    emulators_dir = Path('./tools/emulators')
    emulators_dir.mkdir(parents=True, exist_ok=True)
    
    # Create emulator pages
    print("Creating emulator information pages...")
    for slug, data in EMULATORS.items():
        file_path = emulators_dir / f'{slug}.html'
        html = create_emulator_page(slug, data)
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(html)
        print(f"  [+] Created: {file_path}")
    
    # Create utility pages
    print("\nCreating utility tool pages...")
    for slug, data in UTILITIES.items():
        file_path = emulators_dir / f'{slug}.html'
        html = create_utility_page(slug, data)
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(html)
        print(f"  [+] Created: {file_path}")
    
    print()
    print("="*60)
    print(f"✓ Created {len(EMULATORS)} emulator pages")
    print(f"✓ Created {len(UTILITIES)} utility pages")
    print(f"✓ Total: {len(EMULATORS) + len(UTILITIES)} pages")
    print("="*60)
    print()
    print("All pages include:")
    print("  • Legal disclaimers")
    print("  • Consistent design")
    print("  • Sidebar navigation")
    print("  • SEO optimization")
    print("  • No copyrighted content")

if __name__ == '__main__':
    main()
