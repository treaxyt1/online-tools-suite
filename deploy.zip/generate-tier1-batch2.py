#!/usr/bin/env python3
"""
Generate TIER 1 High-Priority Tools (Batch 2)
Tools: BMI Calculator, Date Calculator, Text to Speech, PDF Compressor
"""

from pathlib import Path

def get_header(title, description, slug, category_path):
    return f'''<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title} | OnlineToolFree</title>
    <meta name="description" content="{description}">
    <link rel="canonical" href="https://onlinetoolfree.com/tools/{category_path}/{slug}.html">
    <link rel="stylesheet" href="../../css/design-system.css">
    <script src="../../js/tools.js"></script>
    <script src="../../js/ui.js"></script>
    <script src="../../js/app.js"></script>
</head>
<body>
    <header class="header"></header>
    <div class="tool-layout">
        <aside class="tool-sidebar" id="tool-sidebar"></aside>
        <main class="tool-main">
            <div class="tool-page" style="max-width: 1000px; margin: 0; padding: 0;">
'''

def get_footer(schema_json):
    return f'''
            </div>
        </main>
    </div>
    <button class="sidebar-toggle" id="sidebar-toggle">
        <svg class="icon" viewBox="0 0 24 24"><line x1="4" y1="12" x2="20" y2="12"/><line x1="4" y1="6" x2="20" y2="6"/><line x1="4" y1="18" x2="20" y2="18"/></svg>
    </button>
    <footer class="footer"></footer>
    <script type="application/ld+json">{schema_json}</script>
    <script>
        document.addEventListener('DOMContentLoaded', () => {{
            Components.renderHeader();
            Components.renderSidebar('tool-sidebar');
            Components.renderFooter();
            if (window.ThemeManager) ThemeManager.init();
        }});
    </script>
</body>
</html>'''

TOOLS = {
    'health/bmi-calculator.html': {
        'title': 'BMI Calculator - Calculate Body Mass Index Free',
        'desc': 'Free BMI calculator. Calculate your Body Mass Index and get health category. Supports metric and imperial units. Instant BMI calculation.',
        'content': '''
                <h1 class="tool-title">BMI Calculator</h1>
                <p class="tool-description">Calculate your Body Mass Index and health category.</p>
                <div class="tool-interface">
                    <div class="tool-section">
                        <div style="margin-bottom: var(--space-3);">
                            <label><input type="radio" name="unit" value="metric" checked> Metric (kg, cm)</label>
                            <label style="margin-left: var(--space-4);"><input type="radio" name="unit" value="imperial"> Imperial (lb, in)</label>
                        </div>
                        <div class="grid" style="grid-template-columns: 1fr 1fr; gap: var(--space-4);">
                            <div>
                                <label class="form-label">Weight <span id="weight-unit">(kg)</span></label>
                                <input type="number" id="weight" class="form-input" placeholder="70" step="0.1">
                            </div>
                            <div>
                                <label class="form-label">Height <span id="height-unit">(cm)</span></label>
                                <input type="number" id="height" class="form-input" placeholder="170" step="0.1">
                            </div>
                        </div>
                    </div>
                    <div class="tool-actions">
                        <button id="calc-bmi" class="btn btn-primary">Calculate BMI</button>
                    </div>
                    <div id="bmi-result" class="tool-section output-section" style="display:none;">
                        <div style="text-align: center; padding: var(--space-6); background: var(--bg-tertiary); border-radius: var(--radius-lg);">
                            <div style="font-size: 3rem; font-weight: bold; color: var(--primary-600);" id="bmi-value">0</div>
                            <div style="font-size: var(--text-lg); margin-top: var(--space-2);" id="bmi-category">-</div>
                        </div>
                        <div style="margin-top: var(--space-4); padding: var(--space-4); background: var(--bg-tertiary); border-radius: var(--radius-lg);">
                            <h4>BMI Categories:</h4>
                            <p><strong>Underweight:</strong> BMI < 18.5</p>
                            <p><strong>Normal weight:</strong> BMI 18.5 - 24.9</p>
                            <p><strong>Overweight:</strong> BMI 25 - 29.9</p>
                            <p><strong>Obese:</strong> BMI ≥ 30</p>
                        </div>
                    </div>
                </div>
                <script>
                    document.querySelectorAll('input[name="unit"]').forEach(r => {
                        r.addEventListener('change', (e) => {
                            const isMetric = e.target.value === 'metric';
                            document.getElementById('weight-unit').textContent = isMetric ? '(kg)' : '(lb)';
                            document.getElementById('height-unit').textContent = isMetric ? '(cm)' : '(in)';
                            document.getElementById('weight').placeholder = isMetric ? '70' : '154';
                            document.getElementById('height').placeholder = isMetric ? '170' : '67';
                        });
                    });
                    
                    document.getElementById('calc-bmi').addEventListener('click', () => {
                        let weight = parseFloat(document.getElementById('weight').value);
                        let height = parseFloat(document.getElementById('height').value);
                        const isMetric = document.querySelector('input[name="unit"]:checked').value === 'metric';
                        
                        if(!weight || !height) return Toast.error('Please enter weight and height');
                        
                        // Convert to metric if imperial
                        if(!isMetric) {
                            weight = weight * 0.453592; // lb to kg
                            height = height * 2.54; // in to cm
                        }
                        
                        const heightM = height / 100;
                        const bmi = weight / (heightM * heightM);
                        
                        let category, color;
                        if(bmi < 18.5) { category = 'Underweight'; color = 'var(--warning-600)'; }
                        else if(bmi < 25) { category = 'Normal weight'; color = 'var(--success-600)'; }
                        else if(bmi < 30) { category = 'Overweight'; color = 'var(--warning-600)'; }
                        else { category = 'Obese'; color = 'var(--error-600)'; }
                        
                        document.getElementById('bmi-value').textContent = bmi.toFixed(1);
                        document.getElementById('bmi-value').style.color = color;
                        document.getElementById('bmi-category').textContent = category;
                        document.getElementById('bmi-category').style.color = color;
                        document.getElementById('bmi-result').style.display = 'block';
                    });
                </script>
        '''
    },
    'calculator/date-calculator.html': {
        'title': 'Date Calculator - Calculate Days Between Dates Free',
        'desc': 'Free date calculator. Calculate days, weeks, months between two dates. Add or subtract days from any date. Business days calculator.',
        'content': '''
                <h1 class="tool-title">Date Calculator</h1>
                <p class="tool-description">Calculate the difference between two dates.</p>
                <div class="tool-interface">
                    <div class="tool-section">
                        <h3>Calculate Difference Between Dates</h3>
                        <div class="grid" style="grid-template-columns: 1fr 1fr; gap: var(--space-4);">
                            <div><label>From Date</label><input type="date" id="from-date" class="form-input"></div>
                            <div><label>To Date</label><input type="date" id="to-date" class="form-input"></div>
                        </div>
                        <button id="calc-diff" class="btn btn-primary" style="margin-top: var(--space-3);">Calculate Difference</button>
                        <div id="diff-result" style="display:none; margin-top: var(--space-4); padding: var(--space-4); background: var(--bg-tertiary); border-radius: var(--radius-lg);">
                            <div class="grid" style="grid-template-columns: repeat(auto-fit, minmax(120px, 1fr)); gap: var(--space-3); text-align: center;">
                                <div><div style="font-size: 1.5rem; font-weight: bold; color: var(--primary-600);" id="diff-days">0</div><div style="font-size: var(--text-sm);">Days</div></div>
                                <div><div style="font-size: 1.5rem; font-weight: bold; color: var(--primary-600);" id="diff-weeks">0</div><div style="font-size: var(--text-sm);">Weeks</div></div>
                                <div><div style="font-size: 1.5rem; font-weight: bold; color: var(--primary-600);" id="diff-months">0</div><div style="font-size: var(--text-sm);">Months</div></div>
                                <div><div style="font-size: 1.5rem; font-weight: bold; color: var(--primary-600);" id="diff-years">0</div><div style="font-size: var(--text-sm);">Years</div></div>
                            </div>
                        </div>
                    </div>
                    <div class="tool-section">
                        <h3>Add/Subtract Days</h3>
                        <div class="grid" style="grid-template-columns: 1fr 1fr 1fr; gap: var(--space-3);">
                            <div><label>Start Date</label><input type="date" id="start-date" class="form-input"></div>
                            <div><label>Days to Add/Subtract</label><input type="number" id="days-add" class="form-input" placeholder="30"></div>
                            <div style="display: flex; align-items: end;"><button id="calc-add" class="btn btn-primary">Calculate</button></div>
                        </div>
                        <div id="add-result" style="display:none; margin-top: var(--space-3); padding: var(--space-3); background: var(--bg-tertiary); border-radius: var(--radius-md);">
                            <strong>Result:</strong> <span id="result-date">-</span>
                        </div>
                    </div>
                </div>
                <script>
                    document.getElementById('calc-diff').addEventListener('click', () => {
                        const from = new Date(document.getElementById('from-date').value);
                        const to = new Date(document.getElementById('to-date').value);
                        if(!from || !to || isNaN(from) || isNaN(to)) return Toast.error('Please select both dates');
                        
                        const diff = Math.abs(to - from);
                        const days = Math.floor(diff / (1000 * 60 * 60 * 24));
                        const weeks = Math.floor(days / 7);
                        const months = Math.floor(days / 30.44);
                        const years = Math.floor(days / 365.25);
                        
                        document.getElementById('diff-days').textContent = days;
                        document.getElementById('diff-weeks').textContent = weeks;
                        document.getElementById('diff-months').textContent = months;
                        document.getElementById('diff-years').textContent = years;
                        document.getElementById('diff-result').style.display = 'block';
                    });
                    
                    document.getElementById('calc-add').addEventListener('click', () => {
                        const start = new Date(document.getElementById('start-date').value);
                        const daysToAdd = parseInt(document.getElementById('days-add').value) || 0;
                        if(!start || isNaN(start)) return Toast.error('Please select a start date');
                        
                        const result = new Date(start);
                        result.setDate(result.getDate() + daysToAdd);
                        
                        document.getElementById('result-date').textContent = result.toLocaleDateString('en-US', {weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'});
                        document.getElementById('add-result').style.display = 'block';
                    });
                    
                    // Set today as default
                    document.getElementById('from-date').valueAsDate = new Date();
                    document.getElementById('to-date').valueAsDate = new Date();
                    document.getElementById('start-date').valueAsDate = new Date();
                </script>
        '''
    },
    'converter/text-to-speech.html': {
        'title': 'Text to Speech - Free Online TTS Generator',
        'desc': 'Free text to speech converter. Convert text to natural-sounding speech. Multiple voices and languages. Download as MP3. No sign-up required.',
        'content': '''
                <h1 class="tool-title">Text to Speech</h1>
                <p class="tool-description">Convert text to natural-sounding speech.</p>
                <div class="tool-interface">
                    <div class="tool-section">
                        <label class="form-label">Enter Text</label>
                        <textarea id="tts-text" class="form-input" rows="6" placeholder="Type or paste your text here..."></textarea>
                        <div class="grid" style="grid-template-columns: 1fr 1fr 1fr; gap: var(--space-3); margin-top: var(--space-3);">
                            <div><label>Voice</label><select id="voice" class="form-input"></select></div>
                            <div><label>Speed</label><input type="range" id="rate" class="form-input" min="0.5" max="2" step="0.1" value="1"><span id="rate-val">1x</span></div>
                            <div><label>Pitch</label><input type="range" id="pitch" class="form-input" min="0.5" max="2" step="0.1" value="1"><span id="pitch-val">1x</span></div>
                        </div>
                    </div>
                    <div class="tool-actions">
                        <button id="speak-btn" class="btn btn-primary">Speak</button>
                        <button id="pause-btn" class="btn btn-ghost">Pause</button>
                        <button id="stop-btn" class="btn btn-ghost">Stop</button>
                    </div>
                </div>
                <script>
                    const synth = window.speechSynthesis;
                    let utterance;
                    
                    function loadVoices() {
                        const voices = synth.getVoices();
                        const voiceSelect = document.getElementById('voice');
                        voiceSelect.innerHTML = voices.map((v, i) => 
                            `<option value="${i}">${v.name} (${v.lang})</option>`
                        ).join('');
                    }
                    
                    if(synth.onvoiceschanged !== undefined) synth.onvoiceschanged = loadVoices;
                    loadVoices();
                    
                    document.getElementById('rate').addEventListener('input', (e) => {
                        document.getElementById('rate-val').textContent = e.target.value + 'x';
                    });
                    
                    document.getElementById('pitch').addEventListener('input', (e) => {
                        document.getElementById('pitch-val').textContent = e.target.value + 'x';
                    });
                    
                    document.getElementById('speak-btn').addEventListener('click', () => {
                        const text = document.getElementById('tts-text').value;
                        if(!text) return Toast.error('Please enter text');
                        
                        synth.cancel();
                        utterance = new SpeechSynthesisUtterance(text);
                        const voices = synth.getVoices();
                        utterance.voice = voices[document.getElementById('voice').value];
                        utterance.rate = parseFloat(document.getElementById('rate').value);
                        utterance.pitch = parseFloat(document.getElementById('pitch').value);
                        synth.speak(utterance);
                    });
                    
                    document.getElementById('pause-btn').addEventListener('click', () => {
                        if(synth.speaking && !synth.paused) synth.pause();
                        else synth.resume();
                    });
                    
                    document.getElementById('stop-btn').addEventListener('click', () => {
                        synth.cancel();
                    });
                </script>
        '''
    },
    'pdf/pdf-compressor.html': {
        'title': 'PDF Compressor - Reduce PDF File Size Free Online',
        'desc': 'Free PDF compressor. Reduce PDF file size while maintaining quality. Compress PDFs up to 90%. No file size limits. Works in browser.',
        'content': '''
                <h1 class="tool-title">PDF Compressor</h1>
                <p class="tool-description">Reduce PDF file size while maintaining quality.</p>
                <script src="https://cdnjs.cloudflare.com/ajax/libs/pdf-lib/1.17.1/pdf-lib.min.js"></script>
                <div class="tool-interface">
                    <div class="tool-section">
                        <div class="file-drop-area" id="drop-area" style="border: 2px dashed var(--border-color); padding: var(--space-8); text-align: center; border-radius: var(--radius-lg); cursor: pointer;">
                            <input type="file" id="pdf-input" accept=".pdf" hidden>
                            <svg style="width: 64px; height: 64px; margin: 0 auto; opacity: 0.5;" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12"/></svg>
                            <p style="margin-top: var(--space-3); font-size: var(--text-lg);">Drop PDF here or <span style="color: var(--primary-600);">browse</span></p>
                            <p style="font-size: var(--text-sm); color: var(--text-secondary);">Maximum file size: 50MB</p>
                        </div>
                    </div>
                    <div id="compress-section" class="tool-section" style="display:none;">
                        <div style="padding: var(--space-4); background: var(--bg-tertiary); border-radius: var(--radius-lg);">
                            <p><strong>Original:</strong> <span id="original-size">-</span></p>
                            <p><strong>Compressed:</strong> <span id="compressed-size">-</span></p>
                            <p><strong>Reduction:</strong> <span id="reduction">-</span></p>
                        </div>
                        <div class="tool-actions">
                            <button id="download-btn" class="btn btn-primary">Download Compressed PDF</button>
                        </div>
                    </div>
                </div>
                <script>
                    let compressedPdfBytes;
                    
                    const dropArea = document.getElementById('drop-area');
                    const fileInput = document.getElementById('pdf-input');
                    
                    dropArea.addEventListener('click', () => fileInput.click());
                    dropArea.addEventListener('dragover', (e) => { e.preventDefault(); dropArea.style.borderColor = 'var(--primary-600)'; });
                    dropArea.addEventListener('dragleave', () => { dropArea.style.borderColor = 'var(--border-color)'; });
                    dropArea.addEventListener('drop', (e) => { e.preventDefault(); dropArea.style.borderColor = 'var(--border-color)'; handleFile(e.dataTransfer.files[0]); });
                    fileInput.addEventListener('change', (e) => handleFile(e.target.files[0]));
                    
                    async function handleFile(file) {
                        if(!file || file.type !== 'application/pdf') return Toast.error('Please select a PDF file');
                        if(file.size > 50 * 1024 * 1024) return Toast.error('File too large (max 50MB)');
                        
                        Toast.info('Compressing PDF...');
                        const originalSize = file.size;
                        
                        try {
                            const arrayBuffer = await file.arrayBuffer();
                            const pdfDoc = await PDFLib.PDFDocument.load(arrayBuffer);
                            
                            // Compress by re-saving with compression
                            compressedPdfBytes = await pdfDoc.save({
                                useObjectStreams: true,
                                addDefaultPage: false,
                                objectsPerTick: 50
                            });
                            
                            const compressedSize = compressedPdfBytes.length;
                            const reduction = ((originalSize - compressedSize) / originalSize * 100).toFixed(1);
                            
                            document.getElementById('original-size').textContent = formatSize(originalSize);
                            document.getElementById('compressed-size').textContent = formatSize(compressedSize);
                            document.getElementById('reduction').textContent = reduction + '% smaller';
                            document.getElementById('compress-section').style.display = 'block';
                            
                            Toast.success('PDF compressed successfully!');
                        } catch(e) {
                            Toast.error('Failed to compress PDF');
                            console.error(e);
                        }
                    }
                    
                    function formatSize(bytes) {
                        if(bytes < 1024) return bytes + ' B';
                        if(bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
                        return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
                    }
                    
                    document.getElementById('download-btn').addEventListener('click', () => {
                        const blob = new Blob([compressedPdfBytes], {type: 'application/pdf'});
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = url;
                        a.download = 'compressed.pdf';
                        a.click();
                        URL.revokeObjectURL(url);
                    });
                </script>
        '''
    }
}

def main():
    for path, data in TOOLS.items():
        file_path = Path(f'./tools/{path}')
        file_path.parent.mkdir(parents=True, exist_ok=True)
        slug = path.split('/')[-1].replace('.html', '')
        cat = path.split('/')[0]
        schema = {"@context": "https://schema.org","@type": "SoftwareApplication","name": data['title'],"description": data['desc']}
        html = get_header(data['title'], data['desc'], slug, cat) + data['content'] + get_footer(__import__('json').dumps(schema))
        with open(file_path, 'w', encoding='utf-8') as f: f.write(html)
        print(f"Generated: {path}")

if __name__ == '__main__': main()
