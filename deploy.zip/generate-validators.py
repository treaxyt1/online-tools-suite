#!/usr/bin/env python3
"""
Generate VALIDATOR TOOLS - 100% Client-Side Validation
Email, Phone, URL, Credit Card, IP, and more
All with SEO content, FAQ, mobile-responsive
"""

from pathlib import Path
import json

VALIDATOR_TEMPLATE = '''<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title} - Free Online Validator</title>
    <meta name="description" content="{description}">
    <meta name="keywords" content="{keywords}">
    <link rel="canonical" href="https://onlinetoolfree.com/tools/validator/{slug}.html">
    <link rel="stylesheet" href="../../css/design-system.css">
</head>
<body>
    <header class="header"></header>
    <div class="tool-layout">
        <aside class="tool-sidebar" id="tool-sidebar"></aside>
        <main class="tool-main">
            <div class="tool-page">
                <h1 class="tool-title">{h1_title}</h1>
                <p class="tool-description">{tool_description}</p>
                
                <div class="tool-stats" style="padding: var(--space-3); background: var(--primary-50); border-radius: var(--radius-md); margin: var(--space-4) 0; display: flex; gap: var(--space-4); flex-wrap: wrap;">
                    <span>✅ 100% Free</span>
                    <span>🔒 Client-Side Only</span>
                    <span>⚡ Instant Validation</span>
                    <span>📱 Mobile-Friendly</span>
                </div>

                <div class="tool-interface">
                    <div class="tool-section">
                        <label for="input">{input_label}</label>
                        <textarea id="input" class="form-input" rows="6" placeholder="{placeholder}" style="font-family: monospace;"></textarea>
                    </div>
                    <div class="tool-actions">
                        <button id="validateBtn" class="btn btn-primary">Validate</button>
                        <button id="clearBtn" class="btn btn-ghost">Clear</button>
                    </div>
                    <div id="result" class="tool-section output-section" style="display:none;">
                        <div id="validationResult"></div>
                    </div>
                </div>

                <div class="tool-content" style="margin-top: var(--space-8); padding: var(--space-6);">
                    {seo_content}
                </div>

                <div class="faq-section" style="margin-top: var(--space-8); padding: var(--space-6); background: var(--bg-secondary); border-radius: var(--radius-lg);">
                    <h2>Frequently Asked Questions</h2>
                    {faq_content}
                </div>
            </div>
        </main>
    </div>
    <button class="sidebar-toggle" id="sidebar-toggle">☰</button>
    <footer class="footer"></footer>
    
    <script src="../../js/tools.js"></script>
    <script src="../../js/ui.js"></script>
    <script src="../../js/app.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', () => {{
            if(window.Components) {{
                Components.renderHeader();
                Components.renderSidebar('tool-sidebar');
                Components.renderFooter();
            }}
            if(window.ThemeManager) ThemeManager.init();
        }});

        {validation_script}

        document.getElementById('validateBtn').addEventListener('click', () => {{
            const input = document.getElementById('input').value.trim();
            if(!input) {{
                if(window.Toast) Toast.error('Please enter {input_type} to validate');
                return;
            }}
            
            const results = validateInput(input);
            displayResults(results);
        }});

        document.getElementById('clearBtn').addEventListener('click', () => {{
            document.getElementById('input').value = '';
            document.getElementById('result').style.display = 'none';
        }});

        function displayResults(results) {{
            const resultDiv = document.getElementById('validationResult');
            const resultSection = document.getElementById('result');
            
            let html = '<div style="display: flex; flex-direction: column; gap: var(--space-3);">';
            
            results.forEach(item => {{
                const icon = item.valid ? '✅' : '❌';
                const color = item.valid ? 'var(--success-600)' : 'var(--error-600)';
                const bgColor = item.valid ? 'var(--success-50)' : 'var(--error-50)';
                
                html += `<div style="padding: var(--space-3); background: ${{bgColor}}; border-left: 4px solid ${{color}}; border-radius: var(--radius-md);">
                    <div style="display: flex; align-items: center; gap: var(--space-2);">
                        <span style="font-size: 1.5rem;">${{icon}}</span>
                        <div style="flex: 1;">
                            <strong>${{item.value}}</strong>
                            <p style="margin: 5px 0 0 0; color: var(--text-secondary); font-size: var(--text-sm);">${{item.message}}</p>
                        </div>
                    </div>
                </div>`;
            }});
            
            html += '</div>';
            resultDiv.innerHTML = html;
            resultSection.style.display = 'block';
            
            if(window.Toast) {{
                const validCount = results.filter(r => r.valid).length;
                const totalCount = results.length;
                Toast.success(`Validated ${{totalCount}} item(s): ${{validCount}} valid, ${{totalCount - validCount}} invalid`);
            }}
        }}
    </script>
</body>
</html>'''

VALIDATORS = [
    {
        'name': 'Email Validator',
        'slug': 'email-validator',
        'searches': '45000',
        'description': 'Free email validator. Validate email addresses instantly. Check email format and syntax. 100% client-side validation.',
        'keywords': 'email validator, validate email, check email, email verification',
        'input_label': 'Enter Email Address(es)',
        'placeholder': 'example@domain.com\nuser@example.org\ntest@test.co.uk',
        'input_type': 'email address(es)',
        'validation_script': '''
        function validateInput(input) {
            const emails = input.split('\\n').filter(e => e.trim());
            const emailRegex = /^[a-zA-Z0-9.!#$%&'*+\\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
            
            return emails.map(email => {
                const trimmed = email.trim();
                const valid = emailRegex.test(trimmed);
                
                let message = '';
                if(valid) {
                    const parts = trimmed.split('@');
                    message = `Valid email format. Domain: ${parts[1]}`;
                } else {
                    if(!trimmed.includes('@')) message = 'Missing @ symbol';
                    else if(trimmed.split('@').length > 2) message = 'Multiple @ symbols';
                    else if(trimmed.startsWith('@')) message = 'Missing local part';
                    else if(trimmed.endsWith('@')) message = 'Missing domain';
                    else if(!trimmed.split('@')[1].includes('.')) message = 'Invalid domain format';
                    else message = 'Invalid email format';
                }
                
                return { value: trimmed, valid, message };
            });
        }''',
        'seo_content': '''
                    <h2>About Email Validator</h2>
                    <p>Our Email Validator is a powerful, free tool that helps you verify email addresses instantly. With over 45,000 monthly searches, it's trusted by developers, marketers, and businesses worldwide to ensure email accuracy and validity.</p>
                    
                    <h3>How It Works</h3>
                    <p>The validator uses advanced regex patterns to check email syntax according to RFC 5322 standards. It verifies the format, checks for common errors, and provides detailed feedback on why an email might be invalid. All validation happens in your browser - no data is sent to any server.</p>
                    
                    <h3>Key Features</h3>
                    <ul>
                        <li><strong>Instant Validation:</strong> Get results in milliseconds</li>
                        <li><strong>Batch Processing:</strong> Validate multiple emails at once</li>
                        <li><strong>Detailed Feedback:</strong> Know exactly why an email is invalid</li>
                        <li><strong>100% Client-Side:</strong> Your data never leaves your browser</li>
                        <li><strong>RFC 5322 Compliant:</strong> Follows official email standards</li>
                        <li><strong>Mobile-Friendly:</strong> Works perfectly on all devices</li>
                    </ul>

                    <h3>Common Email Validation Checks</h3>
                    <p><strong>Format Validation:</strong> Ensures the email follows the standard format (local@domain.tld)</p>
                    <p><strong>Syntax Checking:</strong> Verifies proper use of special characters and symbols</p>
                    <p><strong>Domain Validation:</strong> Checks if the domain part is properly formatted</p>
                    <p><strong>Length Limits:</strong> Ensures email doesn't exceed maximum allowed length</p>

                    <h3>Use Cases</h3>
                    <p><strong>Form Validation:</strong> Validate user input before form submission</p>
                    <p><strong>Email List Cleaning:</strong> Remove invalid emails from your mailing lists</p>
                    <p><strong>Data Quality:</strong> Ensure email data quality in your databases</p>
                    <p><strong>Development:</strong> Test email validation logic in your applications</p>''',
        'faq_content': '''
                    <div class="faq-item">
                        <h3>Is this email validator really free?</h3>
                        <p>Yes! Our email validator is 100% free with no hidden costs or limitations. Validate as many emails as you need.</p>
                    </div>
                    <div class="faq-item">
                        <h3>Does this check if the email actually exists?</h3>
                        <p>No, this tool validates email format and syntax only. It doesn't verify if the email address actually exists or is active.</p>
                    </div>
                    <div class="faq-item">
                        <h3>Is my data safe?</h3>
                        <p>Absolutely! All validation happens in your browser. Your email addresses never leave your device or get sent to any server.</p>
                    </div>
                    <div class="faq-item">
                        <h3>Can I validate multiple emails at once?</h3>
                        <p>Yes! Enter one email per line to validate multiple email addresses in a single batch.</p>
                    </div>'''
    },
    {
        'name': 'Phone Number Validator',
        'slug': 'phone-validator',
        'searches': '30000',
        'description': 'Free phone number validator. Validate phone numbers from any country. Check format and validity. International phone validation.',
        'keywords': 'phone validator, validate phone number, phone number validation, international phone',
        'input_label': 'Enter Phone Number(s)',
        'placeholder': '+1-555-123-4567\n(555) 123-4567\n555-123-4567',
        'input_type': 'phone number(s)',
        'validation_script': '''
        function validateInput(input) {
            const phones = input.split('\\n').filter(p => p.trim());
            
            return phones.map(phone => {
                const trimmed = phone.trim();
                const cleaned = trimmed.replace(/[^0-9+]/g, '');
                
                let valid = false;
                let message = '';
                
                if(cleaned.length >= 10 && cleaned.length <= 15) {
                    valid = true;
                    const hasCountryCode = cleaned.startsWith('+');
                    message = `Valid phone format. ${hasCountryCode ? 'International' : 'Domestic'} number. Digits: ${cleaned.length}`;
                } else if(cleaned.length < 10) {
                    message = 'Too short. Phone numbers need at least 10 digits';
                } else {
                    message = 'Too long. Phone numbers should not exceed 15 digits';
                }
                
                return { value: trimmed, valid, message };
            });
        }''',
        'seo_content': '''
                    <h2>About Phone Number Validator</h2>
                    <p>Our Phone Number Validator helps you verify phone numbers from any country. With support for international formats and 30,000+ monthly searches, it's the go-to tool for validating phone numbers quickly and accurately.</p>
                    
                    <h3>Supported Formats</h3>
                    <ul>
                        <li>International: +1-555-123-4567</li>
                        <li>US Format: (555) 123-4567</li>
                        <li>Simple: 555-123-4567</li>
                        <li>Dots: 555.123.4567</li>
                        <li>Spaces: 555 123 4567</li>
                    </ul>

                    <h3>Validation Rules</h3>
                    <p>Phone numbers must be between 10-15 digits. Country codes (starting with +) are optional but recommended for international numbers.</p>''',
        'faq_content': '''
                    <div class="faq-item">
                        <h3>What phone formats are supported?</h3>
                        <p>We support all common phone number formats including international (+country code), US format with parentheses, and simple dash-separated formats.</p>
                    </div>
                    <div class="faq-item">
                        <h3>Can this validate international numbers?</h3>
                        <p>Yes! Our validator works with phone numbers from any country. Use the international format with + and country code for best results.</p>
                    </div>'''
    },
    {
        'name': 'URL Validator',
        'slug': 'url-validator',
        'searches': '25000',
        'description': 'Free URL validator. Validate URLs and web addresses. Check URL format and syntax. Support for HTTP, HTTPS, and more.',
        'keywords': 'url validator, validate url, check url, url verification',
        'input_label': 'Enter URL(s)',
        'placeholder': 'https://www.example.com\nhttp://subdomain.example.org/path\nftp://files.example.com',
        'input_type': 'URL(s)',
        'validation_script': '''
        function validateInput(input) {
            const urls = input.split('\\n').filter(u => u.trim());
            
            return urls.map(url => {
                const trimmed = url.trim();
                
                try {
                    const urlObj = new URL(trimmed);
                    const protocol = urlObj.protocol.replace(':', '');
                    const domain = urlObj.hostname;
                    
                    return {
                        value: trimmed,
                        valid: true,
                        message: `Valid URL. Protocol: ${protocol}, Domain: ${domain}`
                    };
                } catch(e) {
                    let message = 'Invalid URL format';
                    if(!trimmed.includes('://')) message = 'Missing protocol (http:// or https://)';
                    else if(!trimmed.includes('.')) message = 'Invalid domain';
                    
                    return { value: trimmed, valid: false, message };
                }
            });
        }''',
        'seo_content': '''
                    <h2>About URL Validator</h2>
                    <p>Validate URLs instantly with our free URL validator. Check if web addresses are properly formatted and follow URL standards. Perfect for developers, SEO professionals, and anyone working with web links.</p>
                    
                    <h3>Supported Protocols</h3>
                    <ul>
                        <li>HTTP and HTTPS</li>
                        <li>FTP and FTPS</li>
                        <li>File protocol</li>
                        <li>Custom protocols</li>
                    </ul>''',
        'faq_content': '''
                    <div class="faq-item">
                        <h3>What makes a URL valid?</h3>
                        <p>A valid URL must have a protocol (like http://), a domain name, and proper syntax. Optional components include paths, query parameters, and fragments.</p>
                    </div>'''
    },
    {
        'name': 'Credit Card Validator',
        'slug': 'credit-card-validator',
        'searches': '35000',
        'description': 'Free credit card validator. Validate credit card numbers using Luhn algorithm. Check Visa, Mastercard, Amex, and more.',
        'keywords': 'credit card validator, validate credit card, luhn algorithm, card validation',
        'input_label': 'Enter Credit Card Number(s)',
        'placeholder': '4532015112830366\n5425233430109903\n378282246310005',
        'input_type': 'credit card number(s)',
        'validation_script': '''
        function validateInput(input) {
            const cards = input.split('\\n').filter(c => c.trim());
            
            function luhnCheck(num) {
                let sum = 0;
                let isEven = false;
                for(let i = num.length - 1; i >= 0; i--) {
                    let digit = parseInt(num[i]);
                    if(isEven) {
                        digit *= 2;
                        if(digit > 9) digit -= 9;
                    }
                    sum += digit;
                    isEven = !isEven;
                }
                return sum % 10 === 0;
            }
            
            function getCardType(num) {
                if(/^4/.test(num)) return 'Visa';
                if(/^5[1-5]/.test(num)) return 'Mastercard';
                if(/^3[47]/.test(num)) return 'American Express';
                if(/^6(?:011|5)/.test(num)) return 'Discover';
                return 'Unknown';
            }
            
            return cards.map(card => {
                const cleaned = card.trim().replace(/[^0-9]/g, '');
                
                if(cleaned.length < 13 || cleaned.length > 19) {
                    return {
                        value: card.trim(),
                        valid: false,
                        message: 'Invalid length. Card numbers are 13-19 digits'
                    };
                }
                
                const valid = luhnCheck(cleaned);
                const type = getCardType(cleaned);
                
                return {
                    value: card.trim(),
                    valid,
                    message: valid ? `Valid ${type} card (Luhn check passed)` : 'Failed Luhn algorithm check'
                };
            });
        }''',
        'seo_content': '''
                    <h2>About Credit Card Validator</h2>
                    <p>Validate credit card numbers using the industry-standard Luhn algorithm. Our validator checks Visa, Mastercard, American Express, Discover, and other major card types. With 35,000+ monthly searches, it's trusted for testing and development.</p>
                    
                    <h3>Luhn Algorithm</h3>
                    <p>The Luhn algorithm (also known as modulus 10) is a checksum formula used to validate credit card numbers. It detects simple errors in card number entry.</p>
                    
                    <h3>Supported Card Types</h3>
                    <ul>
                        <li>Visa (starts with 4)</li>
                        <li>Mastercard (starts with 51-55)</li>
                        <li>American Express (starts with 34 or 37)</li>
                        <li>Discover (starts with 6011 or 65)</li>
                    </ul>

                    <h3>Important Note</h3>
                    <p><strong>For Testing Only:</strong> This tool validates card number format only. It does NOT verify if a card is active, has funds, or belongs to a real account. Never use real card numbers for testing.</p>''',
        'faq_content': '''
                    <div class="faq-item">
                        <h3>Is this safe to use with real card numbers?</h3>
                        <p>While all validation happens locally in your browser, we recommend using test card numbers only. Never share real credit card information online.</p>
                    </div>
                    <div class="faq-item">
                        <h3>What is the Luhn algorithm?</h3>
                        <p>The Luhn algorithm is a checksum formula used to validate credit card numbers. It helps detect accidental errors in card number entry.</p>
                    </div>
                    <div class="faq-item">
                        <h3>Can I use this for payment processing?</h3>
                        <p>No. This tool only validates card number format. For actual payment processing, use certified payment gateways like Stripe or PayPal.</p>
                    </div>'''
    },
    {
        'name': 'IP Address Validator',
        'slug': 'ip-validator',
        'searches': '20000',
        'description': 'Free IP address validator. Validate IPv4 and IPv6 addresses. Check IP format and validity. Network administration tool.',
        'keywords': 'ip validator, validate ip address, ipv4 validator, ipv6 validator',
        'input_label': 'Enter IP Address(es)',
        'placeholder': '192.168.1.1\n2001:0db8:85a3:0000:0000:8a2e:0370:7334\n10.0.0.1',
        'input_type': 'IP address(es)',
        'validation_script': '''
        function validateInput(input) {
            const ips = input.split('\\n').filter(ip => ip.trim());
            
            function isValidIPv4(ip) {
                const parts = ip.split('.');
                if(parts.length !== 4) return false;
                return parts.every(part => {
                    const num = parseInt(part);
                    return num >= 0 && num <= 255 && part === num.toString();
                });
            }
            
            function isValidIPv6(ip) {
                const parts = ip.split(':');
                if(parts.length < 3 || parts.length > 8) return false;
                return parts.every(part => /^[0-9a-fA-F]{0,4}$/.test(part));
            }
            
            return ips.map(ip => {
                const trimmed = ip.trim();
                
                if(isValidIPv4(trimmed)) {
                    const isPrivate = trimmed.startsWith('192.168.') || trimmed.startsWith('10.') || trimmed.startsWith('172.');
                    return {
                        value: trimmed,
                        valid: true,
                        message: `Valid IPv4 address. ${isPrivate ? 'Private' : 'Public'} IP`
                    };
                } else if(isValidIPv6(trimmed)) {
                    return {
                        value: trimmed,
                        valid: true,
                        message: 'Valid IPv6 address'
                    };
                } else {
                    return {
                        value: trimmed,
                        valid: false,
                        message: 'Invalid IP address format (not IPv4 or IPv6)'
                    };
                }
            });
        }''',
        'seo_content': '''
                    <h2>About IP Address Validator</h2>
                    <p>Validate both IPv4 and IPv6 addresses with our free IP validator. Essential for network administrators, developers, and IT professionals. Supports all IP address formats and provides detailed validation feedback.</p>
                    
                    <h3>IPv4 vs IPv6</h3>
                    <p><strong>IPv4:</strong> Traditional format with four octets (e.g., 192.168.1.1)</p>
                    <p><strong>IPv6:</strong> Modern format with eight groups of hexadecimal digits (e.g., 2001:0db8:85a3::8a2e:0370:7334)</p>''',
        'faq_content': '''
                    <div class="faq-item">
                        <h3>What's the difference between IPv4 and IPv6?</h3>
                        <p>IPv4 uses 32-bit addresses (4 octets), while IPv6 uses 128-bit addresses (8 groups). IPv6 was created to address IPv4 address exhaustion.</p>
                    </div>'''
    },
    {
        'name': 'JSON Validator',
        'slug': 'json-validator-advanced',
        'searches': '40000',
        'description': 'Free JSON validator. Validate JSON syntax and structure. Find errors in JSON data. Format and beautify JSON.',
        'keywords': 'json validator, validate json, json syntax checker, json formatter',
        'input_label': 'Enter JSON Data',
        'placeholder': '{\n  "name": "John",\n  "age": 30,\n  "city": "New York"\n}',
        'input_type': 'JSON data',
        'validation_script': '''
        function validateInput(input) {
            try {
                const parsed = JSON.parse(input);
                const formatted = JSON.stringify(parsed, null, 2);
                const size = new Blob([input]).size;
                const keys = Object.keys(parsed).length;
                
                return [{
                    value: 'JSON Data',
                    valid: true,
                    message: `Valid JSON! Size: ${size} bytes, Keys: ${keys}`
                }];
            } catch(e) {
                return [{
                    value: 'JSON Data',
                    valid: false,
                    message: `Invalid JSON: ${e.message}`
                }];
            }
        }''',
        'seo_content': '''
                    <h2>About JSON Validator</h2>
                    <p>Validate JSON data instantly with our advanced JSON validator. Check syntax, find errors, and ensure your JSON is properly formatted. With 40,000+ monthly searches, it's the preferred tool for developers working with JSON.</p>''',
        'faq_content': '''
                    <div class="faq-item">
                        <h3>What is JSON?</h3>
                        <p>JSON (JavaScript Object Notation) is a lightweight data interchange format that's easy for humans to read and write, and easy for machines to parse and generate.</p>
                    </div>'''
    },
    {
        'name': 'Password Strength Validator',
        'slug': 'password-strength-validator',
        'searches': '28000',
        'description': 'Free password strength validator. Check password security and strength. Get suggestions to improve password safety.',
        'keywords': 'password validator, password strength, check password, password security',
        'input_label': 'Enter Password',
        'placeholder': 'Enter your password to check its strength',
        'input_type': 'password',
        'validation_script': '''
        function validateInput(input) {
            const password = input.trim();
            let score = 0;
            let feedback = [];
            
            if(password.length >= 8) score += 20; else feedback.push('Use at least 8 characters');
            if(password.length >= 12) score += 10;
            if(/[a-z]/.test(password)) score += 15; else feedback.push('Add lowercase letters');
            if(/[A-Z]/.test(password)) score += 15; else feedback.push('Add uppercase letters');
            if(/[0-9]/.test(password)) score += 15; else feedback.push('Add numbers');
            if(/[^a-zA-Z0-9]/.test(password)) score += 25; else feedback.push('Add special characters');
            
            let strength = 'Very Weak';
            if(score >= 80) strength = 'Very Strong';
            else if(score >= 60) strength = 'Strong';
            else if(score >= 40) strength = 'Medium';
            else if(score >= 20) strength = 'Weak';
            
            const message = `Strength: ${strength} (${score}/100). ${feedback.length ? 'Suggestions: ' + feedback.join(', ') : 'Excellent password!'}`;
            
            return [{
                value: '•'.repeat(password.length),
                valid: score >= 60,
                message
            }];
        }''',
        'seo_content': '''
                    <h2>About Password Strength Validator</h2>
                    <p>Check your password strength and get instant feedback on how to improve it. Our validator analyzes length, complexity, and character variety to give you a comprehensive security score.</p>''',
        'faq_content': '''
                    <div class="faq-item">
                        <h3>What makes a strong password?</h3>
                        <p>A strong password should be at least 12 characters long and include a mix of uppercase, lowercase, numbers, and special characters.</p>
                    </div>'''
    },
    {
        'name': 'IBAN Validator',
        'slug': 'iban-validator',
        'searches': '15000',
        'description': 'Free IBAN validator. Validate International Bank Account Numbers. Check IBAN format and country codes.',
        'keywords': 'iban validator, validate iban, bank account validator, international banking',
        'input_label': 'Enter IBAN',
        'placeholder': 'GB82 WEST 1234 5698 7654 32\nDE89 3704 0044 0532 0130 00',
        'input_type': 'IBAN',
        'validation_script': '''
        function validateInput(input) {
            const ibans = input.split('\\n').filter(i => i.trim());
            
            function validateIBAN(iban) {
                const cleaned = iban.replace(/\\s/g, '').toUpperCase();
                if(cleaned.length < 15 || cleaned.length > 34) return false;
                
                const rearranged = cleaned.slice(4) + cleaned.slice(0, 4);
                const numeric = rearranged.split('').map(c => {
                    const code = c.charCodeAt(0);
                    return code >= 65 && code <= 90 ? code - 55 : c;
                }).join('');
                
                let remainder = numeric;
                while(remainder.length > 2) {
                    const block = remainder.slice(0, 9);
                    remainder = (parseInt(block) % 97) + remainder.slice(block.length);
                }
                
                return parseInt(remainder) % 97 === 1;
            }
            
            return ibans.map(iban => {
                const trimmed = iban.trim();
                const country = trimmed.slice(0, 2).toUpperCase();
                const valid = validateIBAN(trimmed);
                
                return {
                    value: trimmed,
                    valid,
                    message: valid ? `Valid IBAN for ${country}` : 'Invalid IBAN format or checksum'
                };
            });
        }''',
        'seo_content': '''
                    <h2>About IBAN Validator</h2>
                    <p>Validate International Bank Account Numbers (IBAN) from any country. Our validator checks format, country codes, and uses the mod-97 algorithm to verify checksums.</p>''',
        'faq_content': '''
                    <div class="faq-item">
                        <h3>What is an IBAN?</h3>
                        <p>IBAN (International Bank Account Number) is an internationally agreed system of identifying bank accounts across national borders. It's used in Europe and many other countries.</p>
                    </div>'''
    }
]

def generate_validator(validator):
    """Generate a validator tool file"""
    file_path = Path(f"./tools/validator/{validator['slug']}.html")
    file_path.parent.mkdir(parents=True, exist_ok=True)
    
    # Prepare all template variables
    template_vars = {
        'title': validator['name'],
        'description': validator['description'],
        'keywords': validator['keywords'],
        'slug': validator['slug'],
        'h1_title': validator['name'],
        'tool_description': validator['description'],
        'input_label': validator['input_label'],
        'placeholder': validator['placeholder'],
        'input_type': validator['input_type'],
        'validation_script': validator['validation_script'],
        'seo_content': validator['seo_content'],
        'faq_content': validator['faq_content']
    }
    
    html = VALIDATOR_TEMPLATE.format(**template_vars)
    
    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(html)
    
    print(f"Generated: {validator['name']} ({validator['searches']}/month)")

def main():
    print("=" * 70)
    print("GENERATING VALIDATOR TOOLS - 100% CLIENT-SIDE")
    print("=" * 70)
    
    total_searches = sum([int(v['searches']) for v in VALIDATORS])
    print(f"Total Monthly Searches: {total_searches:,}")
    print("=" * 70)
    
    for validator in VALIDATORS:
        generate_validator(validator)
    
    print("=" * 70)
    print(f"SUCCESS! Generated {len(VALIDATORS)} validator tools!")
    print(f"Total Monthly Searches: {total_searches:,}")
    print("=" * 70)

if __name__ == '__main__': main()
