#!/usr/bin/env python3
"""
Final cleanup - Remove all remaining Tailwind classes and fix tool-panel
"""

import os
import re
from pathlib import Path

class Colors:
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    RESET = '\033[0m'

def print_colored(text, color):
    try:
        print(f"{color}{text}{Colors.RESET}")
    except UnicodeEncodeError:
        print(text.encode('ascii', 'replace').decode('ascii'))

def final_cleanup(file_path):
    """Final cleanup of remaining issues"""
    
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    original_content = content
    
    # Fix: Replace ALL instances of tool-panel with tool-section
    content = re.sub(r'class="tool-panel([^"]*)"', r'class="tool-section\1"', content)
    
    # Fix: Remove Tailwind utility classes from various elements
    tailwind_patterns = [
        (r'class="([^"]*)\s*hidden([^"]*)"', r'class="\1\2" style="display: none;"'),
        (r'class="([^"]*)\s*relative([^"]*)"', r'class="\1\2" style="position: relative;"'),
        (r'class="([^"]*)\s*absolute([^"]*)"', r'class="\1\2" style="position: absolute;"'),
        (r'class="([^"]*)\s*inline-block([^"]*)"', r'class="\1\2" style="display: inline-block;"'),
        (r'class="([^"]*)\s*overflow-hidden([^"]*)"', r'class="\1\2" style="overflow: hidden;"'),
        (r'class="([^"]*)\s*rounded([^"]*)"', r'class="\1\2" style="border-radius: var(--radius-lg);"'),
        (r'class="([^"]*)\s*flex([^"]*)"', r'class="\1\2" style="display: flex;"'),
        (r'class="([^"]*)\s*justify-center([^"]*)"', r'class="\1\2" style="justify-content: center;"'),
        (r'class="([^"]*)\s*text-center([^"]*)"', r'class="\1\2" style="text-align: center;"'),
        (r'class="([^"]*)\s*font-bold([^"]*)"', r'class="\1\2" style="font-weight: var(--font-semibold);"'),
        (r'class="([^"]*)\s*text-sm([^"]*)"', r'class="\1\2" style="font-size: var(--text-sm);"'),
        (r'class="([^"]*)\s*text-secondary([^"]*)"', r'class="\1\2" style="color: var(--text-secondary);"'),
        (r'class="([^"]*)\s*list-disc([^"]*)"', r'class="\1\2" style="list-style-type: disc;"'),
        (r'class="([^"]*)\s*pl-5([^"]*)"', r'class="\1\2" style="padding-left: var(--space-5);"'),
        (r'class="([^"]*)\s*mb-2([^"]*)"', r'class="\1\2" style="margin-bottom: var(--space-2);"'),
        (r'class="([^"]*)\s*mt-4([^"]*)"', r'class="\1\2" style="margin-top: var(--space-4);"'),
        (r'class="([^"]*)\s*w-full([^"]*)"', r'class="\1\2" style="width: 100%;"'),
        (r'class="([^"]*)\s*h-full([^"]*)"', r'class="\1\2" style="height: 100%;"'),
        (r'class="([^"]*)\s*top-0([^"]*)"', r'class="\1\2" style="top: 0;"'),
        (r'class="([^"]*)\s*left-0([^"]*)"', r'class="\1\2" style="left: 0;"'),
        (r'class="([^"]*)\s*pointer-events-none([^"]*)"', r'class="\1\2" style="pointer-events: none;"'),
        (r'class="([^"]*)\s*bg-gray-100([^"]*)"', r'class="\1\2" style="background: var(--bg-tertiary);"'),
    ]
    
    for pattern, replacement in tailwind_patterns:
        content = re.sub(pattern, replacement, content)
    
    # Clean up empty class attributes
    content = re.sub(r'class="\s*"\s*', '', content)
    content = re.sub(r"class='\s*'\s*", '', content)
    
    # Clean up multiple spaces in style attributes
    content = re.sub(r'style="([^"]*)\s{2,}([^"]*)"', r'style="\1 \2"', content)
    
    # Only write if content changed
    if content != original_content:
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(content)
        return True
    return False

def main():
    print_colored("="*60, Colors.CYAN)
    print_colored("Final Cleanup - Removing Tailwind Classes", Colors.CYAN)
    print_colored("="*60, Colors.CYAN)
    print()
    
    tools_dir = Path('./tools')
    
    if not tools_dir.exists():
        print_colored("Error: ./tools directory not found!", Colors.RED)
        return
    
    # Find all HTML files
    html_files = list(tools_dir.rglob('*.html'))
    
    print_colored(f"Scanning {len(html_files)} HTML files...\n", Colors.YELLOW)
    
    fixed_count = 0
    
    for file_path in html_files:
        try:
            if final_cleanup(file_path):
                relative_path = file_path.relative_to(Path('.'))
                print_colored(f"[+] Cleaned: {relative_path}", Colors.GREEN)
                fixed_count += 1
        except Exception as e:
            relative_path = file_path.relative_to(Path('.'))
            print_colored(f"[X] Error in {relative_path}: {str(e)}", Colors.RED)
    
    print()
    print_colored("="*60, Colors.CYAN)
    print_colored("Cleanup Complete!", Colors.CYAN)
    print_colored("="*60, Colors.CYAN)
    print_colored(f"[+] Cleaned: {fixed_count} files", Colors.GREEN)
    print_colored(f"[-] Unchanged: {len(html_files) - fixed_count} files", Colors.YELLOW)

if __name__ == '__main__':
    main()
