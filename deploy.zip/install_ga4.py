import os
import re

ROOT_DIR = r"c:\Users\LENOVO\.gemini\antigravity\scratch\online-tools-suite"
GA4_ID = "G-EX25SFMRXZ"

GA4_CODE = """<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-EX25SFMRXZ"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-EX25SFMRXZ');
</script>"""

def install_ga4():
    count = 0
    skipped = 0
    
    print(f"Scanning {ROOT_DIR}...")
    
    for root, dirs, files in os.walk(ROOT_DIR):
        for file in files:
            if file.lower().endswith(".html"):
                path = os.path.join(root, file)
                
                try:
                    with open(path, "r", encoding="utf-8") as f:
                        content = f.read()
                    
                    # Check if already installed
                    if "G-EX25SFMRXZ" in content:
                        print(f"Skipping (already present): {file}")
                        skipped += 1
                        continue
                    
                    # Inject HEAD
                    # We look for <head> and insert AFTER it.
                    # This RegEx finds <head... > and replaces it with <head... > \n CODE
                    new_content = re.sub(
                        r'(<head[^>]*>)', 
                        r'\1\n' + GA4_CODE, 
                        content, 
                        count=1, 
                        flags=re.IGNORECASE
                    )
                    
                    if new_content != content:
                        with open(path, "w", encoding="utf-8") as f:
                            f.write(new_content)
                        print(f"Updated: {file}")
                        count += 1
                    else:
                        print(f"Skipping (head tag not found): {file}")
                        
                except Exception as e:
                    print(f"Error processing {path}: {e}")

    print(f"\nSummary: Updated {count} files. Skipped {skipped} files.")

if __name__ == "__main__":
    install_ga4()
