#!/usr/bin/env python3
from pathlib import Path

def get_header(title, description, slug, category_path):
    return f'''<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title} | OnlineToolFree</title>
    <meta name="description" content="{description}">
    <link rel="canonical" href="https://onlinetoolfree.com/tools/{category_path}/{slug}.html">
    <link rel="stylesheet" href="../../css/design-system.css">
    <script src="../../js/tools.js"></script>
    <script src="../../js/ui.js"></script>
    <script src="../../js/app.js"></script>
</head>
<body>
    <header class="header"></header>
    <div class="tool-layout">
        <aside class="tool-sidebar" id="tool-sidebar"></aside>
        <main class="tool-main">
            <div class="tool-page" style="max-width: 1000px; margin: 0; padding: 0;">
'''

def get_footer(schema_json):
    return f'''
            </div>
        </main>
    </div>
    <button class="sidebar-toggle" id="sidebar-toggle">
        <svg class="icon" viewBox="0 0 24 24"><line x1="4" y1="12" x2="20" y2="12"/><line x1="4" y1="6" x2="20" y2="6"/><line x1="4" y1="18" x2="20" y2="18"/></svg>
    </button>
    <footer class="footer"></footer>
    <script type="application/ld+json">{schema_json}</script>
    <script>
        document.addEventListener('DOMContentLoaded', () => {{
            Components.renderHeader();
            Components.renderSidebar('tool-sidebar');
            Components.renderFooter();
            if (window.ThemeManager) ThemeManager.init();
        }});
    </script>
</body>
</html>'''

TOOLS = {
    'finance/loan-calculator.html': {
        'title': 'Loan Calculator - Monthly Payment & Amortization',
        'desc': 'Calculate monthly loan payments, total interest, and see a full amortization schedule. Free calculator for mortgages, car loans, and personal loans.',
        'content': '''
                <h1 class="tool-title">Loan Calculator</h1>
                <p class="tool-description">Calculate monthly payments and total interest for any loan.</p>
                <div class="tool-interface">
                    <div class="tool-section">
                        <div class="grid" style="grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: var(--space-4);">
                            <div><label class="form-label">Loan Amount ($)</label><input type="number" id="amount" class="form-input" value="10000"></div>
                            <div><label class="form-label">Interest Rate (%)</label><input type="number" id="rate" class="form-input" value="5" step="0.1"></div>
                            <div><label class="form-label">Term (Years)</label><input type="number" id="term" class="form-input" value="5"></div>
                        </div>
                    </div>
                    <div class="tool-actions"><button id="calc-btn" class="btn btn-primary">Calculate EMI</button></div>
                    <div id="loan-results" class="tool-section output-section" style="display:none;">
                        <div class="grid" style="grid-template-columns: 1fr 1fr; gap: var(--space-4); margin-bottom: var(--space-6);">
                            <div style="padding: var(--space-4); background: var(--bg-tertiary); border-radius: var(--radius-lg);">
                                <div style="font-size: var(--text-sm); color: var(--text-secondary);">Monthly Payment</div>
                                <div style="font-size: var(--text-2xl); font-weight: bold; color: var(--primary-600);">$<span id="monthly-pay">0</span></div>
                            </div>
                            <div style="padding: var(--space-4); background: var(--bg-tertiary); border-radius: var(--radius-lg);">
                                <div style="font-size: var(--text-sm); color: var(--text-secondary);">Total Interest</div>
                                <div style="font-size: var(--text-2xl); font-weight: bold; color: var(--success-600);">$<span id="total-int">0</span></div>
                            </div>
                        </div>
                    </div>
                </div>
                <script>
                    document.getElementById('calc-btn').addEventListener('click', () => {
                        const p = parseFloat(document.getElementById('amount').value);
                        const r = parseFloat(document.getElementById('rate').value) / 100 / 12;
                        const n = parseFloat(document.getElementById('term').value) * 12;
                        const emi = (p * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
                        document.getElementById('monthly-pay').textContent = emi.toFixed(2);
                        document.getElementById('total-int').textContent = ((emi * n) - p).toFixed(2);
                        document.getElementById('loan-results').style.display = 'block';
                    });
                </script>
        '''
    },
    'finance/budget-planner.html': {
        'title': '50/30/20 Budget Planner - Interactive Calculator',
        'desc': 'Plan your monthly budget using the 50/30/20 rule. Allocate your income to needs, wants, and savings automatically with our free budget tool.',
        'content': '''
                <h1 class="tool-title">50/30/20 Budget Planner</h1>
                <p class="tool-description">Divide your income into Needs (50%), Wants (30%), and Savings (20%).</p>
                <div class="tool-interface">
                    <div class="tool-section">
                        <label class="form-label">Monthly Take-Home Income ($)</label>
                        <input type="number" id="income" class="form-input" placeholder="e.g. 4000" style="max-width:300px;">
                    </div>
                    <div class="tool-section output-section">
                        <div style="display: grid; gap: var(--space-4);">
                            <div id="needs-box" style="padding: var(--space-4); background: #e0f2fe; border-radius: var(--radius-lg); border-left: 6px solid #0ea5e9;">
                                <strong>Needs (50%): $<span id="needs-val">0</span></strong>
                                <p style="font-size: var(--text-xs); margin-top: 5px;">Rent, Utilities, Insurance, Food, Transport.</p>
                            </div>
                            <div id="wants-box" style="padding: var(--space-4); background: #fdf2f8; border-radius: var(--radius-lg); border-left: 6px solid #ec4899;">
                                <strong>Wants (30%): $<span id="wants-val">0</span></strong>
                                <p style="font-size: var(--text-xs); margin-top: 5px;">Dining out, Hobbies, Subscriptions, Travel.</p>
                            </div>
                            <div id="savings-box" style="padding: var(--space-4); background: #f0fdf4; border-radius: var(--radius-lg); border-left: 6px solid #22c55e;">
                                <strong>Savings & Debt (20%): $<span id="savings-val">0</span></strong>
                                <p style="font-size: var(--text-xs); margin-top: 5px;">Emergency fund, Investments, Debt repayment.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <script>
                    document.getElementById('income').addEventListener('input', (e) => {
                        const val = parseFloat(e.target.value) || 0;
                        document.getElementById('needs-val').textContent = (val * 0.5).toFixed(2);
                        document.getElementById('wants-val').textContent = (val * 0.3).toFixed(2);
                        document.getElementById('savings-val').textContent = (val * 0.2).toFixed(2);
                    });
                </script>
        '''
    },
    'image/transparent-maker.html': {
        'title': 'Transparent PNG Maker - Remove White Background',
        'desc': 'Make your PNG background transparent online. Remove solid white or colored backgrounds from logos and icons instantly and for free.',
        'content': '''
                <h1 class="tool-title">Transparent PNG Maker</h1>
                <p class="tool-description">Easily remove solid backgrounds from your images.</p>
                <div class="tool-interface">
                    <div class="tool-section">
                         <div class="file-drop-area" id="drop-area">
                            <input type="file" id="file-input" accept="image/*" hidden>
                            <p>Drag & drop image or <span>browse</span></p>
                        </div>
                    </div>
                    <div class="tool-section output-section" style="text-align:center;">
                        <canvas id="canvas" style="max-width: 100%; height: auto; display:none; background: repeating-conic-gradient(#eee 0% 25%, #fff 0% 50%) 50% / 20px 20px; border-radius: var(--radius-lg);"></canvas>
                        <div id="preview-actions" style="display:none; margin-top: 20px;">
                            <button id="download-btn" class="btn btn-primary">Download as Transparent PNG</button>
                        </div>
                    </div>
                </div>
                <script>
                    const dropArea = document.getElementById('drop-area');
                    const fileInput = document.getElementById('file-input');
                    const canvas = document.getElementById('canvas');
                    const ctx = canvas.getContext('2d');
                    dropArea.addEventListener('click', () => fileInput.click());
                    fileInput.addEventListener('change', (e) => handleFile(e.target.files[0]));
                    function handleFile(file) {
                        if(!file) return;
                        const reader = new FileReader();
                        reader.onload = (e) => {
                            const img = new Image();
                            img.onload = () => {
                                canvas.width = img.width;
                                canvas.height = img.height;
                                ctx.drawImage(img, 0, 0);
                                const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
                                const data = imageData.data;
                                // Basic white background removal
                                for (let i = 0; i < data.length; i += 4) {
                                    if (data[i] > 240 && data[i+1] > 240 && data[i+2] > 240) {
                                        data[i+3] = 0;
                                    }
                                }
                                ctx.putImageData(imageData, 0, 0);
                                canvas.style.display = 'block';
                                document.getElementById('preview-actions').style.display = 'block';
                            };
                            img.src = e.target.result;
                        };
                        reader.readAsDataURL(file);
                    }
                    document.getElementById('download-btn').addEventListener('click', () => {
                        const link = document.createElement('a');
                        link.download = 'transparent.png';
                        link.href = canvas.toDataURL();
                        link.click();
                    });
                </script>
        '''
    }
}

def main():
    for path, data in TOOLS.items():
        file_path = Path(f'./tools/{path}')
        file_path.parent.mkdir(parents=True, exist_ok=True)
        slug = path.split('/')[-1].replace('.html', '')
        cat = path.split('/')[0]
        schema = {"@context": "https://schema.org","@type": "SoftwareApplication","name": data['title'],"description": data['desc']}
        html = get_header(data['title'], data['desc'], slug, cat) + data['content'] + get_footer(__import__('json').dumps(schema))
        with open(file_path, 'w', encoding='utf-8') as f: f.write(html)
        print(f"Generated: {path}")

if __name__ == '__main__': main()
