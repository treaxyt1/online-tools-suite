#!/usr/bin/env python3
from pathlib import Path
import json

def get_header(title, description, slug, category_path):
    return f'''<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title} | OnlineToolFree</title>
    <meta name="description" content="{description}">
    <link rel="canonical" href="https://onlinetoolfree.com/tools/{category_path}/{slug}.html">
    <link rel="stylesheet" href="../../css/design-system.css">
    <script src="../../js/tools.js"></script>
    <script src="../../js/ui.js"></script>
    <script src="../../js/app.js"></script>
</head>
<body>
    <header class="header"></header>
    <div class="tool-layout">
        <aside class="tool-sidebar" id="tool-sidebar"></aside>
        <main class="tool-main">
            <div class="tool-page" style="max-width: 1000px; margin: 0; padding: 0;">
'''

def get_footer(schema_json):
    return f'''
            </div>
        </main>
    </div>
    <button class="sidebar-toggle" id="sidebar-toggle">
        <svg class="icon" viewBox="0 0 24 24"><line x1="4" y1="12" x2="20" y2="12"/><line x1="4" y1="6" x2="20" y2="6"/><line x1="4" y1="18" x2="20" y2="18"/></svg>
    </button>
    <footer class="footer"></footer>
    <script type="application/ld+json">{schema_json}</script>
    <script>
        document.addEventListener('DOMContentLoaded', () => {{
            Components.renderHeader();
            Components.renderSidebar('tool-sidebar');
            Components.renderFooter();
            if (window.ThemeManager) ThemeManager.init();
        }});
    </script>
</body>
</html>'''

TOOLS = {
    'productivity/time-until.html': {
        'title': 'Time Until Calculator - Countdown Timer',
        'desc': 'Count down the days, hours, minutes, and seconds to any future event.',
        'content': '''
            <h1 class="tool-title">Time Until Calculator</h1>
            <div class="tool-interface">
                <div class="tool-section">
                    <label>Target Date & Time</label>
                    <input type="datetime-local" id="target" class="form-input">
                </div>
                <div class="tool-section output-section" style="text-align:center;">
                    <div id="countdown" style="font-size: 2rem; font-weight: bold;">0d 00h 00m 00s</div>
                </div>
            </div>
            <script>
                document.getElementById('target').addEventListener('change', function() {
                    const target = new Date(this.value).getTime();
                    if(isNaN(target)) return;
                    
                    if(window.timer) clearInterval(window.timer);
                    window.timer = setInterval(() => {
                        const now = new Date().getTime();
                        const dist = target - now;
                        
                        if (dist < 0) {
                            document.getElementById('countdown').textContent = "EXPIRED";
                            clearInterval(window.timer);
                            return;
                        }
                        
                        const d = Math.floor(dist / (1000 * 60 * 60 * 24));
                        const h = Math.floor((dist % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                        const m = Math.floor((dist % (1000 * 60 * 60)) / (1000 * 60));
                        const s = Math.floor((dist % (1000 * 60)) / 1000);
                        
                        document.getElementById('countdown').textContent = `${d}d ${h}h ${m}m ${s}s`;
                    }, 1000);
                });
            </script>
        '''
    },
    'writing/word-frequency.html': {
        'title': 'Word Frequency Counter',
        'desc': 'Count frequency of every word in your text.',
        'content': '''
            <h1 class="tool-title">Word Frequency Counter</h1>
            <div class="tool-interface">
                <textarea id="wf-input" class="form-input" rows="8" placeholder="Paste text..."></textarea>
                <div id="wf-res" class="tool-section output-section"></div>
            </div>
            <script>
                document.getElementById('wf-input').addEventListener('input', function() {
                    const text = this.value.toLowerCase().match(/\\b\\w+\\b/g) || [];
                    const freq = {};
                    text.forEach(w => freq[w] = (freq[w] || 0) + 1);
                    const sorted = Object.entries(freq).sort((a,b) => b[1] - a[1]).slice(0, 20);
                    document.getElementById('wf-res').innerHTML = sorted.map(([w,c]) => `
                        <div style="display:inline-block; margin:5px; padding:5px 10px; background:var(--bg-tertiary); border-radius:5px;">${w}: ${c}</div>
                    `).join('');
                });
            </script>
        '''
    },
    'finance/freelance-rate.html': {
        'title': 'Freelance Rate Calculator',
        'desc': 'Calculate your ideal hourly rate based on income goals.',
        'content': '''
            <h1 class="tool-title">Freelance Rate Calculator</h1>
            <div class="tool-interface">
                <div class="tool-section">
                    <label>Annual Income Goal ($)</label><input type="number" id="goal" class="form-input" value="60000">
                    <label>Billable Hours / Week</label><input type="number" id="hours" class="form-input" value="30">
                    <label>Vacation Weeks</label><input type="number" id="vacation" class="form-input" value="4">
                </div>
                <div class="tool-section output-section">
                    <h3>Minimum Hourly Rate: <span id="rate-res">$50.00</span></h3>
                </div>
            </div>
            <script>
                function calc() {
                    const g = parseFloat(document.getElementById('goal').value);
                    const h = parseFloat(document.getElementById('hours').value);
                    const v = parseFloat(document.getElementById('vacation').value);
                    const weeks = 52 - v;
                    const rate = g / (weeks * h);
                    document.getElementById('rate-res').textContent = '$' + rate.toFixed(2);
                }
                document.querySelectorAll('input').forEach(i => i.addEventListener('input', calc));
                calc();
            </script>
        '''
    },
    'seo/og-image-generator.html': {
        'title': 'Open Graph Image Generator',
        'desc': 'Create simple OG images for your blog posts.',
        'content': '''
            <h1 class="tool-title">OG Image Generator</h1>
            <div class="tool-interface">
                <div class="tool-section">
                    <label>Title</label><input type="text" id="og-title" class="form-input" value="My Awesome Post">
                    <label>BG Color</label><input type="color" id="og-color" class="form-input" value="#3b82f6">
                </div>
                <div class="tool-section output-section">
                    <canvas id="og-canvas" width="1200" height="630" style="width:100%; height:auto; border-radius:8px;"></canvas>
                    <button id="og-dl" class="btn btn-primary" style="margin-top:10px;">Download Image</button>
                </div>
            </div>
            <script>
                const c = document.getElementById('og-canvas');
                const ctx = c.getContext('2d');
                function draw() {
                    const title = document.getElementById('og-title').value;
                    const color = document.getElementById('og-color').value;
                    
                    ctx.fillStyle = color;
                    ctx.fillRect(0,0,1200,630);
                    ctx.fillStyle = 'white';
                    ctx.font = 'bold 80px Inter, sans-serif';
                    ctx.textAlign = 'center';
                    ctx.textBaseline = 'middle';
                    ctx.fillText(title, 600, 315);
                }
                document.querySelectorAll('input').forEach(i => i.addEventListener('input', draw));
                document.getElementById('og-dl').addEventListener('click', () => {
                    const a = document.createElement('a');
                    a.download = 'og-image.png';
                    a.href = c.toDataURL();
                    a.click();
                });
                // Load font first
                document.fonts.ready.then(draw);
            </script>
        '''
    },
    'image/image-compressor.html': {
        'title': 'Image Compressor - Reduce File Size',
        'desc': 'Compress JPG and PNG images right in your browser.',
        'content': '''
            <h1 class="tool-title">Image Compressor</h1>
            <div class="tool-interface">
                <input type="file" id="comp-file" accept="image/*" class="form-input">
                <div class="tool-section">
                    <label>Quality (0-1)</label>
                    <input type="range" id="quality" min="0.1" max="1" step="0.1" value="0.7">
                </div>
                <div class="tool-section output-section" style="display:none;" id="comp-res">
                    <img id="comp-img" style="max-width:100%">
                    <div>Original: <span id="orig-size"></span> | Compressed: <span id="new-size"></span></div>
                    <a id="comp-dl" class="btn btn-primary">Download</a>
                </div>
            </div>
            <script>
                document.getElementById('comp-file').addEventListener('change', function(e) {
                    const file = e.target.files[0];
                    if(!file) return;
                    document.getElementById('orig-size').textContent = (file.size/1024).toFixed(1) + ' KB';
                    
                    const reader = new FileReader();
                    reader.onload = (ev) => {
                        const img = new Image();
                        img.onload = () => {
                            const cvs = document.createElement('canvas');
                            cvs.width = img.width;
                            cvs.height = img.height;
                            const ctx = cvs.getContext('2d');
                            ctx.drawImage(img, 0, 0);
                            
                            const q = parseFloat(document.getElementById('quality').value);
                            cvs.toBlob((blob) => {
                                document.getElementById('new-size').textContent = (blob.size/1024).toFixed(1) + ' KB';
                                const url = URL.createObjectURL(blob);
                                document.getElementById('comp-img').src = url;
                                const dl = document.getElementById('comp-dl');
                                dl.href = url;
                                dl.download = 'compressed_' + file.name;
                                document.getElementById('comp-res').style.display = 'block';
                            }, file.type, q);
                        };
                        img.src = ev.target.result;
                    };
                    reader.readAsDataURL(file);
                });
            </script>
        '''
    },
    'image/photo-collage.html': {
        'title': 'Simple Photo Collage Maker',
        'desc': 'Combine 2 images side-by-side.',
        'content': '''
            <h1 class="tool-title">Photo Collage Maker</h1>
            <div class="tool-interface">
                <div class="grid" style="grid-template-columns: 1fr 1fr; gap: 10px;">
                    <input type="file" id="img1" accept="image/*">
                    <input type="file" id="img2" accept="image/*">
                </div>
                <button id="make-col" class="btn btn-primary" style="margin-top:10px;">Create Collage</button>
                <div class="tool-section output-section">
                    <canvas id="col-cvs" style="max-width:100%; display:none;"></canvas>
                </div>
            </div>
            <script>
                document.getElementById('make-col').addEventListener('click', async () => {
                    const f1 = document.getElementById('img1').files[0];
                    const f2 = document.getElementById('img2').files[0];
                    if(!f1 || !f2) return;
                    
                    const load = (f) => new Promise(r => {
                        const i = new Image();
                        i.onload = () => r(i);
                        i.src = URL.createObjectURL(f);
                    });
                    
                    const [i1, i2] = await Promise.all([load(f1), load(f2)]);
                    const c = document.getElementById('col-cvs');
                    c.width = i1.width + i2.width;
                    c.height = Math.max(i1.height, i2.height);
                    const cx = c.getContext('2d');
                    cx.drawImage(i1, 0, 0);
                    cx.drawImage(i2, i1.width, 0);
                    c.style.display = 'block';
                });
            </script>
        '''
    },
    'image/mockup-generator.html': {
        'title': 'Device Mockup Generator',
        'desc': 'Place your screenshot inside a device frame.',
        'content': '''
            <h1 class="tool-title">Mockup Generator</h1>
            <div class="tool-interface">
                <input type="file" id="mock-in" accept="image/*">
                <div class="tool-section output-section" id="mock-out" style="padding: 50px; background: #eee; text-align: center; display:none;">
                    <div style="border: 10px solid #333; border-radius: 20px; display: inline-block; overflow: hidden; bg:white;">
                        <img id="mock-img" style="max-width: 300px; display:block;">
                    </div>
                </div>
            </div>
            <script>
                document.getElementById('mock-in').addEventListener('change', (e) => {
                    const f = e.target.files[0];
                    if(f) {
                        document.getElementById('mock-img').src = URL.createObjectURL(f);
                        document.getElementById('mock-out').style.display = 'block';
                    }
                });
            </script>
        '''
    },
     'image/instagram-editor.html': {
        'title': 'Instagram Photo Editor',
        'desc': 'Apply filters to your photos before posting.',
        'content': '''
            <h1 class="tool-title">Instagram Filter Editor</h1>
            <div class="tool-interface">
                <input type="file" id="ig-in" accept="image/*">
                <div class="tool-actions" style="margin-top:10px;">
                    <button onclick="apply('grayscale(100%)')" class="btn btn-sm">B&W</button>
                    <button onclick="apply('sepia(100%)')" class="btn btn-sm">Sepia</button>
                    <button onclick="apply('contrast(150%)')" class="btn btn-sm">Contrast</button>
                    <button onclick="apply('none')" class="btn btn-sm">Reset</button>
                </div>
                <div class="tool-section output-section">
                    <img id="ig-img" style="max-width:100%; transition: filter 0.3s;">
                </div>
            </div>
            <script>
                document.getElementById('ig-in').addEventListener('change', (e) => {
                    if(e.target.files[0]) document.getElementById('ig-img').src = URL.createObjectURL(e.target.files[0]);
                });
                window.apply = (f) => document.getElementById('ig-img').style.filter = f;
            </script>
        '''
    },
    'seo/backlink-checker.html': {
        'title': 'Dead Link Checker',
        'desc': 'Check if a specific link is reachable (Client-Side Check).',
        'content': '''
            <h1 class="tool-title">Link Status Checker</h1>
            <div class="tool-interface">
                <input type="text" id="ln-url" class="form-input" placeholder="https://example.com/image.png">
                <button id="ln-check" class="btn btn-primary" style="margin-top:10px;">Check Status</button>
                <div id="ln-res" class="tool-section output-section"></div>
            </div>
            <script>
                document.getElementById('ln-check').addEventListener('click', async () => {
                   const u = document.getElementById('ln-url').value;
                   const r = document.getElementById('ln-res');
                   r.innerHTML = 'Checking... (Note: CORS restrictions apply)';
                   try {
                       const res = await fetch(u, {method: 'HEAD'});
                       r.innerHTML = res.ok ? '<span style="color:green">Active (200)</span>' : '<span style="color:red">Error</span>';
                   } catch(e) {
                       r.innerHTML = 'Likely Active (or CORS blocked)';
                   }
                });
            </script>
        '''
    }
}

def main():
    for path, data in TOOLS.items():
        file_path = Path(f'./tools/{path}')
        file_path.parent.mkdir(parents=True, exist_ok=True)
        slug = path.split('/')[-1].replace('.html', '')
        cat = path.split('/')[0]
        schema = {"@context": "https://schema.org","@type": "SoftwareApplication","name": data['title'],"description": data['desc']}
        html = get_header(data['title'], data['desc'], slug, cat) + data['content'] + get_footer(json.dumps(schema))
        with open(file_path, 'w', encoding='utf-8') as f: f.write(html)
        print(f"Generated: {path}")

if __name__ == '__main__': main()
