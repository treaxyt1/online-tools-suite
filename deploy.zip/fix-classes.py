#!/usr/bin/env python3
"""
Fix remaining class name inconsistencies in tool pages
"""

import os
import re
from pathlib import Path

class Colors:
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    RESET = '\033[0m'

def print_colored(text, color):
    try:
        print(f"{color}{text}{Colors.RESET}")
    except UnicodeEncodeError:
        print(text.encode('ascii', 'replace').decode('ascii'))

def fix_file(file_path):
    """Fix class name inconsistencies in a single file"""
    
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    original_content = content
    
    # Fix 1: Replace panel-actions with output-actions
    content = content.replace('class="panel-actions"', 'class="output-actions"')
    content = content.replace("class='panel-actions'", "class='output-actions'")
    
    # Fix 2: Replace tool-panel with tool-section (but not in comments)
    content = content.replace('class="tool-panel"', 'class="tool-section"')
    content = content.replace("class='tool-panel'", "class='tool-section'")
    
    # Fix 3: Replace panel-header with output-header (in output contexts)
    content = content.replace('class="panel-header"', 'class="output-header"')
    content = content.replace("class='panel-header'", "class='output-header'")
    
    # Fix 4: Replace panel-title with tool-section-title
    content = content.replace('class="panel-title"', 'class="tool-section-title"')
    content = content.replace("class='panel-title'", "class='tool-section-title'")
    
    # Fix 5: Remove Tailwind utility classes from info-section
    # Replace mt-12, mt-4, etc. with proper inline styles
    content = re.sub(
        r'class="info-section\s+mt-\d+"',
        'class="info-section" style="margin-top: var(--space-8);"',
        content
    )
    
    # Fix 6: Replace other common Tailwind classes
    content = content.replace('class="mt-4"', 'style="margin-top: var(--space-4);"')
    content = content.replace('class="mb-4"', 'style="margin-bottom: var(--space-4);"')
    content = content.replace('class="mt-6"', 'style="margin-top: var(--space-6);"')
    content = content.replace('class="mb-6"', 'style="margin-bottom: var(--space-6);"')
    content = content.replace('class="mt-8"', 'style="margin-top: var(--space-8);"')
    
    # Fix 7: Replace btn-ghost btn-sm with proper classes
    content = content.replace('class="btn-ghost btn-sm"', 'class="btn btn-ghost btn-sm"')
    
    # Fix 8: Ensure proper info-section styling
    info_section_pattern = r'<section class="info-section"([^>]*)>'
    def add_info_section_style(match):
        existing_attrs = match.group(1)
        if 'style=' not in existing_attrs:
            return f'<section class="info-section" style="margin-top: var(--space-8); padding: var(--space-6); background: var(--bg-primary); border: 1px solid var(--border-light); border-radius: var(--radius-xl);">'
        return match.group(0)
    
    content = re.sub(info_section_pattern, add_info_section_style, content)
    
    # Only write if content changed
    if content != original_content:
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(content)
        return True
    return False

def main():
    print_colored("="*60, Colors.CYAN)
    print_colored("Fixing Class Name Inconsistencies", Colors.CYAN)
    print_colored("="*60, Colors.CYAN)
    print()
    
    tools_dir = Path('./tools')
    
    if not tools_dir.exists():
        print_colored("Error: ./tools directory not found!", Colors.RED)
        return
    
    # Find all HTML files
    html_files = list(tools_dir.rglob('*.html'))
    
    print_colored(f"Scanning {len(html_files)} HTML files...\n", Colors.YELLOW)
    
    fixed_count = 0
    
    for file_path in html_files:
        try:
            if fix_file(file_path):
                relative_path = file_path.relative_to(Path('.'))
                print_colored(f"[+] Fixed: {relative_path}", Colors.GREEN)
                fixed_count += 1
        except Exception as e:
            relative_path = file_path.relative_to(Path('.'))
            print_colored(f"[X] Error in {relative_path}: {str(e)}", Colors.RED)
    
    print()
    print_colored("="*60, Colors.CYAN)
    print_colored("Fix Complete!", Colors.CYAN)
    print_colored("="*60, Colors.CYAN)
    print_colored(f"[+] Fixed: {fixed_count} files", Colors.GREEN)
    print_colored(f"[-] Unchanged: {len(html_files) - fixed_count} files", Colors.YELLOW)

if __name__ == '__main__':
    main()
