#!/usr/bin/env python3
"""
Comprehensive Headless Testing Suite
Tests all 30 tools without opening browser
Performs deep validation of HTML, CSS, JavaScript, and functionality
"""

from pathlib import Path
import re
import json

# All 30 tools to test
ALL_TOOLS = {
    'Productivity': [
        'tools/productivity/tip-calculator.html',
        'tools/productivity/character-counter.html',
        'tools/productivity/todo-list.html',
        'tools/productivity/note-taking.html',
        'tools/productivity/habit-tracker.html',
        'tools/productivity/decision-maker.html',
        'tools/productivity/focus-timer.html',
        'tools/productivity/time-until.html',
    ],
    'Finance': [
        'tools/finance/salary-calculator.html',
        'tools/finance/loan-calculator.html',
        'tools/finance/budget-planner.html',
        'tools/finance/price-comparison.html',
        'tools/finance/freelance-rate.html',
    ],
    'Writing': [
        'tools/writing/paraphrasing-tool.html',
        'tools/writing/essay-outline.html',
        'tools/writing/readability-score.html',
        'tools/writing/plagiarism-checker.html',
        'tools/writing/word-frequency.html',
    ],
    'SEO': [
        'tools/seo/utm-builder.html',
        'tools/seo/keyword-density.html',
        'tools/seo/robots-txt.html',
        'tools/seo/meta-preview.html',
        'tools/seo/backlink-checker.html',
        'tools/seo/og-image-generator.html',
    ],
    'Image': [
        'tools/image/image-compressor.html',
        'tools/image/transparent-maker.html',
        'tools/image/photo-collage.html',
        'tools/image/mockup-generator.html',
        'tools/image/instagram-editor.html',
    ]
}

class ToolValidator:
    def __init__(self, filepath):
        self.filepath = Path(filepath)
        self.content = ""
        self.errors = []
        self.warnings = []
        self.passed_checks = []
        
    def load_file(self):
        """Load file content"""
        try:
            with open(self.filepath, 'r', encoding='utf-8') as f:
                self.content = f.read()
            return True
        except Exception as e:
            self.errors.append(f"Failed to load file: {e}")
            return False
    
    def validate_html_structure(self):
        """Validate HTML structure"""
        checks = {
            'DOCTYPE': r'<!DOCTYPE html>',
            'HTML tag': r'<html[^>]*>',
            'Head section': r'<head>',
            'Body section': r'<body>',
            'Title tag': r'<title>.*?</title>',
            'Meta charset': r'<meta charset=',
            'Meta viewport': r'<meta name="viewport"',
            'Meta description': r'<meta name="description"',
        }
        
        for check_name, pattern in checks.items():
            if re.search(pattern, self.content, re.IGNORECASE):
                self.passed_checks.append(f"HTML: {check_name}")
            else:
                self.warnings.append(f"Missing: {check_name}")
    
    def validate_seo_elements(self):
        """Validate SEO elements"""
        # Check title length
        title_match = re.search(r'<title>(.*?)</title>', self.content)
        if title_match:
            title = title_match.group(1)
            if 30 <= len(title) <= 60:
                self.passed_checks.append(f"SEO: Title length optimal ({len(title)} chars)")
            else:
                self.warnings.append(f"SEO: Title length suboptimal ({len(title)} chars, should be 30-60)")
        
        # Check meta description
        desc_match = re.search(r'<meta name="description" content="(.*?)"', self.content)
        if desc_match:
            desc = desc_match.group(1)
            if 120 <= len(desc) <= 160:
                self.passed_checks.append(f"SEO: Description length optimal ({len(desc)} chars)")
            else:
                self.warnings.append(f"SEO: Description length suboptimal ({len(desc)} chars, should be 120-160)")
        
        # Check canonical URL
        if 'rel="canonical"' in self.content:
            self.passed_checks.append("SEO: Canonical URL present")
        else:
            self.warnings.append("SEO: Missing canonical URL")
        
        # Check schema markup
        if 'application/ld+json' in self.content:
            self.passed_checks.append("SEO: Schema markup present")
            # Validate JSON-LD
            try:
                schema_match = re.search(r'<script type="application/ld\+json">(.*?)</script>', self.content, re.DOTALL)
                if schema_match:
                    json.loads(schema_match.group(1))
                    self.passed_checks.append("SEO: Schema markup valid JSON")
            except:
                self.warnings.append("SEO: Schema markup invalid JSON")
        else:
            self.warnings.append("SEO: Missing schema markup")
    
    def validate_css_integration(self):
        """Validate CSS integration"""
        if 'design-system.css' in self.content:
            self.passed_checks.append("CSS: design-system.css linked")
        else:
            self.errors.append("CSS: Missing design-system.css")
        
        # Check for inline styles (should be minimal)
        inline_styles = len(re.findall(r'style="[^"]*"', self.content))
        if inline_styles < 50:
            self.passed_checks.append(f"CSS: Minimal inline styles ({inline_styles})")
        else:
            self.warnings.append(f"CSS: Many inline styles ({inline_styles})")
    
    def validate_javascript(self):
        """Validate JavaScript integration and syntax"""
        # Check for required scripts
        required_scripts = ['tools.js', 'ui.js', 'app.js']
        for script in required_scripts:
            if script in self.content:
                self.passed_checks.append(f"JS: {script} linked")
            else:
                self.warnings.append(f"JS: Missing {script}")
        
        # Check for Components.render calls
        if 'Components.render' in self.content:
            self.passed_checks.append("JS: Components.render present")
        else:
            self.warnings.append("JS: Missing Components.render calls")
        
        # Extract and validate JavaScript
        js_blocks = re.findall(r'<script>(.*?)</script>', self.content, re.DOTALL)
        
        for i, js in enumerate(js_blocks):
            # Skip external scripts
            if not js.strip():
                continue
            
            # Check for common syntax issues
            if js.count('{') != js.count('}'):
                self.errors.append(f"JS Block {i+1}: Mismatched curly braces")
            if js.count('(') != js.count(')'):
                self.errors.append(f"JS Block {i+1}: Mismatched parentheses")
            if js.count('[') != js.count(']'):
                self.errors.append(f"JS Block {i+1}: Mismatched square brackets")
            
            # Check for console.log (debug code)
            if 'console.log' in js:
                self.warnings.append(f"JS Block {i+1}: Contains console.log (debug code)")
            
            # Check for addEventListener
            if 'addEventListener' in js:
                self.passed_checks.append(f"JS Block {i+1}: Event listeners present")
    
    def validate_accessibility(self):
        """Validate accessibility features"""
        # Check for form labels
        inputs = len(re.findall(r'<input[^>]*>', self.content))
        labels = len(re.findall(r'<label[^>]*>', self.content))
        
        if inputs > 0 and labels >= inputs * 0.8:  # At least 80% of inputs have labels
            self.passed_checks.append(f"A11y: Good label coverage ({labels}/{inputs})")
        elif inputs > 0:
            self.warnings.append(f"A11y: Insufficient labels ({labels}/{inputs})")
        
        # Check for alt text on images
        imgs = re.findall(r'<img[^>]*>', self.content)
        imgs_with_alt = [img for img in imgs if 'alt=' in img]
        if len(imgs) > 0:
            if len(imgs_with_alt) == len(imgs):
                self.passed_checks.append(f"A11y: All images have alt text")
            else:
                self.warnings.append(f"A11y: Some images missing alt text ({len(imgs_with_alt)}/{len(imgs)})")
    
    def validate_mobile_responsive(self):
        """Check for mobile responsiveness indicators"""
        # Check viewport meta tag
        if 'width=device-width' in self.content:
            self.passed_checks.append("Mobile: Viewport meta tag present")
        else:
            self.errors.append("Mobile: Missing viewport meta tag")
        
        # Check for responsive CSS patterns
        responsive_patterns = [
            r'@media',
            r'max-width',
            r'min-width',
            r'grid-template-columns.*repeat',
            r'flex',
        ]
        
        responsive_count = sum(1 for pattern in responsive_patterns if re.search(pattern, self.content))
        if responsive_count >= 2:
            self.passed_checks.append(f"Mobile: Responsive patterns detected ({responsive_count})")
        else:
            self.warnings.append(f"Mobile: Few responsive patterns ({responsive_count})")
    
    def validate_performance(self):
        """Check for performance indicators"""
        # Check file size
        file_size = len(self.content.encode('utf-8'))
        if file_size < 50000:  # 50KB
            self.passed_checks.append(f"Performance: Small file size ({file_size/1024:.1f}KB)")
        elif file_size < 100000:  # 100KB
            self.warnings.append(f"Performance: Moderate file size ({file_size/1024:.1f}KB)")
        else:
            self.warnings.append(f"Performance: Large file size ({file_size/1024:.1f}KB)")
        
        # Check for external dependencies
        external_deps = len(re.findall(r'https?://', self.content))
        if external_deps < 5:
            self.passed_checks.append(f"Performance: Few external deps ({external_deps})")
        else:
            self.warnings.append(f"Performance: Many external deps ({external_deps})")
    
    def run_all_tests(self):
        """Run all validation tests"""
        if not self.load_file():
            return False
        
        self.validate_html_structure()
        self.validate_seo_elements()
        self.validate_css_integration()
        self.validate_javascript()
        self.validate_accessibility()
        self.validate_mobile_responsive()
        self.validate_performance()
        
        return len(self.errors) == 0
    
    def get_summary(self):
        """Get test summary"""
        return {
            'passed': len(self.passed_checks),
            'warnings': len(self.warnings),
            'errors': len(self.errors),
            'total_checks': len(self.passed_checks) + len(self.warnings) + len(self.errors)
        }

def main():
    print("=" * 80)
    print("COMPREHENSIVE HEADLESS TESTING - 30 TOOLS")
    print("=" * 80)
    print()
    
    total_tools = 0
    passed_tools = 0
    total_checks = 0
    total_passed = 0
    total_warnings = 0
    total_errors = 0
    
    results = {}
    
    for category, tools in ALL_TOOLS.items():
        print(f"\n{'='*80}")
        print(f"CATEGORY: {category}")
        print(f"{'='*80}\n")
        
        category_results = []
        
        for tool_path in tools:
            total_tools += 1
            tool_name = Path(tool_path).stem.replace('-', ' ').title()
            
            print(f"[{total_tools}/30] Testing: {tool_name}")
            
            validator = ToolValidator(tool_path)
            success = validator.run_all_tests()
            summary = validator.get_summary()
            
            total_checks += summary['total_checks']
            total_passed += summary['passed']
            total_warnings += summary['warnings']
            total_errors += summary['errors']
            
            if success:
                passed_tools += 1
                status = "[PASS]"
            else:
                status = "[FAIL]"
            
            print(f"  {status} Checks: {summary['passed']} passed, {summary['warnings']} warnings, {summary['errors']} errors")
            
            # Show errors if any
            if validator.errors:
                print("  ERRORS:")
                for error in validator.errors[:3]:  # Show first 3 errors
                    print(f"    - {error}")
            
            # Show warnings if any
            if validator.warnings and len(validator.warnings) <= 3:
                print("  WARNINGS:")
                for warning in validator.warnings:
                    print(f"    - {warning}")
            elif validator.warnings:
                print(f"  WARNINGS: {len(validator.warnings)} total")
            
            category_results.append({
                'name': tool_name,
                'path': tool_path,
                'success': success,
                'summary': summary,
                'errors': validator.errors,
                'warnings': validator.warnings
            })
            
            print()
        
        results[category] = category_results
    
    # Final Summary
    print("\n" + "=" * 80)
    print("FINAL TEST SUMMARY")
    print("=" * 80)
    print(f"\nTools Tested: {total_tools}")
    print(f"Tools Passed: {passed_tools}")
    print(f"Tools Failed: {total_tools - passed_tools}")
    print(f"Success Rate: {(passed_tools/total_tools)*100:.1f}%")
    print(f"\nTotal Checks: {total_checks}")
    print(f"Checks Passed: {total_passed}")
    print(f"Warnings: {total_warnings}")
    print(f"Errors: {total_errors}")
    print(f"Check Pass Rate: {(total_passed/total_checks)*100:.1f}%")
    
    # Category breakdown
    print("\n" + "=" * 80)
    print("CATEGORY BREAKDOWN")
    print("=" * 80)
    for category, tools in results.items():
        passed = sum(1 for t in tools if t['success'])
        total = len(tools)
        print(f"\n{category}: {passed}/{total} passed ({(passed/total)*100:.0f}%)")
    
    # Common issues
    print("\n" + "=" * 80)
    print("COMMON ISSUES FOUND")
    print("=" * 80)
    
    all_warnings = {}
    for category_tools in results.values():
        for tool in category_tools:
            for warning in tool['warnings']:
                # Extract warning type
                warning_type = warning.split(':')[0] if ':' in warning else warning
                all_warnings[warning_type] = all_warnings.get(warning_type, 0) + 1
    
    if all_warnings:
        print("\nMost Common Warnings:")
        for warning, count in sorted(all_warnings.items(), key=lambda x: x[1], reverse=True)[:5]:
            print(f"  - {warning}: {count} occurrences")
    else:
        print("\nNo common warnings found!")
    
    print("\n" + "=" * 80)
    print("TESTING COMPLETE")
    print("=" * 80)
    print("\nAll tools have been validated without opening a browser.")
    print("See results above for detailed breakdown.")
    print()

if __name__ == '__main__':
    main()
