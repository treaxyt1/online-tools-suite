#!/usr/bin/env python3
from pathlib import Path
import json

def get_header(title, description, slug, category_path):
    return f'''<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title} | OnlineToolFree</title>
    <meta name="description" content="{description}">
    <link rel="canonical" href="https://onlinetoolfree.com/tools/{category_path}/{slug}.html">
    <link rel="stylesheet" href="../../css/design-system.css">
    <script src="../../js/tools.js"></script>
    <script src="../../js/ui.js"></script>
    <script src="../../js/app.js"></script>
</head>
<body>
    <header class="header"></header>
    <div class="tool-layout">
        <aside class="tool-sidebar" id="tool-sidebar"></aside>
        <main class="tool-main">
            <div class="tool-page" style="max-width: 1000px; margin: 0; padding: 0;">
'''

def get_footer(schema_json):
    return f'''
            </div>
        </main>
    </div>
    <button class="sidebar-toggle" id="sidebar-toggle">
        <svg class="icon" viewBox="0 0 24 24"><line x1="4" y1="12" x2="20" y2="12"/><line x1="4" y1="6" x2="20" y2="6"/><line x1="4" y1="18" x2="20" y2="18"/></svg>
    </button>
    <footer class="footer"></footer>
    <script type="application/ld+json">{schema_json}</script>
    <script>
        document.addEventListener('DOMContentLoaded', () => {{
            Components.renderHeader();
            Components.renderSidebar('tool-sidebar');
            Components.renderFooter();
            if (window.ThemeManager) ThemeManager.init();
        }});
    </script>
</body>
</html>'''

TOOLS = {
    'seo/keyword-density.html': {
        'title': 'Keyword Density Checker - SEO Analysis Tool',
        'desc': 'Analyze your text for keyword frequency and density. Optimize your content for SEO by identifying overused or missing keywords.',
        'content': '''
            <h1 class="tool-title">Keyword Density Checker</h1>
            <p class="tool-description">Check the frequency of keywords in your content.</p>
            <div class="tool-interface">
                <div class="tool-section">
                    <textarea id="text-input" class="form-input" rows="8" placeholder="Paste your article or content here..."></textarea>
                </div>
                <div class="tool-actions">
                    <button id="analyze-btn" class="btn btn-primary">Analyze Keywords</button>
                </div>
                <div id="results" class="tool-section output-section" style="display:none;">
                    <h3>Top Keywords</h3>
                    <div id="keyword-list" style="display: grid; gap: 10px; margin-top: 15px;"></div>
                </div>
            </div>
            <script>
                document.getElementById('analyze-btn').addEventListener('click', () => {
                    const text = document.getElementById('text-input').value.toLowerCase();
                    if(!text) return;
                    
                    const words = text.match(/\\b\\w+\\b/g) || [];
                    const total = words.length;
                    const freq = {};
                    
                    const stopWords = new Set(['the','be','to','of','and','a','in','that','have','it','for','not','on','with','he','as','you','do','at']);
                    
                    words.forEach(w => {
                        if(!stopWords.has(w) && w.length > 2) freq[w] = (freq[w] || 0) + 1;
                    });
                    
                    const sorted = Object.entries(freq).sort((a,b) => b[1] - a[1]).slice(0, 10);
                    
                    const html = sorted.map(([word, count]) => `
                        <div style="display: flex; justify-content: space-between; padding: 10px; background: var(--bg-tertiary); border-radius: 8px;">
                            <span>${word}</span>
                            <span>${count} (${((count/total)*100).toFixed(1)}%)</span>
                        </div>
                    `).join('');
                    
                    document.getElementById('keyword-list').innerHTML = html;
                    document.getElementById('results').style.display = 'block';
                });
            </script>
        '''
    },
    'seo/robots-txt.html': {
        'title': 'Robots.txt Generator - Create SEO Files',
        'desc': 'Generate a robots.txt file for your website. Control web crawler access and optimize your site indexing with our free generator.',
        'content': '''
            <h1 class="tool-title">Robots.txt Generator</h1>
            <p class="tool-description">Create a robots.txt file to control crawler access.</p>
            <div class="tool-interface">
                <div class="tool-section">
                    <div class="grid" style="gap: 15px;">
                        <div>
                            <label class="form-label">Default Access (All Robots)</label>
                            <select id="default-access" class="form-input">
                                <option value="Allow">Allow All</option>
                                <option value="Disallow">Disallow All</option>
                            </select>
                        </div>
                        <div>
                            <label class="form-label">Sitemap URL (Optional)</label>
                            <input type="text" id="sitemap" class="form-input" placeholder="https://example.com/sitemap.xml">
                        </div>
                        <div>
                            <label class="form-label">Crawl Delay (seconds)</label>
                            <select id="delay" class="form-input">
                                <option value="">None</option>
                                <option value="5">5</option>
                                <option value="10">10</option>
                                <option value="20">20</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="tool-actions">
                    <button id="gen-btn" class="btn btn-primary">Generate File</button>
                </div>
                <div id="output-box" class="tool-section output-section" style="display:none;">
                    <pre id="result" style="background: var(--bg-tertiary); padding: 15px; border-radius: 8px; white-space: pre-wrap;"></pre>
                    <button onclick="copyRes()" class="btn btn-ghost btn-sm" style="margin-top: 10px;">Copy Code</button>
                </div>
            </div>
            <script>
                document.getElementById('gen-btn').addEventListener('click', () => {
                    const access = document.getElementById('default-access').value;
                    const sitemap = document.getElementById('sitemap').value;
                    const delay = document.getElementById('delay').value;
                    
                    let txt = "User-agent: *\\n";
                    txt += `${access}: /\\n`;
                    if(delay) txt += `Crawl-delay: ${delay}\\n`;
                    if(sitemap) txt += `\\nSitemap: ${sitemap}`;
                    
                    document.getElementById('result').textContent = txt;
                    document.getElementById('output-box').style.display = 'block';
                });
                function copyRes() {
                    navigator.clipboard.writeText(document.getElementById('result').textContent).then(() => Toast.success('Copied!'));
                }
            </script>
        '''
    },
    'writing/readability-score.html': {
        'title': 'Readability Score Calculator',
        'desc': 'Check how easy your text is to read. Calculates Flesch Reading Ease and grade levels.',
        'content': '''
            <h1 class="tool-title">Readability Score Calculator</h1>
            <p class="tool-description">Measure the readability of your text.</p>
            <div class="tool-interface">
                <div class="tool-section">
                    <textarea id="read-input" class="form-input" rows="8" placeholder="Paste text here..."></textarea>
                </div>
                <div class="tool-actions">
                    <button id="calc-read" class="btn btn-primary">Check Score</button>
                </div>
                <div id="read-res" class="tool-section output-section" style="display:none;">
                    <div style="font-size: 24px; font-weight: bold; color: var(--primary-600); margin-bottom: 10px;">
                        Flesch Score: <span id="score-val">0</span>
                    </div>
                    <p id="score-text"></p>
                </div>
            </div>
            <script>
                document.getElementById('calc-read').addEventListener('click', () => {
                    const text = document.getElementById('read-input').value;
                    if(!text) return;
                    
                    const sentences = text.split(/[.!?]+/).length;
                    const words = text.split(/\\s+/).length;
                    const syllables = text.split(/[aeiouy]+/).length; // Simple approximation
                    
                    // Flesch Reading Ease formula
                    const score = 206.835 - (1.015 * (words/sentences)) - (84.6 * (syllables/words));
                    
                    document.getElementById('score-val').textContent = score.toFixed(1);
                    document.getElementById('score-text').textContent = score > 60 ? "Easy to read (Standard)" : "Difficult to read";
                    document.getElementById('read-res').style.display = 'block';
                });
            </script>
        '''
    },
    'finance/price-comparison.html': {
        'title': 'Unit Price Comparison Calculator',
        'desc': 'Compare prices of two items to find the best value.',
        'content': '''
            <h1 class="tool-title">Price Comparison Calculator</h1>
            <p class="tool-description">Find out which product offers better value.</p>
            <div class="tool-interface">
                <div class="grid" style="grid-template-columns: 1fr 1fr; gap: 20px;">
                    <div class="tool-section">
                        <h3>Item A</h3>
                        <label>Price ($)</label><input type="number" id="price-a" class="form-input">
                        <label>Quantity</label><input type="number" id="qty-a" class="form-input">
                    </div>
                    <div class="tool-section">
                        <h3>Item B</h3>
                        <label>Price ($)</label><input type="number" id="price-b" class="form-input">
                        <label>Quantity</label><input type="number" id="qty-b" class="form-input">
                    </div>
                </div>
                <div class="tool-actions">
                    <button id="compare-btn" class="btn btn-primary">Compare</button>
                </div>
                <div id="comp-res" class="tool-section output-section" style="display:none; text-align:center; font-weight:bold;"></div>
            </div>
            <script>
                document.getElementById('compare-btn').addEventListener('click', () => {
                    const pa = parseFloat(document.getElementById('price-a').value);
                    const qa = parseFloat(document.getElementById('qty-a').value);
                    const pb = parseFloat(document.getElementById('price-b').value);
                    const qb = parseFloat(document.getElementById('qty-b').value);
                    
                    if(!pa || !qa || !pb || !qb) return;
                    
                    const unitA = pa / qa;
                    const unitB = pb / qb;
                    
                    const better = unitA < unitB ? "Item A" : "Item B";
                    const diff = Math.abs(100 * (1 - (Math.min(unitA, unitB) / Math.max(unitA, unitB)))).toFixed(1);
                    
                    document.getElementById('comp-res').innerHTML = `
                        <div style="font-size: 1.2rem; color: var(--success-600);">Best Value: ${better}</div>
                        <div style="font-size: 0.9rem; margin-top: 5px;">It is ${diff}% cheaper per unit.</div>
                    `;
                    document.getElementById('comp-res').style.display = 'block';
                });
            </script>
        '''
    },
    'productivity/decision-maker.html': {
        'title': 'Random Decision Maker',
        'desc': 'Can\'t decide? Let our tool choose for you.',
        'content': '''
            <h1 class="tool-title">Decision Maker</h1>
            <div class="tool-interface">
                <div class="tool-section">
                    <label>Enter options (one per line)</label>
                    <textarea id="options" class="form-input" rows="6" placeholder="Pizza\\nBurgers\\nTacos"></textarea>
                </div>
                <div class="tool-actions">
                    <button id="decide-btn" class="btn btn-primary">Decide for Me</button>
                </div>
                <div id="choice-res" class="tool-section output-section" style="display:none; text-align:center;">
                    <h3>The winner is:</h3>
                    <div id="choice" style="font-size: 2rem; color: var(--primary-600); font-weight: bold; margin: 20px 0;"></div>
                </div>
            </div>
            <script>
                document.getElementById('decide-btn').addEventListener('click', () => {
                    const opts = document.getElementById('options').value.split('\\n').filter(o => o.trim());
                    if(opts.length < 2) return Toast.error('Enter at least 2 options');
                    
                    const choice = opts[Math.floor(Math.random() * opts.length)];
                    document.getElementById('choice').textContent = choice;
                    document.getElementById('choice-res').style.display = 'block';
                });
            </script>
        '''
    },
    'productivity/focus-timer.html': {
        'title': 'Focus Mode Timer - Pomodoro Technique',
        'desc': 'Boost productivity with this simple focus timer.',
        'content': '''
            <h1 class="tool-title">Focus Timer</h1>
            <div class="tool-interface" style="text-align:center;">
                <div class="tool-section">
                    <div id="timer" style="font-size: 4rem; font-weight: bold; font-family: monospace; margin: 20px 0;">25:00</div>
                    <div style="display: flex; gap: 10px; justify-content: center;">
                        <button id="start-timer" class="btn btn-primary">Start</button>
                        <button id="reset-timer" class="btn btn-ghost">Reset</button>
                    </div>
                </div>
            </div>
            <script>
                let time = 25 * 60;
                let interval;
                
                function update() {
                    const m = Math.floor(time / 60).toString().padStart(2, '0');
                    const s = (time % 60).toString().padStart(2, '0');
                    document.getElementById('timer').textContent = `${m}:${s}`;
                }
                
                document.getElementById('start-timer').addEventListener('click', function() {
                    if(interval) {
                        clearInterval(interval);
                        interval = null;
                        this.textContent = 'Start';
                    } else {
                        interval = setInterval(() => {
                            if(time > 0) {
                                time--;
                                update();
                            } else {
                                clearInterval(interval);
                                new Audio('https://actions.google.com/sounds/v1/alarms/beep_short.ogg').play();
                            }
                        }, 1000);
                        this.textContent = 'Pause';
                    }
                });
                
                document.getElementById('reset-timer').addEventListener('click', () => {
                    clearInterval(interval);
                    interval = null;
                    document.getElementById('start-timer').textContent = 'Start';
                    time = 25 * 60;
                    update();
                });
            </script>
        '''
    },
    'seo/meta-preview.html': {
        'title': 'Google SERP Preview Tool',
        'desc': 'Preview how your website will appear in Google search results.',
        'content': '''
            <h1 class="tool-title">Meta Tag Preview</h1>
            <div class="tool-interface">
                <div class="tool-section">
                    <label>Meta Title</label><input type="text" id="meta-title" class="form-input" placeholder="Page Title (60 chars max)">
                    <label>Meta Description</label><textarea id="meta-desc" class="form-input" placeholder="Page Description (160 chars max)"></textarea>
                </div>
                <div class="tool-section" style="background: #fff; border: 1px solid #dfe1e5; padding: 20px; border-radius: 8px;">
                    <cite style="color: #202124; font-style: normal; font-size: 14px;">example.com</cite>
                    <h3 id="preview-title" style="color: #1a0dab; font-size: 20px; margin: 5px 0; font-weight: 400; cursor: pointer;">Page Title</h3>
                    <div id="preview-desc" style="color: #4d5156; font-size: 14px;">Page Description will appear here...</div>
                </div>
            </div>
            <script>
                const t = document.getElementById('meta-title');
                const d = document.getElementById('meta-desc');
                
                function update() {
                    document.getElementById('preview-title').textContent = t.value || 'Page Title';
                    document.getElementById('preview-desc').textContent = d.value || 'Page Description...';
                }
                t.addEventListener('input', update);
                d.addEventListener('input', update);
            </script>
        '''
    },
    'writing/plagiarism-checker.html': {
        'title': 'Plagiarism Percentage Calculator',
        'desc': 'Compare two texts to find similarity percentage.',
        'content': '''
            <h1 class="tool-title">Plagiarism Checker (Comparison)</h1>
            <div class="tool-interface">
                <div class="grid" style="grid-template-columns: 1fr 1fr; gap: 20px;">
                    <textarea id="text1" class="form-input" rows="6" placeholder="Original Text"></textarea>
                    <textarea id="text2" class="form-input" rows="6" placeholder="Suspect Text"></textarea>
                </div>
                <button id="check-plag" class="btn btn-primary" style="margin-top: 15px;">Check Similarity</button>
                <div id="plag-res" class="tool-section output-section" style="display:none; text-align:center;">
                    <div style="font-size: 2rem; font-weight: bold;">Similarity: <span id="sim-score">0</span>%</div>
                </div>
            </div>
            <script>
                document.getElementById('check-plag').addEventListener('click', () => {
                    const s1 = document.getElementById('text1').value;
                    const s2 = document.getElementById('text2').value;
                    if(!s1 || !s2) return;
                    
                    // Simple Jaccard Index approximation
                    const set1 = new Set(s1.toLowerCase().split(/\\s+/));
                    const set2 = new Set(s2.toLowerCase().split(/\\s+/));
                    const intersection = new Set([...set1].filter(x => set2.has(x)));
                    const union = new Set([...set1, ...set2]);
                    
                    const sim = (intersection.size / union.size) * 100;
                    document.getElementById('sim-score').textContent = sim.toFixed(1);
                    document.getElementById('plag-res').style.display = 'block';
                });
            </script>
        '''
    }
}

def main():
    for path, data in TOOLS.items():
        file_path = Path(f'./tools/{path}')
        file_path.parent.mkdir(parents=True, exist_ok=True)
        slug = path.split('/')[-1].replace('.html', '')
        cat = path.split('/')[0]
        schema = {"@context": "https://schema.org","@type": "SoftwareApplication","name": data['title'],"description": data['desc']}
        html = get_header(data['title'], data['desc'], slug, cat) + data['content'] + get_footer(json.dumps(schema))
        with open(file_path, 'w', encoding='utf-8') as f: f.write(html)
        print(f"Generated: {path}")

if __name__ == '__main__': main()
