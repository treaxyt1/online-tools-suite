#!/usr/bin/env python3
"""
Add Functional Content to Emulator Utility Pages
Removes "Coming Soon" placeholders with working tools
"""

from pathlib import Path

LEGAL_NOTICE = '''<div class="legal-notice" style="background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%); border-left: 4px solid #f59e0b; padding: var(--space-4); border-radius: var(--radius-lg); margin-bottom: var(--space-6);">
    <div style="display: flex; align-items: start; gap: var(--space-3);">
        <svg class="icon" style="color: #f59e0b; flex-shrink: 0; margin-top: 2px;" viewBox="0 0 24 24">
            <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>
            <line x1="12" y1="9" x2="12" y2="13"/>
            <line x1="12" y1="17" x2="12.01" y2="17"/>
        </svg>
        <div>
            <h4 style="margin: 0 0 var(--space-2) 0; font-weight: var(--font-semibold); color: #92400e;">Legal Notice</h4>
            <p style="margin: 0; font-size: var(--text-sm); color: #78350f; line-height: 1.6;">
                <strong>Emulators are legal software.</strong> You must own original games to create personal backups. 
                This site does not host or distribute copyrighted content.
            </p>
        </div>
    </div>
</div>'''

# Emulator utility tools with full functionality
EMULATOR_TOOLS = {
    'fps-tester.html': {
        'name': 'FPS Performance Tester',
        'description': 'Test and measure frame rates for emulator performance',
        'content': '''
                <div class="tool-interface">
                    <div class="tool-section" style="margin-bottom: var(--space-6);">
                        <div class="output-header">
                            <span class="tool-section-title">Performance Monitor</span>
                            <div class="output-actions">
                                <button class="btn btn-ghost btn-sm" id="toggle-test">
                                    <span id="test-status">Start Test</span>
                                </button>
                            </div>
                        </div>
                        <div style="background: var(--bg-tertiary); padding: var(--space-6); border-radius: var(--radius-lg); text-align: center;">
                            <div style="font-size: 4rem; font-weight: var(--font-bold); color: var(--primary-600); margin-bottom: var(--space-4);">
                                <span id="fps-display">0</span>
                                <span style="font-size: var(--text-2xl); color: var(--text-secondary);">FPS</span>
                            </div>
                            <canvas id="fps-chart" width="800" height="200" style="max-width: 100%; height: auto; margin-top: var(--space-4);"></canvas>
                        </div>
                    </div>

                    <div class="tool-section">
                        <h3 style="font-size: var(--text-lg); font-weight: var(--font-semibold); margin-bottom: var(--space-4);">Statistics</h3>
                        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: var(--space-4);">
                            <div style="padding: var(--space-4); background: var(--bg-tertiary); border-radius: var(--radius-lg); text-align: center;">
                                <div style="font-size: var(--text-sm); color: var(--text-secondary); margin-bottom: var(--space-1);">Average</div>
                                <div style="font-size: var(--text-2xl); font-weight: var(--font-semibold);"><span id="avg-fps">0</span> FPS</div>
                            </div>
                            <div style="padding: var(--space-4); background: var(--bg-tertiary); border-radius: var(--radius-lg); text-align: center;">
                                <div style="font-size: var(--text-sm); color: var(--text-secondary); margin-bottom: var(--space-1);">Min</div>
                                <div style="font-size: var(--text-2xl); font-weight: var(--font-semibold);"><span id="min-fps">0</span> FPS</div>
                            </div>
                            <div style="padding: var(--space-4); background: var(--bg-tertiary); border-radius: var(--radius-lg); text-align: center;">
                                <div style="font-size: var(--text-sm); color: var(--text-secondary); margin-bottom: var(--space-1);">Max</div>
                                <div style="font-size: var(--text-2xl); font-weight: var(--font-semibold);"><span id="max-fps">0</span> FPS</div>
                            </div>
                        </div>
                    </div>
                </div>

                <script>
                    let testing = false;
                    let frames = [];
                    let lastTime = performance.now();
                    const canvas = document.getElementById('fps-chart');
                    const ctx = canvas.getContext('2d');

                    function drawChart() {
                        ctx.clearRect(0, 0, canvas.width, canvas.height);
                        ctx.strokeStyle = '#3b82f6';
                        ctx.lineWidth = 2;
                        ctx.beginPath();
                        const step = canvas.width / 60;
                        frames.slice(-60).forEach((fps, i) => {
                            const x = i * step;
                            const y = canvas.height - (fps / 60 * canvas.height);
                            if (i === 0) ctx.moveTo(x, y);
                            else ctx.lineTo(x, y);
                        });
                        ctx.stroke();
                    }

                    function measureFPS() {
                        if (!testing) return;
                        const now = performance.now();
                        const fps = Math.round(1000 / (now - lastTime));
                        lastTime = now;
                        frames.push(fps);
                        if (frames.length > 60) frames.shift();
                        
                        document.getElementById('fps-display').textContent = fps;
                        document.getElementById('avg-fps').textContent = Math.round(frames.reduce((a,b) => a+b, 0) / frames.length);
                        document.getElementById('min-fps').textContent = Math.min(...frames);
                        document.getElementById('max-fps').textContent = Math.max(...frames);
                        
                        drawChart();
                        requestAnimationFrame(measureFPS);
                    }

                    document.getElementById('toggle-test').addEventListener('click', () => {
                        testing = !testing;
                        document.getElementById('test-status').textContent = testing ? 'Stop Test' : 'Start Test';
                        if (testing) {
                            frames = [];
                            lastTime = performance.now();
                            measureFPS();
                            Toast.success('FPS test started');
                        } else {
                            Toast.success('FPS test stopped');
                        }
                    });
                </script>
        '''
    },
    'aspect-ratio.html': {
        'name': 'Aspect Ratio Calculator',
        'description': 'Calculate proper aspect ratios for retro gaming displays',
        'content': '''
                <div class="tool-interface">
                    <div class="tool-section" style="margin-bottom: var(--space-6);">
                        <h3 style="font-size: var(--text-lg); font-weight: var(--font-semibold); margin-bottom: var(--space-4);">Input Dimensions</h3>
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: var(--space-4);">
                            <div>
                                <label class="form-label">Width</label>
                                <input type="number" id="width" class="form-input" value="1920" min="1">
                            </div>
                            <div>
                                <label class="form-label">Height</label>
                                <input type="number" id="height" class="form-input" value="1080" min="1">
                            </div>
                        </div>
                        <button class="btn btn-primary" style="margin-top: var(--space-4); width: 100%;" onclick="calculate()">Calculate</button>
                    </div>

                    <div class="tool-section output-section" id="result" style="display: none;">
                        <div class="output-header">
                            <span class="tool-section-title">Results</span>
                        </div>
                        <div style="background: var(--bg-tertiary); padding: var(--space-6); border-radius: var(--radius-lg);">
                            <div style="font-size: var(--text-3xl); font-weight: var(--font-bold); text-align: center; margin-bottom: var(--space-4);">
                                <span id="ratio-display"></span>
                            </div>
                            <div style="font-size: var(--text-sm); color: var(--text-secondary); text-align: center;" id="common-ratio"></div>
                        </div>
                    </div>

                    <div class="tool-section" style="margin-top: var(--space-6);">
                        <h3 style="font-size: var(--text-lg); font-weight: var(--font-semibold); margin-bottom: var(--space-4);">Common Retro Ratios</h3>
                        <div style="display: grid; gap: var(--space-3);">
                            <div style="padding: var(--space-3); background: var(--bg-tertiary); border-radius: var(--radius-md); display: flex; justify-content: space-between;">
                                <span>4:3 (Classic CRT)</span>
                                <span style="color: var(--text-secondary);">1.333</span>
                            </div>
                            <div style="padding: var(--space-3); background: var(--bg-tertiary); border-radius: var(--radius-md); display: flex; justify-content: space-between;">
                                <span>16:9 (Widescreen)</span>
                                <span style="color: var(--text-secondary);">1.778</span>
                            </div>
                            <div style="padding: var(--space-3); background: var(--bg-tertiary); border-radius: var(--radius-md); display: flex; justify-content: space-between;">
                                <span>16:10 (PC Monitor)</span>
                                <span style="color: var(--text-secondary);">1.600</span>
                            </div>
                            <div style="padding: var(--space-3); background: var(--bg-tertiary); border-radius: var(--radius-md); display: flex; justify-content: space-between;">
                                <span>3:2 (Game Boy Advance)</span>
                                <span style="color: var(--text-secondary);">1.500</span>
                            </div>
                        </div>
                    </div>
                </div>

                <script>
                    function gcd(a, b) {
                        return b === 0 ? a : gcd(b, a % b);
                    }

                    function calculate() {
                        const w = parseInt(document.getElementById('width').value);
                        const h = parseInt(document.getElementById('height').value);
                        const divisor = gcd(w, h);
                        const ratioW = w / divisor;
                        const ratioH = h / divisor;
                        const decimal = (w / h).toFixed(3);

                        document.getElementById('ratio-display').textContent = ratioW + ':' + ratioH;
                        
                        let common = '';
                        if (Math.abs(decimal - 1.333) < 0.01) common = '(4:3 - Classic CRT)';
                        else if (Math.abs(decimal - 1.778) < 0.01) common = '(16:9 - Widescreen)';
                        else if (Math.abs(decimal - 1.600) < 0.01) common = '(16:10 - PC Monitor)';
                        else if (Math.abs(decimal - 1.500) < 0.01) common = '(3:2 - GBA)';
                        else common = 'Decimal: ' + decimal;
                        
                        document.getElementById('common-ratio').textContent = common;
                        document.getElementById('result').style.display = 'block';
                        Toast.success('Aspect ratio calculated!');
                    }
                </script>
        '''
    },
    'input-latency.html': {
        'name': 'Input Latency Tester',
        'description': 'Measure controller and keyboard input lag',
        'content': '''
                <div class="tool-interface">
                    <div class="tool-section" style="margin-bottom: var(--space-6);">
                        <div class="output-header">
                            <span class="tool-section-title">Latency Test</span>
                        </div>
                        <div style="background: var(--bg-tertiary); padding: var(--space-8); border-radius: var(--radius-lg); text-align: center;">
                            <p style="margin-bottom: var(--space-4); font-size: var(--text-lg);">Press any key or button when the circle turns <strong style="color: #22c55e;">GREEN</strong></p>
                            <div id="test-circle" style="width: 200px; height: 200px; border-radius: 50%; background: #ef4444; margin: 0 auto var(--space-6); transition: background 0.1s;"></div>
                            <button class="btn btn-primary" id="start-test">Start Test</button>
                        </div>
                    </div>

                    <div class="tool-section output-section" id="results" style="display: none;">
                        <div class="output-header">
                            <span class="tool-section-title">Results</span>
                            <button class="btn btn-ghost btn-sm" onclick="document.getElementById('results').style.display='none'; document.getElementById('history').innerHTML=''">Clear</button>
                        </div>
                        <div style="background: var(--bg-tertiary); padding: var(--space-6); border-radius: var(--radius-lg);">
                            <div style="font-size: var(--text-4xl); font-weight: var(--font-bold); text-align: center; margin-bottom: var(--space-2);">
                                <span id="last-latency">0</span>
                                <span style="font-size: var(--text-xl); color: var(--text-secondary);">ms</span>
                            </div>
                            <div style="text-align: center; color: var(--text-secondary); margin-bottom: var(--space-4);">Last Result</div>
                            <div id="history" style="display: grid; gap: var(--space-2);"></div>
                        </div>
                    </div>
                </div>

                <script>
                    let testActive = false;
                    let startTime = 0;
                    const circle = document.getElementById('test-circle');
                    const results = [];

                    document.getElementById('start-test').addEventListener('click', startTest);

                    function startTest() {
                        testActive = false;
                        circle.style.background = '#ef4444';
                        const delay = 2000 + Math.random() * 3000;
                        
                        setTimeout(() => {
                            circle.style.background = '#22c55e';
                            testActive = true;
                            startTime = performance.now();
                        }, delay);
                    }

                    document.addEventListener('keydown', handleInput);
                    document.addEventListener('click', handleInput);

                    function handleInput(e) {
                        if (!testActive) return;
                        testActive = false;
                        const latency = Math.round(performance.now() - startTime);
                        results.push(latency);
                        
                        document.getElementById('last-latency').textContent = latency;
                        document.getElementById('results').style.display = 'block';
                        
                        const avg = Math.round(results.reduce((a,b) => a+b, 0) / results.length);
                        const history = document.getElementById('history');
                        history.innerHTML = `
                            <div style="padding: var(--space-3); background: var(--bg-primary); border-radius: var(--radius-md); display: flex; justify-content: space-between;">
                                <span>Average</span>
                                <span style="font-weight: var(--font-semibold);">${avg}ms</span>
                            </div>
                            <div style="padding: var(--space-3); background: var(--bg-primary); border-radius: var(--radius-md); display: flex; justify-content: space-between;">
                                <span>Best</span>
                                <span style="font-weight: var(--font-semibold); color: #22c55e;">${Math.min(...results)}ms</span>
                            </div>
                            <div style="padding: var(--space-3); background: var(--bg-primary); border-radius: var(--radius-md); display: flex; justify-content: space-between;">
                                <span>Worst</span>
                                <span style="font-weight: var(--font-semibold); color: #ef4444;">${Math.max(...results)}ms</span>
                            </div>
                        `;
                        
                        circle.style.background = '#ef4444';
                        Toast.success(`${latency}ms latency`);
                    }
                </script>
        '''
    },
}

def create_emulator_utility(name, description, content):
    slug = name.lower().replace(' ', '-')
    return f'''<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{name} - Emulator Utility | OnlineToolFree</title>
    <meta name="description" content="{description} Free online tool for retro gaming.">
    <link rel="canonical" href="https://onlinetoolfree.com/tools/emulators/{slug}.html">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../../css/design-system.css">
    <script src="../../js/tools.js"></script>
    <script src="../../js/ui.js"></script>
    <script src="../../js/app.js"></script>
</head>
<body>
    <header class="header"></header>
    <div class="tool-layout">
        <aside class="tool-sidebar" id="tool-sidebar"></aside>
        <main class="tool-main">
            <div class="tool-page" style="max-width: 900px; margin: 0; padding: 0;">
                <div class="tool-header" style="text-align: left; margin-bottom: var(--space-6);">
                    <div style="display: flex; align-items: center; gap: var(--space-4); margin-bottom: var(--space-4);">
                        <div class="tool-icon-large" style="margin: 0;">
                            <svg class="icon icon-lg" viewBox="0 0 24 24">
                                <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/>
                            </svg>
                        </div>
                        <div>
                            <h1 class="tool-title" style="font-size: var(--text-2xl);">{name}</h1>
                            <p class="tool-description" style="font-size: var(--text-base); margin: 0;">{description}</p>
                        </div>
                    </div>
                </div>

                {LEGAL_NOTICE}

                {content}

                <section class="info-section" style="margin-top: var(--space-8); padding: var(--space-6); background: var(--bg-primary); border: 1px solid var(--border-light); border-radius: var(--radius-xl);">
                    <h2 style="font-size: var(--text-xl); font-weight: var(--font-semibold); margin-bottom: var(--space-4);">About This Tool</h2>
                    <p>This utility helps optimize your retro gaming emulation experience. All processing happens client-side in your browser.</p>
                </section>
            </div>
        </main>
    </div>
    <button class="sidebar-toggle" id="sidebar-toggle">
        <svg class="icon" viewBox="0 0 24 24">
            <line x1="4" y1="12" x2="20" y2="12"/><line x1="4" y1="6" x2="20" y2="6"/><line x1="4" y1="18" x2="20" y2="18"/>
        </svg>
    </button>
    <footer class="footer"></footer>
    <script>
        document.addEventListener('DOMContentLoaded', () => {{
            Components.renderHeader();
            Components.renderMobileMenu();
            Components.renderSidebar('tool-sidebar');
            Components.renderFooter();
            const sidebarToggle = document.getElementById('sidebar-toggle');
            const sidebar = document.getElementById('tool-sidebar');
            sidebarToggle?.addEventListener('click', () => sidebar?.classList.toggle('open'));
            if (window.ThemeManager) ThemeManager.init();
            if (window.ResponsiveManager) ResponsiveManager.init();
        }});
    </script>
</body>
</html>'''

def main():
    print("="*60)
    print("Adding Functionality to Emulator Utilities")
    print("="*60)
    print()
    
    emulators_dir = Path('./tools/emulators')
    updated = 0
    
    for filename, config in EMULATOR_TOOLS.items():
        file_path = emulators_dir / filename
        html = create_emulator_utility(config['name'], config['description'], config['content'])
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(html)
        print(f"[+] Created: {filename}")
        updated += 1
    
    print()
    print(f"[+] Updated {updated} emulator utilities with full functionality")
    print("="*60)

if __name__ == '__main__':
    main()
