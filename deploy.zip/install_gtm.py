import os
import re

ROOT_DIR = r"c:\Users\LENOVO\.gemini\antigravity\scratch\online-tools-suite"
GTM_ID = "GTM-KWQ2T7QS"

HEAD_CODE = """<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-KWQ2T7QS');</script>
<!-- End Google Tag Manager -->"""

BODY_CODE = """<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-KWQ2T7QS"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->"""

def install_gtm():
    count = 0
    skipped = 0
    
    print(f"Scanning {ROOT_DIR}...")
    
    for root, dirs, files in os.walk(ROOT_DIR):
        for file in files:
            if file.lower().endswith(".html"):
                path = os.path.join(root, file)
                
                try:
                    with open(path, "r", encoding="utf-8") as f:
                        content = f.read()
                    
                    # Check if already installed
                    if GTM_ID in content:
                        print(f"Skipping (already present): {file}")
                        skipped += 1
                        continue
                    
                    # Inject HEAD
                    # Look for <head> or <head ...>
                    new_content = re.sub(
                        r'(<head[^>]*>)', 
                        r'\1\n' + HEAD_CODE, 
                        content, 
                        count=1, 
                        flags=re.IGNORECASE
                    )
                    
                    # Inject BODY
                    # Look for <body> or <body ...>
                    new_content = re.sub(
                        r'(<body[^>]*>)', 
                        r'\1\n' + BODY_CODE, 
                        new_content, 
                        count=1, 
                        flags=re.IGNORECASE
                    )
                    
                    if new_content != content:
                        with open(path, "w", encoding="utf-8") as f:
                            f.write(new_content)
                        print(f"Updated: {file}")
                        count += 1
                    else:
                        print(f"Skipping (tags not found): {file}")
                        
                except Exception as e:
                    print(f"Error processing {path}: {e}")

    print(f"\nSummary: Updated {count} files. Skipped {skipped} files.")

if __name__ == "__main__":
    install_gtm()
