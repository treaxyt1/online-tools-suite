#!/usr/bin/env python3
"""
Open Sample Tools in Browser for Visual Testing
Opens one tool from each category for manual verification
"""

import webbrowser
import time
from pathlib import Path
import os

# Sample tools to open (one from each category)
SAMPLE_TOOLS = [
    ('Productivity', 'tools/productivity/tip-calculator.html'),
    ('Finance', 'tools/finance/salary-calculator.html'),
    ('Writing', 'tools/writing/paraphrasing-tool.html'),
    ('SEO', 'tools/seo/utm-builder.html'),
    ('Image', 'tools/image/image-compressor.html'),
]

def open_tools_in_browser():
    """Open sample tools in default browser"""
    print("=" * 80)
    print("OPENING SAMPLE TOOLS IN BROWSER")
    print("=" * 80)
    print()
    print("Opening one tool from each category for visual testing...")
    print()
    
    base_path = Path(__file__).parent.absolute()
    
    for category, tool_path in SAMPLE_TOOLS:
        full_path = base_path / tool_path
        
        if not full_path.exists():
            print(f"[ERROR] {category}: File not found - {tool_path}")
            continue
        
        # Convert to file:// URL
        file_url = full_path.as_uri()
        
        print(f"[OPENING] {category}: {tool_path}")
        print(f"  URL: {file_url}")
        
        try:
            webbrowser.open(file_url)
            print(f"  [OK] Opened in browser")
            time.sleep(1)  # Wait 1 second between opens
        except Exception as e:
            print(f"  [ERROR] Failed to open: {e}")
        
        print()
    
    print("=" * 80)
    print("BROWSER TESTING CHECKLIST")
    print("=" * 80)
    print()
    print("For each tool, verify:")
    print("  [ ] Page loads without errors")
    print("  [ ] Design matches site theme")
    print("  [ ] Header and sidebar appear")
    print("  [ ] Tool functionality works")
    print("  [ ] No JavaScript console errors")
    print("  [ ] Mobile responsive (resize browser)")
    print("  [ ] All buttons/inputs work")
    print("  [ ] Copy/download features work")
    print()
    print("=" * 80)
    print("ADDITIONAL TESTING")
    print("=" * 80)
    print()
    print("To test all 30 tools, open:")
    print("  file:///C:/Users/LENOVO/.gemini/antigravity/scratch/online-tools-suite/index.html")
    print()
    print("Then navigate to each tool category in the sidebar.")
    print()

if __name__ == '__main__':
    open_tools_in_browser()
