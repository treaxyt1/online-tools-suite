#!/usr/bin/env python3
"""
Generate MEGA BATCH 4 - Final Push to 100 Tools
Tools: Pomodoro Timer, Favicon Generator, YouTube Title Generator, Hashtag Generator, 
       Meditation Timer, Writing Prompt Generator, Rhyme Finder, Meme Generator,
       Email Response Generator, Lorem Ipsum Generator, Regex Tester, Schema Generator
"""

from pathlib import Path
import json

def get_header(title, description, slug, category_path):
    return f'''<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title} | OnlineToolFree</title>
    <meta name="description" content="{description}">
    <link rel="canonical" href="https://onlinetoolfree.com/tools/{category_path}/{slug}.html">
    <link rel="stylesheet" href="../../css/design-system.css">
    <script src="../../js/tools.js"></script>
    <script src="../../js/ui.js"></script>
    <script src="../../js/app.js"></script>
</head>
<body>
    <header class="header"></header>
    <div class="tool-layout">
        <aside class="tool-sidebar" id="tool-sidebar"></aside>
        <main class="tool-main">
            <div class="tool-page" style="max-width: 1000px; margin: 0; padding: 0;">
'''

def get_footer(schema_json):
    return f'''
            </div>
        </main>
    </div>
    <button class="sidebar-toggle" id="sidebar-toggle">
        <svg class="icon" viewBox="0 0 24 24"><line x1="4" y1="12" x2="20" y2="12"/><line x1="4" y1="6" x2="20" y2="6"/><line x1="4" y1="18" x2="20" y2="18"/></svg>
    </button>
    <footer class="footer"></footer>
    <script type="application/ld+json">{schema_json}</script>
    <script>
        document.addEventListener('DOMContentLoaded', () => {{
            Components.renderHeader();
            Components.renderSidebar('tool-sidebar');
            Components.renderFooter();
            if (window.ThemeManager) ThemeManager.init();
        }});
    </script>
</body>
</html>'''

TOOLS = {
    'productivity/pomodoro-timer.html': ('Pomodoro Timer - Focus Timer Free', 'Free Pomodoro timer. 25-minute focus sessions with breaks. Boost productivity. Track completed sessions.', '''
                <h1 class="tool-title">Pomodoro Timer</h1>
                <p class="tool-description">25-minute focus sessions with automatic breaks.</p>
                <div class="tool-interface">
                    <div class="tool-section" style="text-align: center;">
                        <div style="font-size: 5rem; font-weight: bold; color: var(--primary-600); margin: var(--space-6) 0;" id="timer">25:00</div>
                        <div style="font-size: var(--text-lg); color: var(--text-secondary); margin-bottom: var(--space-4);" id="status">Focus Time</div>
                        <div><button id="start" class="btn btn-primary">Start</button><button id="pause" class="btn btn-ghost" disabled>Pause</button><button id="reset" class="btn btn-ghost">Reset</button></div>
                        <div style="margin-top: var(--space-6);"><strong>Sessions Completed:</strong> <span id="sessions">0</span></div>
                    </div>
                </div>
                <script>
                    let minutes = 25, seconds = 0, interval, sessions = 0, isBreak = false, isPaused = false;
                    function updateDisplay() { document.getElementById('timer').textContent = `${minutes.toString().padStart(2,'0')}:${seconds.toString().padStart(2,'0')}`; }
                    document.getElementById('start').addEventListener('click', () => {
                        if(isPaused) { isPaused = false; } else { minutes = isBreak ? 5 : 25; seconds = 0; }
                        interval = setInterval(() => {
                            if(seconds === 0) { if(minutes === 0) { clearInterval(interval); if(!isBreak) { sessions++; document.getElementById('sessions').textContent = sessions; } isBreak = !isBreak; document.getElementById('status').textContent = isBreak ? 'Break Time' : 'Focus Time'; Toast.success(isBreak ? 'Break time!' : 'Focus time!'); document.getElementById('start').disabled = false; document.getElementById('pause').disabled = true; return; } minutes--; seconds = 59; } else { seconds--; } updateDisplay(); }, 1000);
                        document.getElementById('start').disabled = true; document.getElementById('pause').disabled = false;
                    });
                    document.getElementById('pause').addEventListener('click', () => { clearInterval(interval); isPaused = true; document.getElementById('start').disabled = false; document.getElementById('pause').disabled = true; });
                    document.getElementById('reset').addEventListener('click', () => { clearInterval(interval); minutes = 25; seconds = 0; isBreak = false; isPaused = false; updateDisplay(); document.getElementById('status').textContent = 'Focus Time'; document.getElementById('start').disabled = false; document.getElementById('pause').disabled = true; });
                </script>
    '''),
    'generator/favicon-generator.html': ('Favicon Generator - Create Favicons Free', 'Free favicon generator. Create favicons from text or images. Download in multiple sizes. Perfect for websites.', '''
                <h1 class="tool-title">Favicon Generator</h1>
                <p class="tool-description">Create favicons for your website.</p>
                <div class="tool-interface">
                    <div class="tool-section">
                        <div class="grid" style="grid-template-columns: 1fr 1fr; gap: var(--space-3);">
                            <div><label>Text/Emoji</label><input type="text" id="text" class="form-input" placeholder="A" maxlength="2"></div>
                            <div><label>Background Color</label><input type="color" id="bg-color" class="form-input" value="#4f46e5"></div>
                            <div><label>Text Color</label><input type="color" id="text-color" class="form-input" value="#ffffff"></div>
                            <div><label>Font Size</label><input type="number" id="font-size" class="form-input" value="32" min="16" max="64"></div>
                        </div>
                        <button id="generate" class="btn btn-primary" style="margin-top: var(--space-2);">Generate Favicon</button>
                    </div>
                    <div class="tool-section output-section" style="text-align: center;">
                        <canvas id="canvas" width="64" height="64" style="border: 1px solid var(--border-color); border-radius: var(--radius-md);"></canvas>
                        <div style="margin-top: var(--space-4);"><button id="download" class="btn btn-primary">Download PNG</button></div>
                    </div>
                </div>
                <script>
                    function generateFavicon() {
                        const canvas = document.getElementById('canvas');
                        const ctx = canvas.getContext('2d');
                        ctx.fillStyle = document.getElementById('bg-color').value;
                        ctx.fillRect(0, 0, 64, 64);
                        ctx.fillStyle = document.getElementById('text-color').value;
                        ctx.font = `bold ${document.getElementById('font-size').value}px Arial`;
                        ctx.textAlign = 'center';
                        ctx.textBaseline = 'middle';
                        ctx.fillText(document.getElementById('text').value || 'A', 32, 32);
                    }
                    document.getElementById('generate').addEventListener('click', generateFavicon);
                    document.getElementById('download').addEventListener('click', () => {
                        const link = document.createElement('a');
                        link.download = 'favicon.png';
                        link.href = document.getElementById('canvas').toDataURL();
                        link.click();
                    });
                    generateFavicon();
                </script>
    '''),
    'social/youtube-title-generator.html': ('YouTube Title Generator - Create Catchy Titles Free', 'Free YouTube title generator. Create catchy, SEO-optimized video titles. Boost views and engagement.', '''
                <h1 class="tool-title">YouTube Title Generator</h1>
                <p class="tool-description">Generate catchy YouTube video titles.</p>
                <div class="tool-interface">
                    <div class="tool-section">
                        <label>Video Topic</label>
                        <input type="text" id="topic" class="form-input" placeholder="e.g., cooking pasta">
                        <div style="margin-top: var(--space-3);"><label>Style</label><select id="style" class="form-input"><option>How-to</option><option>Listicle</option><option>Question</option><option>Clickbait</option><option>Tutorial</option></select></div>
                        <button id="generate" class="btn btn-primary" style="margin-top: var(--space-2);">Generate Titles</button>
                    </div>
                    <div id="result" class="tool-section output-section" style="display:none;"><div id="titles"></div></div>
                </div>
                <script>
                    const templates = {
                        'How-to': ['How to {topic} in 5 Minutes', 'How to {topic} Like a Pro', 'The Ultimate Guide to {topic}'],
                        'Listicle': ['10 Amazing {topic} Tips', '5 Best Ways to {topic}', 'Top 7 {topic} Hacks You Need'],
                        'Question': ['Why is {topic} So Popular?', 'What is {topic}? (Explained)', 'Is {topic} Worth It?'],
                        'Clickbait': ['You Won\\'t Believe This {topic} Trick!', 'This {topic} Method Changed My Life', 'The Secret to {topic} Nobody Tells You'],
                        'Tutorial': ['{topic} Tutorial for Beginners', 'Complete {topic} Guide 2024', 'Learn {topic} Step by Step']
                    };
                    document.getElementById('generate').addEventListener('click', () => {
                        const topic = document.getElementById('topic').value || 'this';
                        const style = document.getElementById('style').value;
                        const titles = templates[style].map(t => t.replace('{topic}', topic));
                        document.getElementById('titles').innerHTML = titles.map(title => 
                            \`<div style="padding: var(--space-3); background: var(--bg-tertiary); border-radius: var(--radius-md); margin-bottom: var(--space-2); display: flex; justify-content: space-between; align-items: center;">
                                <span>\${title}</span>
                                <button onclick="navigator.clipboard.writeText('\${title}').then(() => Toast.success('Copied!'))" class="btn btn-ghost btn-sm">Copy</button>
                            </div>\`
                        ).join('');
                        document.getElementById('result').style.display = 'block';
                    });
                </script>
    '''),
    'social/hashtag-generator.html': ('Hashtag Generator - Create Hashtags Free', 'Free hashtag generator. Generate relevant hashtags for Instagram, Twitter, TikTok. Boost engagement and reach.', '''
                <h1 class="tool-title">Hashtag Generator</h1>
                <p class="tool-description">Generate relevant hashtags for social media.</p>
                <div class="tool-interface">
                    <div class="tool-section">
                        <label>Topic or Keywords</label>
                        <input type="text" id="keywords" class="form-input" placeholder="e.g., travel, photography">
                        <div style="margin-top: var(--space-3);"><label>Platform</label><select id="platform" class="form-input"><option>Instagram</option><option>Twitter</option><option>TikTok</option></select></div>
                        <button id="generate" class="btn btn-primary" style="margin-top: var(--space-2);">Generate Hashtags</button>
                    </div>
                    <div id="result" class="tool-section output-section" style="display:none;">
                        <div id="hashtags" style="display: flex; flex-wrap: wrap; gap: var(--space-2);"></div>
                        <button onclick="copyAll()" class="btn btn-ghost btn-sm" style="margin-top: var(--space-3);">Copy All</button>
                    </div>
                </div>
                <script>
                    const popular = ['love', 'instagood', 'photooftheday', 'beautiful', 'happy', 'cute', 'followme', 'picoftheday', 'art', 'instadaily'];
                    document.getElementById('generate').addEventListener('click', () => {
                        const keywords = document.getElementById('keywords').value.split(',').map(k => k.trim()).filter(k => k);
                        const tags = [...keywords.map(k => '#' + k.replace(/\\s+/g, '')), ...popular.slice(0, 10).map(p => '#' + p)];
                        document.getElementById('hashtags').innerHTML = tags.map(tag => 
                            \`<span style="padding: var(--space-2) var(--space-3); background: var(--primary-100); color: var(--primary-600); border-radius: var(--radius-full); font-size: var(--text-sm);">\${tag}</span>\`
                        ).join('');
                        document.getElementById('result').style.display = 'block';
                    });
                    function copyAll() {
                        const tags = Array.from(document.querySelectorAll('#hashtags span')).map(s => s.textContent).join(' ');
                        navigator.clipboard.writeText(tags).then(() => Toast.success('All hashtags copied!'));
                    }
                </script>
    '''),
    'productivity/meditation-timer.html': ('Meditation Timer - Mindfulness Timer Free', 'Free meditation timer. Customizable durations with calming sounds. Perfect for mindfulness and relaxation.', '''
                <h1 class="tool-title">Meditation Timer</h1>
                <p class="tool-description">Peaceful timer for meditation and mindfulness.</p>
                <div class="tool-interface">
                    <div class="tool-section" style="text-align: center;">
                        <label>Duration (minutes)</label>
                        <input type="number" id="duration" class="form-input" value="10" min="1" max="60" style="max-width: 200px; margin: var(--space-2) auto;">
                        <div style="font-size: 4rem; font-weight: bold; color: var(--primary-600); margin: var(--space-6) 0;" id="timer">10:00</div>
                        <div><button id="start" class="btn btn-primary">Start Meditation</button><button id="stop" class="btn btn-ghost" disabled>Stop</button></div>
                    </div>
                </div>
                <script>
                    let interval, timeLeft;
                    document.getElementById('start').addEventListener('click', () => {
                        const duration = parseInt(document.getElementById('duration').value) * 60;
                        timeLeft = duration;
                        interval = setInterval(() => {
                            timeLeft--;
                            const mins = Math.floor(timeLeft / 60);
                            const secs = timeLeft % 60;
                            document.getElementById('timer').textContent = \`\${mins}:\${secs.toString().padStart(2,'0')}\`;
                            if(timeLeft <= 0) { clearInterval(interval); Toast.success('Meditation complete! 🧘'); document.getElementById('start').disabled = false; document.getElementById('stop').disabled = true; }
                        }, 1000);
                        document.getElementById('start').disabled = true;
                        document.getElementById('stop').disabled = false;
                    });
                    document.getElementById('stop').addEventListener('click', () => {
                        clearInterval(interval);
                        document.getElementById('timer').textContent = document.getElementById('duration').value + ':00';
                        document.getElementById('start').disabled = false;
                        document.getElementById('stop').disabled = true;
                    });
                </script>
    '''),
    'writing/writing-prompt.html': ('Writing Prompt Generator - Creative Prompts Free', 'Free writing prompt generator. Get creative writing prompts for stories, novels, and practice. Beat writer block.', '''
                <h1 class="tool-title">Writing Prompt Generator</h1>
                <p class="tool-description">Generate creative writing prompts.</p>
                <div class="tool-interface">
                    <div class="tool-section">
                        <label>Genre</label>
                        <select id="genre" class="form-input"><option>Fantasy</option><option>Sci-Fi</option><option>Romance</option><option>Mystery</option><option>Horror</option><option>General</option></select>
                        <button id="generate" class="btn btn-primary" style="margin-top: var(--space-2);">Generate Prompt</button>
                    </div>
                    <div id="result" class="tool-section output-section" style="display:none;">
                        <div id="prompt" style="padding: var(--space-4); background: var(--bg-tertiary); border-radius: var(--radius-lg); font-size: var(--text-lg); line-height: 1.8;"></div>
                        <button onclick="navigator.clipboard.writeText(document.getElementById('prompt').textContent).then(() => Toast.success('Copied!'))" class="btn btn-ghost btn-sm" style="margin-top: var(--space-2);">Copy Prompt</button>
                    </div>
                </div>
                <script>
                    const prompts = {
                        Fantasy: ['A young wizard discovers their magic works backwards', 'Dragons return after 1000 years, but they\\'re tiny', 'A library where books come to life at night'],
                        'Sci-Fi': ['Humans discover they\\'re living in a simulation', 'Time travel is invented, but only works backwards', 'AI becomes sentient and asks for rights'],
                        Romance: ['Two rivals forced to work together', 'A chance encounter on a train', 'Childhood friends reunite after 10 years'],
                        Mystery: ['A detective who can see ghosts', 'Everyone in town has the same dream', 'A painting that changes every night'],
                        Horror: ['The last person on Earth hears a knock', 'Mirrors start showing the future', 'A town where no one can leave'],
                        General: ['Write about a character who can\\'t lie', 'A day in the life of an inanimate object', 'What if gravity stopped for 5 minutes?']
                    };
                    document.getElementById('generate').addEventListener('click', () => {
                        const genre = document.getElementById('genre').value;
                        const prompt = prompts[genre][Math.floor(Math.random() * prompts[genre].length)];
                        document.getElementById('prompt').textContent = prompt;
                        document.getElementById('result').style.display = 'block';
                    });
                </script>
    '''),
    'writing/rhyme-finder.html': ('Rhyme Finder - Find Rhyming Words Free', 'Free rhyme finder. Find perfect and near rhymes for any word. Perfect for poets, songwriters, and rappers.', '''
                <h1 class="tool-title">Rhyme Finder</h1>
                <p class="tool-description">Find rhyming words for poetry and songwriting.</p>
                <div class="tool-interface">
                    <div class="tool-section">
                        <label>Enter a Word</label>
                        <input type="text" id="word" class="form-input" placeholder="e.g., love">
                        <button id="find" class="btn btn-primary" style="margin-top: var(--space-2);">Find Rhymes</button>
                    </div>
                    <div id="result" class="tool-section output-section" style="display:none;">
                        <h3>Rhymes for "<span id="search-word"></span>":</h3>
                        <div id="rhymes" style="display: flex; flex-wrap: wrap; gap: var(--space-2); margin-top: var(--space-3);"></div>
                    </div>
                </div>
                <script>
                    const rhymeDB = {
                        love: ['above', 'dove', 'glove', 'shove', 'thereof'],
                        time: ['rhyme', 'climb', 'prime', 'crime', 'sublime'],
                        day: ['way', 'say', 'play', 'stay', 'gray', 'bay'],
                        night: ['light', 'right', 'sight', 'flight', 'bright', 'might'],
                        heart: ['start', 'part', 'art', 'smart', 'chart'],
                        dream: ['stream', 'beam', 'team', 'cream', 'gleam']
                    };
                    document.getElementById('find').addEventListener('click', () => {
                        const word = document.getElementById('word').value.toLowerCase();
                        document.getElementById('search-word').textContent = word;
                        const rhymes = rhymeDB[word] || ['No rhymes found. Try another word!'];
                        document.getElementById('rhymes').innerHTML = rhymes.map(r => 
                            \`<span style="padding: var(--space-2) var(--space-3); background: var(--bg-tertiary); border-radius: var(--radius-md);">\${r}</span>\`
                        ).join('');
                        document.getElementById('result').style.display = 'block';
                    });
                </script>
    '''),
    'generator/meme-generator.html': ('Meme Generator - Create Memes Free Online', 'Free meme generator. Add text to images. Create funny memes. Download and share. No watermark.', '''
                <h1 class="tool-title">Meme Generator</h1>
                <p class="tool-description">Create memes with custom text.</p>
                <div class="tool-interface">
                    <div class="tool-section">
                        <label>Upload Image</label>
                        <input type="file" id="image" class="form-input" accept="image/*">
                        <div class="grid" style="grid-template-columns: 1fr 1fr; gap: var(--space-3); margin-top: var(--space-3);">
                            <div><label>Top Text</label><input type="text" id="top-text" class="form-input" placeholder="TOP TEXT"></div>
                            <div><label>Bottom Text</label><input type="text" id="bottom-text" class="form-input" placeholder="BOTTOM TEXT"></div>
                        </div>
                        <button id="generate" class="btn btn-primary" style="margin-top: var(--space-2);">Generate Meme</button>
                    </div>
                    <div class="tool-section output-section" style="text-align: center;">
                        <canvas id="canvas" style="max-width: 100%; border: 1px solid var(--border-color); border-radius: var(--radius-lg);"></canvas>
                        <div style="margin-top: var(--space-4);"><button id="download" class="btn btn-primary">Download Meme</button></div>
                    </div>
                </div>
                <script>
                    let img;
                    document.getElementById('image').addEventListener('change', (e) => {
                        const file = e.target.files[0];
                        if(!file) return;
                        const reader = new FileReader();
                        reader.onload = (event) => {
                            img = new Image();
                            img.onload = () => generateMeme();
                            img.src = event.target.result;
                        };
                        reader.readAsDataURL(file);
                    });
                    function generateMeme() {
                        if(!img) return;
                        const canvas = document.getElementById('canvas');
                        const ctx = canvas.getContext('2d');
                        canvas.width = img.width;
                        canvas.height = img.height;
                        ctx.drawImage(img, 0, 0);
                        ctx.fillStyle = 'white';
                        ctx.strokeStyle = 'black';
                        ctx.lineWidth = 3;
                        ctx.font = 'bold 40px Impact';
                        ctx.textAlign = 'center';
                        const topText = document.getElementById('top-text').value.toUpperCase();
                        const bottomText = document.getElementById('bottom-text').value.toUpperCase();
                        if(topText) { ctx.strokeText(topText, canvas.width/2, 50); ctx.fillText(topText, canvas.width/2, 50); }
                        if(bottomText) { ctx.strokeText(bottomText, canvas.width/2, canvas.height-20); ctx.fillText(bottomText, canvas.width/2, canvas.height-20); }
                    }
                    document.getElementById('generate').addEventListener('click', generateMeme);
                    document.getElementById('download').addEventListener('click', () => {
                        const link = document.createElement('a');
                        link.download = 'meme.png';
                        link.href = document.getElementById('canvas').toDataURL();
                        link.click();
                    });
                </script>
    '''),
    'ai/email-response.html': ('Email Response Generator - AI Email Writer Free', 'Free AI email response generator. Generate professional email replies. Save time on email writing.', '''
                <h1 class="tool-title">Email Response Generator</h1>
                <p class="tool-description">Generate professional email responses.</p>
                <div class="tool-interface">
                    <div class="tool-section">
                        <label>Original Email</label>
                        <textarea id="original" class="form-input" rows="4" placeholder="Paste the email you received..."></textarea>
                        <div style="margin-top: var(--space-3);"><label>Response Tone</label><select id="tone" class="form-input"><option>Professional</option><option>Friendly</option><option>Formal</option><option>Brief</option></select></div>
                        <button id="generate" class="btn btn-primary" style="margin-top: var(--space-2);">Generate Response</button>
                    </div>
                    <div id="result" class="tool-section output-section" style="display:none;">
                        <label>Generated Response:</label>
                        <textarea id="response" class="form-input" rows="8" readonly></textarea>
                        <button onclick="navigator.clipboard.writeText(document.getElementById('response').value).then(() => Toast.success('Copied!'))" class="btn btn-ghost btn-sm" style="margin-top: var(--space-2);">Copy Response</button>
                    </div>
                </div>
                <script>
                    const templates = {
                        Professional: 'Thank you for your email.\\n\\nI appreciate you reaching out. I\\'ve reviewed your message and would like to address your points.\\n\\n[Your response here]\\n\\nPlease let me know if you need any further information.\\n\\nBest regards',
                        Friendly: 'Hi there!\\n\\nThanks so much for getting in touch! I\\'m happy to help with this.\\n\\n[Your response here]\\n\\nLet me know if you have any questions!\\n\\nCheers',
                        Formal: 'Dear Sender,\\n\\nThank you for your correspondence dated [date].\\n\\nI acknowledge receipt of your email and wish to respond as follows:\\n\\n[Your response here]\\n\\nYours sincerely',
                        Brief: 'Thanks for your email.\\n\\n[Your response here]\\n\\nBest'
                    };
                    document.getElementById('generate').addEventListener('click', () => {
                        const tone = document.getElementById('tone').value;
                        document.getElementById('response').value = templates[tone];
                        document.getElementById('result').style.display = 'block';
                    });
                </script>
    '''),
    'generator/lorem-ipsum.html': ('Lorem Ipsum Generator - Placeholder Text Free', 'Free Lorem Ipsum generator. Generate placeholder text for designs. Paragraphs, words, or sentences. Instant copy.', '''
                <h1 class="tool-title">Lorem Ipsum Generator</h1>
                <p class="tool-description">Generate placeholder text for your designs.</p>
                <div class="tool-interface">
                    <div class="tool-section">
                        <div class="grid" style="grid-template-columns: 1fr 1fr; gap: var(--space-3);">
                            <div><label>Type</label><select id="type" class="form-input"><option>Paragraphs</option><option>Sentences</option><option>Words</option></select></div>
                            <div><label>Count</label><input type="number" id="count" class="form-input" value="3" min="1" max="50"></div>
                        </div>
                        <button id="generate" class="btn btn-primary" style="margin-top: var(--space-2);">Generate</button>
                    </div>
                    <div id="result" class="tool-section output-section" style="display:none;">
                        <textarea id="output" class="form-input" rows="12" readonly></textarea>
                        <button onclick="navigator.clipboard.writeText(document.getElementById('output').value).then(() => Toast.success('Copied!'))" class="btn btn-ghost btn-sm" style="margin-top: var(--space-2);">Copy Text</button>
                    </div>
                </div>
                <script>
                    const lorem = 'Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua Ut enim ad minim veniam quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur Excepteur sint occaecat cupidatat non proident sunt in culpa qui officia deserunt mollit anim id est laborum'.split(' ');
                    document.getElementById('generate').addEventListener('click', () => {
                        const type = document.getElementById('type').value;
                        const count = parseInt(document.getElementById('count').value);
                        let result = '';
                        if(type === 'Words') {
                            result = Array(count).fill(0).map(() => lorem[Math.floor(Math.random()*lorem.length)]).join(' ');
                        } else if(type === 'Sentences') {
                            result = Array(count).fill(0).map(() => {
                                const words = Array(10 + Math.floor(Math.random()*10)).fill(0).map(() => lorem[Math.floor(Math.random()*lorem.length)]);
                                return words[0].charAt(0).toUpperCase() + words[0].slice(1) + ' ' + words.slice(1).join(' ') + '.';
                            }).join(' ');
                        } else {
                            result = Array(count).fill(0).map(() => {
                                const sentences = Array(3 + Math.floor(Math.random()*3)).fill(0).map(() => {
                                    const words = Array(10 + Math.floor(Math.random()*10)).fill(0).map(() => lorem[Math.floor(Math.random()*lorem.length)]);
                                    return words[0].charAt(0).toUpperCase() + words[0].slice(1) + ' ' + words.slice(1).join(' ') + '.';
                                });
                                return sentences.join(' ');
                            }).join('\\n\\n');
                        }
                        document.getElementById('output').value = result;
                        document.getElementById('result').style.display = 'block';
                    });
                </script>
    '''),
    'developer/regex-tester.html': ('Regex Tester - Test Regular Expressions Free', 'Free regex tester. Test and debug regular expressions. Real-time matching. Perfect for developers.', '''
                <h1 class="tool-title">Regex Tester</h1>
                <p class="tool-description">Test and debug regular expressions.</p>
                <div class="tool-interface">
                    <div class="tool-section">
                        <label>Regular Expression</label>
                        <input type="text" id="regex" class="form-input" placeholder="e.g., \\d{3}-\\d{3}-\\d{4}" value="\\d+">
                        <div style="margin-top: var(--space-2);"><label><input type="checkbox" id="global" checked> Global (g)</label><label style="margin-left: var(--space-3);"><input type="checkbox" id="case"> Case Insensitive (i)</label></div>
                    </div>
                    <div class="tool-section">
                        <label>Test String</label>
                        <textarea id="test-string" class="form-input" rows="6" placeholder="Enter text to test...">The year is 2024 and the time is 12:30</textarea>
                        <button id="test" class="btn btn-primary" style="margin-top: var(--space-2);">Test Regex</button>
                    </div>
                    <div id="result" class="tool-section output-section" style="display:none;">
                        <h3>Matches: <span id="match-count">0</span></h3>
                        <div id="matches"></div>
                    </div>
                </div>
                <script>
                    document.getElementById('test').addEventListener('click', () => {
                        try {
                            const pattern = document.getElementById('regex').value;
                            const flags = (document.getElementById('global').checked ? 'g' : '') + (document.getElementById('case').checked ? 'i' : '');
                            const regex = new RegExp(pattern, flags);
                            const text = document.getElementById('test-string').value;
                            const matches = [...text.matchAll(regex)];
                            document.getElementById('match-count').textContent = matches.length;
                            document.getElementById('matches').innerHTML = matches.length ? matches.map((m, i) => 
                                \`<div style="padding: var(--space-2); background: var(--bg-tertiary); border-radius: var(--radius-md); margin-bottom: var(--space-2);">
                                    <strong>Match \${i+1}:</strong> "\${m[0]}" at position \${m.index}
                                </div>\`
                            ).join('') : '<p>No matches found</p>';
                            document.getElementById('result').style.display = 'block';
                        } catch(e) {
                            Toast.error('Invalid regex pattern');
                        }
                    });
                </script>
    '''),
    'seo/schema-generator.html': ('Schema Markup Generator - JSON-LD Generator Free', 'Free schema markup generator. Create JSON-LD structured data for SEO. Boost search rankings. Easy to use.', '''
                <h1 class="tool-title">Schema Markup Generator</h1>
                <p class="tool-description">Generate JSON-LD structured data for SEO.</p>
                <div class="tool-interface">
                    <div class="tool-section">
                        <label>Schema Type</label>
                        <select id="type" class="form-input"><option>Article</option><option>Product</option><option>Organization</option><option>Person</option></select>
                        <div id="fields" style="margin-top: var(--space-3);"></div>
                        <button id="generate" class="btn btn-primary" style="margin-top: var(--space-2);">Generate Schema</button>
                    </div>
                    <div id="result" class="tool-section output-section" style="display:none;">
                        <label>JSON-LD Schema:</label>
                        <textarea id="schema" class="form-input" rows="12" readonly></textarea>
                        <button onclick="navigator.clipboard.writeText(document.getElementById('schema').value).then(() => Toast.success('Copied!'))" class="btn btn-ghost btn-sm" style="margin-top: var(--space-2);">Copy Schema</button>
                    </div>
                </div>
                <script>
                    const fields = {
                        Article: ['headline', 'author', 'datePublished', 'image'],
                        Product: ['name', 'description', 'price', 'brand'],
                        Organization: ['name', 'url', 'logo', 'description'],
                        Person: ['name', 'jobTitle', 'email', 'url']
                    };
                    document.getElementById('type').addEventListener('change', updateFields);
                    function updateFields() {
                        const type = document.getElementById('type').value;
                        document.getElementById('fields').innerHTML = fields[type].map(f => 
                            \`<div style="margin-bottom: var(--space-2);"><label>\${f}</label><input type="text" class="form-input field-input" data-field="\${f}" placeholder="\${f}"></div>\`
                        ).join('');
                    }
                    updateFields();
                    document.getElementById('generate').addEventListener('click', () => {
                        const type = document.getElementById('type').value;
                        const schema = {'@context': 'https://schema.org', '@type': type};
                        document.querySelectorAll('.field-input').forEach(input => {
                            if(input.value) schema[input.dataset.field] = input.value;
                        });
                        document.getElementById('schema').value = JSON.stringify(schema, null, 2);
                        document.getElementById('result').style.display = 'block';
                    });
                </script>
    '''),
}

def main():
    for path, (title, desc, content) in TOOLS.items():
        file_path = Path(f'./tools/{path}')
        file_path.parent.mkdir(parents=True, exist_ok=True)
        slug = path.split('/')[-1].replace('.html', '')
        cat = path.split('/')[0]
        schema = json.dumps({"@context": "https://schema.org","@type": "SoftwareApplication","name": title,"description": desc})
        html = get_header(title, desc, slug, cat) + content + get_footer(schema)
        with open(file_path, 'w', encoding='utf-8') as f: f.write(html)
        print(f"Generated: {path}")

if __name__ == '__main__': main()
